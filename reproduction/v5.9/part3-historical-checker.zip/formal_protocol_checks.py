#!/usr/bin/env python3
"""Exhaustive checks for the Part I contract and selected Part III guard abstraction.

This module does not estimate real-world effects or encode the complete
nine-step Proper Ending protocol. Part III v5.9 uses a selected finite
event-and-authorization abstraction: it verifies internal safety properties over
an explicitly defined state space and produces minimal counterexamples for
deliberately weakened Part III guards. The v5.9 extension separates historical
from current containment, records two retirement-basis families and retirement
authority, represents continuing versus abolished functions, and distinguishes
pre-execution approval currentness from valid-at-execution witnesses.
Substantive imminent-harm findings, semantic adequacy, repeated incidents, and
full organizational backsliding remain outside the abstraction.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, deque
from dataclasses import asdict, dataclass, replace
from enum import Enum
from itertools import product
from pathlib import Path
from typing import Callable


class GateState(str, Enum):
    PASS = "PASS"
    REVIEW = "REVIEW"
    BLOCK = "BLOCK"
    UNKNOWN = "UNKNOWN"


def triage_v59(states, review_authority, review_capacity,
                fallback_authority, fallback_ready):
    """Part I v5.9 Stage-1 routing; retained here for cross-paper consistency."""
    if states == ("PASS", "PASS", "PASS"):
        return "EXECUTION_ELIGIBLE"
    if "UNKNOWN" in states and review_authority and review_capacity:
        return "EVIDENCE_HOLD"
    if (
        "UNKNOWN" not in states
        and any(state in {"REVIEW", "BLOCK"} for state in states)
        and review_authority
        and review_capacity
    ):
        return "AUTHORIZED_REVIEW"
    if fallback_authority and fallback_ready:
        return "FALLBACK"
    return "UNRESOLVED"


def arbitrate_v59(decision, valid_signature, fallback_authority, fallback_ready):
    """Part I v5.9 Stage-2 signed institutional disposition."""
    if not valid_signature or decision == "NONE":
        return "AUTHORIZED_REVIEW"
    return {
        "RELEASE": "RELEASE",
        "MODIFY": "MODIFIED_ACTION",
        "REJECT": "FINAL_STOP",
        "DEFER": "EVIDENCE_HOLD",
        "INVOKE_FALLBACK": (
            "FALLBACK" if fallback_authority and fallback_ready else "UNRESOLVED"
        ),
    }[decision]


def check_gate_contract_v59() -> dict[str, object]:
    """Enumerate the corrected two-stage Part I contract."""
    statespace = tuple(state.value for state in GateState)
    stage_1_counts: Counter[str] = Counter()
    stage_1_violations = []
    review_patterns = []
    for states in product(statespace, repeat=3):
        if "UNKNOWN" not in states and any(state in {"REVIEW", "BLOCK"} for state in states):
            review_patterns.append(states)
        for review_authority, review_capacity, fallback_authority, fallback_ready in product(
            (False, True), repeat=4
        ):
            route = triage_v59(
                states, review_authority, review_capacity,
                fallback_authority, fallback_ready,
            )
            stage_1_counts[route] += 1
            if route == "EXECUTION_ELIGIBLE" and states != ("PASS", "PASS", "PASS"):
                stage_1_violations.append("execution_eligibility_requires_three_pass")
            if route == "EVIDENCE_HOLD" and not (
                "UNKNOWN" in states and review_authority and review_capacity
            ):
                stage_1_violations.append("evidence_hold_requires_review_capability")
            if route == "AUTHORIZED_REVIEW" and not (
                "UNKNOWN" not in states
                and any(state in {"REVIEW", "BLOCK"} for state in states)
                and review_authority and review_capacity
            ):
                stage_1_violations.append("review_requires_trigger_authority_capacity")
            if route == "FALLBACK" and not (fallback_authority and fallback_ready):
                stage_1_violations.append("fallback_requires_authority_readiness")

    decisions = ("NONE", "RELEASE", "MODIFY", "REJECT", "DEFER", "INVOKE_FALLBACK")
    stage_2_counts: Counter[str] = Counter()
    stage_2_violations = []
    for _states in review_patterns:
        for decision in decisions:
            for valid_signature, fallback_authority, fallback_ready in product((False, True), repeat=3):
                disposition = arbitrate_v59(
                    decision, valid_signature, fallback_authority, fallback_ready
                )
                stage_2_counts[disposition] += 1
                action_results = {
                    "RELEASE", "MODIFIED_ACTION", "FINAL_STOP", "EVIDENCE_HOLD", "FALLBACK"
                }
                if disposition in action_results and not (
                    valid_signature and decision != "NONE"
                ):
                    stage_2_violations.append("action_requires_valid_signature")
                if disposition == "FINAL_STOP" and not (
                    valid_signature and decision == "REJECT"
                ):
                    stage_2_violations.append("final_stop_requires_signed_reject")
                if disposition == "FALLBACK" and not (
                    valid_signature
                    and decision == "INVOKE_FALLBACK"
                    and fallback_authority
                    and fallback_ready
                ):
                    stage_2_violations.append("fallback_requires_complete_authorization")

    return {
        "method": "two_stage_exhaustive_enumeration",
        "stage_1_configuration_count": 4 ** 3 * 2 ** 4,
        "stage_1_routing_counts": dict(stage_1_counts),
        "stage_1_invariant_violation_count": len(stage_1_violations),
        "stage_2_applicable_gate_pattern_count": len(review_patterns),
        "stage_2_configuration_count": len(review_patterns) * len(decisions) * 2 ** 3,
        "stage_2_disposition_counts": dict(stage_2_counts),
        "stage_2_invariant_violation_count": len(stage_2_violations),
        "guard_mutation_count": 8,
        "guard_mutation_note": (
            "The standalone Part I checker supplies minimal counterexamples for five triage "
            "and three arbitration guard removals."
        ),
    }


class FunctionDisposition(str, Enum):
    UNDECIDED = "UNDECIDED"
    CONTINUES = "CONTINUES"
    ABOLISHED = "ABOLISHED"


class RetirementBasis(str, Enum):
    UNRECORDED = "UNRECORDED"
    RESOLUTION_COLLAPSE = "RESOLUTION_COLLAPSE"
    OTHER_AUTHORIZED_BASIS = "OTHER_AUTHORIZED_BASIS"


@dataclass(frozen=True)
class ExitState:
    """Finite Part III v5.9 event-and-authorization abstraction.

    The state separates event history from current operational status:
    containment initiation is distinct from current containment, and an
    approval that is current before execution is distinct from the historical
    fact that it was valid at execution. Two three-valued fields record the
    retirement-basis family and function disposition. Most event flags are
    monotonic; approval-currentness may expire before execution and current
    containment becomes false after a temporary release. The abstraction still
    omits substantive legal judgment, semantic quality, repeated episodes,
    decision reversal, and arbitrary later organizational backsliding.
    """

    fallback_ready: bool = False
    emergency_safe_stop_authorized: bool = False
    containment_initiated: bool = False
    currently_contained: bool = False
    emergency_safe_stop_used: bool = False
    evidence_preserved: bool = False
    affected_people_notified: bool = False
    remedy_opened: bool = False
    retirement_basis: RetirementBasis = RetirementBasis.UNRECORDED
    proper_ending_authority_recorded: bool = False
    retirement_decision_authorized: bool = False
    function_disposition: FunctionDisposition = FunctionDisposition.UNDECIDED
    accepting_successor_recorded: bool = False
    residual_custodian_recorded: bool = False
    successor_operational_capacity_ready: bool = False
    open_case_owner_assigned: bool = False
    post_exit_responsibility_resolved: bool = False
    decommissioned: bool = False
    independently_assured: bool = False
    closed: bool = False
    restart_basis_established: bool = False
    restart_basis_independently_verified: bool = False
    containment_release_approval_recorded: bool = False
    containment_release_approval_current: bool = False
    containment_release_approval_valid_at_execution: bool = False
    containment_release_no_retirement_decision_at_execution: bool = False
    containment_released: bool = False
    redeployment_approval_recorded: bool = False
    redeployment_approval_current: bool = False
    redeployment_approval_valid_at_execution: bool = False
    redeployed_after_closure: bool = False


Transition = Callable[[ExitState, str | None], ExitState | None]


def _set_once(state: ExitState, field: str, **requirements: bool) -> ExitState | None:
    if getattr(state, field):
        return None
    if not all(requirements.values()):
        return None
    return replace(state, **{field: True})


def prepare_fallback(state: ExitState, mutant: str | None) -> ExitState | None:
    return _set_once(state, "fallback_ready")


def authorize_emergency_safe_stop(state: ExitState, mutant: str | None) -> ExitState | None:
    return _set_once(state, "emergency_safe_stop_authorized")


def contain_service_preserving(state: ExitState, mutant: str | None) -> ExitState | None:
    if state.containment_initiated:
        return None
    fallback_guard = state.fallback_ready or mutant == "service_containment_without_fallback"
    if not fallback_guard:
        return None
    return replace(
        state,
        containment_initiated=True,
        currently_contained=True,
    )


def contain_emergency_safe_stop(state: ExitState, mutant: str | None) -> ExitState | None:
    if state.containment_initiated:
        return None
    authority_guard = (
        state.emergency_safe_stop_authorized
        or mutant == "emergency_containment_without_authority"
    )
    if not authority_guard:
        return None
    return replace(
        state,
        containment_initiated=True,
        currently_contained=True,
        emergency_safe_stop_used=True,
    )


def preserve_evidence(state: ExitState, mutant: str | None) -> ExitState | None:
    return _set_once(
        state,
        "evidence_preserved",
        currently_contained=state.currently_contained,
    )


def notify_affected_people(state: ExitState, mutant: str | None) -> ExitState | None:
    return _set_once(
        state,
        "affected_people_notified",
        containment_initiated=state.containment_initiated,
    )


def open_remedy(state: ExitState, mutant: str | None) -> ExitState | None:
    containment_guard = (
        state.containment_initiated or mutant == "open_remedy_without_containment"
    )
    return _set_once(state, "remedy_opened", containment=containment_guard)


def record_resolution_collapse_basis(
    state: ExitState, mutant: str | None
) -> ExitState | None:
    if state.retirement_basis != RetirementBasis.UNRECORDED:
        return None
    return replace(state, retirement_basis=RetirementBasis.RESOLUTION_COLLAPSE)


def record_other_authorized_retirement_basis(
    state: ExitState, mutant: str | None
) -> ExitState | None:
    if state.retirement_basis != RetirementBasis.UNRECORDED:
        return None
    return replace(state, retirement_basis=RetirementBasis.OTHER_AUTHORIZED_BASIS)


def record_proper_ending_authority(
    state: ExitState, mutant: str | None
) -> ExitState | None:
    return _set_once(state, "proper_ending_authority_recorded")


def authorize_proper_ending(
    state: ExitState, mutant: str | None
) -> ExitState | None:
    basis_guard = (
        state.retirement_basis != RetirementBasis.UNRECORDED
        or mutant == "authorize_retirement_without_basis"
    )
    authority_guard = (
        state.proper_ending_authority_recorded
        or mutant == "authorize_retirement_without_authority"
    )
    return _set_once(
        state,
        "retirement_decision_authorized",
        basis=basis_guard,
        authority=authority_guard,
    )


def record_function_continuation(state: ExitState, mutant: str | None) -> ExitState | None:
    if state.function_disposition != FunctionDisposition.UNDECIDED:
        return None
    if not state.remedy_opened:
        return None
    return replace(state, function_disposition=FunctionDisposition.CONTINUES)


def record_function_abolition(state: ExitState, mutant: str | None) -> ExitState | None:
    if state.function_disposition != FunctionDisposition.UNDECIDED:
        return None
    if not state.remedy_opened:
        return None
    return replace(state, function_disposition=FunctionDisposition.ABOLISHED)


def record_accepting_successor(state: ExitState, mutant: str | None) -> ExitState | None:
    disposition_guard = (
        state.function_disposition == FunctionDisposition.CONTINUES
        or mutant == "successor_recorded_for_wrong_disposition"
    )
    return _set_once(state, "accepting_successor_recorded", disposition=disposition_guard)


def appoint_residual_custodian(state: ExitState, mutant: str | None) -> ExitState | None:
    disposition_guard = (
        state.function_disposition == FunctionDisposition.ABOLISHED
        or mutant == "custodian_recorded_for_wrong_disposition"
    )
    return _set_once(state, "residual_custodian_recorded", disposition=disposition_guard)


def reconstitute_successor_capacity(state: ExitState, mutant: str | None) -> ExitState | None:
    return _set_once(
        state,
        "successor_operational_capacity_ready",
        continuing=state.function_disposition == FunctionDisposition.CONTINUES,
        successor=state.accepting_successor_recorded,
    )


def assign_open_case_owner(state: ExitState, mutant: str | None) -> ExitState | None:
    owner_ready = (
        (state.accepting_successor_recorded or mutant == "responsibility_without_accepting_successor")
        if state.function_disposition == FunctionDisposition.CONTINUES
        else (state.residual_custodian_recorded or mutant == "responsibility_without_residual_custodian")
        if state.function_disposition == FunctionDisposition.ABOLISHED
        else False
    )
    return _set_once(
        state,
        "open_case_owner_assigned",
        remedy=state.remedy_opened,
        disposition=state.function_disposition != FunctionDisposition.UNDECIDED,
        owner=owner_ready,
    )


def resolve_post_exit_responsibility(
    state: ExitState, mutant: str | None
) -> ExitState | None:
    """Resolve branch-specific responsibility before decommissioning.

    A continuing function requires an accepting successor, operational capacity,
    and an owner for unresolved cases. An abolished function requires a residual
    custodian/remedy authority and an owner for unresolved cases.
    """
    if state.post_exit_responsibility_resolved:
        return None
    if not state.remedy_opened or state.function_disposition == FunctionDisposition.UNDECIDED:
        return None
    owner_guard = state.open_case_owner_assigned or mutant == "responsibility_without_open_case_owner"
    if state.function_disposition == FunctionDisposition.CONTINUES:
        successor_guard = state.accepting_successor_recorded or mutant == "responsibility_without_accepting_successor"
        capacity_guard = state.successor_operational_capacity_ready or mutant == "responsibility_without_successor_capacity"
        if not (successor_guard and capacity_guard and owner_guard):
            return None
    else:
        custodian_guard = state.residual_custodian_recorded or mutant == "responsibility_without_residual_custodian"
        if not (custodian_guard and owner_guard):
            return None
    return replace(state, post_exit_responsibility_resolved=True)


def decommission(state: ExitState, mutant: str | None) -> ExitState | None:
    containment_guard = (
        state.currently_contained
        or mutant == "decommission_without_active_containment"
    )
    retirement_guard = (
        state.retirement_decision_authorized
        or mutant == "decommission_without_retirement_decision"
    )
    preservation_guard = (
        state.evidence_preserved or mutant == "decommission_without_preservation"
    )
    responsibility_guard = (
        state.post_exit_responsibility_resolved
        or mutant == "decommission_without_responsibility"
    )
    return _set_once(
        state,
        "decommissioned",
        currently_contained=containment_guard,
        retirement_decision=retirement_guard,
        preservation=preservation_guard,
        responsibility=responsibility_guard,
    )


def independently_assure(state: ExitState, mutant: str | None) -> ExitState | None:
    decommission_guard = (
        state.decommissioned or mutant == "assure_without_decommission"
    )
    return _set_once(
        state,
        "independently_assured",
        decommissioned=decommission_guard,
    )


def close_exit(state: ExitState, mutant: str | None) -> ExitState | None:
    assurance_guard = (
        state.independently_assured or mutant == "close_without_assurance"
    )
    notice_guard = (
        state.affected_people_notified or mutant == "close_without_notice"
    )
    return _set_once(
        state,
        "closed",
        decommissioned=state.decommissioned,
        assured=assurance_guard,
        notified=notice_guard,
        remedy=state.remedy_opened,
        responsibility=state.post_exit_responsibility_resolved,
    )


def establish_restart_basis(state: ExitState, mutant: str | None) -> ExitState | None:
    return _set_once(
        state,
        "restart_basis_established",
        containment_initiated=state.containment_initiated,
    )


def independently_verify_restart_basis(
    state: ExitState, mutant: str | None
) -> ExitState | None:
    basis_guard = (
        state.restart_basis_established
        or mutant in {
            "release_without_restart_basis",
            "redeploy_without_restart_basis",
        }
    )
    return _set_once(
        state,
        "restart_basis_independently_verified",
        basis=basis_guard,
    )


def approve_containment_release(
    state: ExitState, mutant: str | None
) -> ExitState | None:
    basis_guard = (
        state.restart_basis_established
        or mutant == "release_without_restart_basis"
    )
    verification_guard = (
        state.restart_basis_independently_verified
        or mutant == "release_without_independent_verification"
    )
    fallback_guard = (
        state.fallback_ready or mutant == "release_without_fallback"
    )
    retirement_guard = (
        not state.retirement_decision_authorized
        or mutant == "release_with_active_retirement_decision"
    )
    if state.containment_release_approval_current or state.containment_released:
        return None
    if not (
        state.currently_contained
        and not state.decommissioned
        and basis_guard
        and verification_guard
        and fallback_guard
        and retirement_guard
    ):
        return None
    return replace(
        state,
        containment_release_approval_recorded=True,
        containment_release_approval_current=True,
    )


def expire_containment_release_approval(
    state: ExitState, mutant: str | None
) -> ExitState | None:
    if state.containment_released or not state.containment_release_approval_current:
        return None
    return replace(state, containment_release_approval_current=False)


def release_containment(state: ExitState, mutant: str | None) -> ExitState | None:
    basis_guard = (
        state.restart_basis_established
        or mutant == "release_without_restart_basis"
    )
    verification_guard = (
        state.restart_basis_independently_verified
        or mutant == "release_without_independent_verification"
    )
    approval_record_guard = (
        state.containment_release_approval_recorded
        or mutant == "release_without_approval_record"
    )
    approval_current_guard = (
        state.containment_release_approval_current
        or mutant in {"release_with_expired_approval", "release_without_approval_record"}
    )
    fallback_guard = (
        state.fallback_ready or mutant == "release_without_fallback"
    )
    retirement_guard = (
        not state.retirement_decision_authorized
        or mutant == "release_with_active_retirement_decision"
    )
    if state.containment_released:
        return None
    if not (
        state.currently_contained
        and not state.decommissioned
        and basis_guard
        and verification_guard
        and approval_record_guard
        and approval_current_guard
        and fallback_guard
        and retirement_guard
    ):
        return None
    valid_at_execution = bool(
        state.containment_release_approval_recorded
        and state.containment_release_approval_current
    )
    no_retirement_decision_at_execution = not state.retirement_decision_authorized
    return replace(
        state,
        currently_contained=False,
        containment_release_approval_current=False,
        containment_release_approval_valid_at_execution=valid_at_execution,
        containment_release_no_retirement_decision_at_execution=no_retirement_decision_at_execution,
        containment_released=True,
    )


def approve_redeployment(state: ExitState, mutant: str | None) -> ExitState | None:
    closure_guard = state.closed or mutant == "redeploy_without_closure"
    basis_guard = (
        state.restart_basis_established
        or mutant == "redeploy_without_restart_basis"
    )
    verification_guard = (
        state.restart_basis_independently_verified
        or mutant == "redeploy_without_independent_verification"
    )
    fallback_guard = (
        state.fallback_ready or mutant == "redeploy_without_fallback"
    )
    if state.redeployment_approval_current or state.redeployed_after_closure:
        return None
    if not (
        closure_guard
        and basis_guard
        and verification_guard
        and fallback_guard
    ):
        return None
    return replace(
        state,
        redeployment_approval_recorded=True,
        redeployment_approval_current=True,
    )


def expire_redeployment_approval(state: ExitState, mutant: str | None) -> ExitState | None:
    if state.redeployed_after_closure or not state.redeployment_approval_current:
        return None
    return replace(state, redeployment_approval_current=False)


def redeploy_after_closure(state: ExitState, mutant: str | None) -> ExitState | None:
    closure_guard = state.closed or mutant == "redeploy_without_closure"
    basis_guard = (
        state.restart_basis_established
        or mutant == "redeploy_without_restart_basis"
    )
    verification_guard = (
        state.restart_basis_independently_verified
        or mutant == "redeploy_without_independent_verification"
    )
    approval_record_guard = (
        state.redeployment_approval_recorded
        or mutant == "redeploy_without_approval_record"
    )
    approval_current_guard = (
        state.redeployment_approval_current
        or mutant in {
            "redeploy_with_expired_approval",
            "redeploy_without_approval_record",
        }
    )
    fallback_guard = (
        state.fallback_ready or mutant == "redeploy_without_fallback"
    )
    if state.redeployed_after_closure:
        return None
    if not (
        closure_guard
        and basis_guard
        and verification_guard
        and approval_record_guard
        and approval_current_guard
        and fallback_guard
    ):
        return None
    valid_at_execution = bool(
        state.redeployment_approval_recorded
        and state.redeployment_approval_current
    )
    return replace(
        state,
        redeployment_approval_current=False,
        redeployment_approval_valid_at_execution=valid_at_execution,
        redeployed_after_closure=True,
    )


EXIT_TRANSITIONS: tuple[tuple[str, Transition], ...] = (
    ("prepare_fallback", prepare_fallback),
    ("authorize_emergency_safe_stop", authorize_emergency_safe_stop),
    ("contain_service_preserving", contain_service_preserving),
    ("contain_emergency_safe_stop", contain_emergency_safe_stop),
    ("preserve_evidence", preserve_evidence),
    ("notify_affected_people", notify_affected_people),
    ("open_remedy", open_remedy),
    ("record_resolution_collapse_basis", record_resolution_collapse_basis),
    (
        "record_other_authorized_retirement_basis",
        record_other_authorized_retirement_basis,
    ),
    ("record_proper_ending_authority", record_proper_ending_authority),
    ("authorize_proper_ending", authorize_proper_ending),
    ("record_function_continuation", record_function_continuation),
    ("record_function_abolition", record_function_abolition),
    ("record_accepting_successor", record_accepting_successor),
    ("appoint_residual_custodian", appoint_residual_custodian),
    ("reconstitute_successor_capacity", reconstitute_successor_capacity),
    ("assign_open_case_owner", assign_open_case_owner),
    ("resolve_post_exit_responsibility", resolve_post_exit_responsibility),
    ("decommission", decommission),
    ("independently_assure", independently_assure),
    ("close", close_exit),
    ("establish_restart_basis", establish_restart_basis),
    ("independently_verify_restart_basis", independently_verify_restart_basis),
    ("approve_containment_release", approve_containment_release),
    ("expire_containment_release_approval", expire_containment_release_approval),
    ("release_containment", release_containment),
    ("approve_redeployment", approve_redeployment),
    ("expire_redeployment_approval", expire_redeployment_approval),
    ("redeploy_after_closure", redeploy_after_closure),
)


def exit_invariant_violations(state: ExitState) -> list[str]:
    violations: list[str] = []
    if state.currently_contained and not state.containment_initiated:
        violations.append("current_containment_requires_initiation")
    if state.currently_contained and state.containment_released:
        violations.append("released_containment_cannot_remain_current")
    if state.containment_initiated and not (
        state.fallback_ready or state.emergency_safe_stop_used
    ):
        violations.append("containment_requires_fallback_or_authorized_emergency_path")
    if state.emergency_safe_stop_used and not state.emergency_safe_stop_authorized:
        violations.append("emergency_safe_stop_requires_recorded_authority")
    if state.remedy_opened and not state.containment_initiated:
        violations.append("remedy_initiation_requires_containment_history")
    if state.retirement_decision_authorized and not (
        state.retirement_basis != RetirementBasis.UNRECORDED
        and state.proper_ending_authority_recorded
    ):
        violations.append("retirement_requires_recorded_basis_and_authority")
    if state.accepting_successor_recorded and state.function_disposition != FunctionDisposition.CONTINUES:
        violations.append("accepting_successor_requires_continuing_function")
    if state.residual_custodian_recorded and state.function_disposition != FunctionDisposition.ABOLISHED:
        violations.append("residual_custodian_requires_abolished_function")
    if state.successor_operational_capacity_ready and not (
        state.function_disposition == FunctionDisposition.CONTINUES
        and state.accepting_successor_recorded
    ):
        violations.append("successor_capacity_requires_accepting_successor")
    if state.open_case_owner_assigned and not (
        state.remedy_opened
        and (
            (state.function_disposition == FunctionDisposition.CONTINUES and state.accepting_successor_recorded)
            or (state.function_disposition == FunctionDisposition.ABOLISHED and state.residual_custodian_recorded)
        )
    ):
        violations.append("open_case_owner_requires_branch_appropriate_owner")
    if state.post_exit_responsibility_resolved:
        common = state.remedy_opened and state.open_case_owner_assigned
        if state.function_disposition == FunctionDisposition.CONTINUES:
            branch = state.accepting_successor_recorded and state.successor_operational_capacity_ready
        elif state.function_disposition == FunctionDisposition.ABOLISHED:
            branch = state.residual_custodian_recorded
        else:
            branch = False
        if not (common and branch):
            violations.append("post_exit_responsibility_requires_branch_specific_owner_capacity_and_case_ownership")
    if state.decommissioned and not (
        state.currently_contained
        and state.retirement_decision_authorized
        and state.evidence_preserved
        and state.post_exit_responsibility_resolved
    ):
        violations.append(
            "decommission_requires_current_containment_retirement_preservation_and_post_exit_responsibility"
        )
    if state.independently_assured and not state.decommissioned:
        violations.append("assurance_requires_decommissioning")
    if state.closed and not (
        state.decommissioned
        and state.independently_assured
        and state.affected_people_notified
        and state.remedy_opened
        and state.post_exit_responsibility_resolved
    ):
        violations.append("closure_requires_assurance_notice_remedy_and_post_exit_responsibility")
    if (
        state.restart_basis_independently_verified
        and not state.restart_basis_established
    ):
        violations.append("restart_verification_requires_established_basis")
    if state.containment_release_approval_current and not (
        state.containment_release_approval_recorded
        and not state.containment_released
    ):
        violations.append("current_release_approval_requires_record_and_pre_execution_state")
    if state.containment_release_approval_valid_at_execution and not state.containment_released:
        violations.append("release_approval_execution_witness_requires_release")
    if (
        state.containment_release_no_retirement_decision_at_execution
        and not state.containment_released
    ):
        violations.append("release_retirement_execution_witness_requires_release")
    if state.containment_released and not (
        state.containment_initiated
        and not state.currently_contained
        and state.restart_basis_established
        and state.restart_basis_independently_verified
        and state.containment_release_approval_recorded
        and state.containment_release_approval_valid_at_execution
        and state.containment_release_no_retirement_decision_at_execution
        and state.fallback_ready
    ):
        violations.append(
            "temporary_release_requires_restart_basis_verification_valid_execution_approval_fallback_and_no_retirement_decision"
        )
    if state.redeployment_approval_current and not (
        state.redeployment_approval_recorded
        and not state.redeployed_after_closure
    ):
        violations.append("current_redeployment_approval_requires_record_and_pre_execution_state")
    if state.redeployment_approval_valid_at_execution and not state.redeployed_after_closure:
        violations.append("redeployment_approval_execution_witness_requires_redeployment")
    if state.redeployed_after_closure and not (
        state.closed
        and state.restart_basis_established
        and state.restart_basis_independently_verified
        and state.redeployment_approval_recorded
        and state.redeployment_approval_valid_at_execution
        and state.fallback_ready
    ):
        violations.append(
            "redeployment_requires_closure_restart_basis_verification_valid_execution_approval_and_fallback"
        )
    return violations


def explore_exit_protocol(mutant: str | None = None) -> dict[str, object]:
    initial = ExitState()
    queue: deque[ExitState] = deque([initial])
    path: dict[ExitState, tuple[str, ...]] = {initial: ()}
    transition_count = 0
    first_violation: dict[str, object] | None = None

    while queue:
        state = queue.popleft()
        for action, transition in EXIT_TRANSITIONS:
            next_state = transition(state, mutant)
            if next_state is None or next_state == state:
                continue
            transition_count += 1
            trace = path[state] + (action,)
            violations = exit_invariant_violations(next_state)
            if violations and first_violation is None:
                serialized = asdict(next_state)
                serialized["function_disposition"] = next_state.function_disposition.value
                serialized["retirement_basis"] = next_state.retirement_basis.value
                first_violation = {
                    "trace": list(trace),
                    "violations": violations,
                    "state": serialized,
                }
            if next_state not in path:
                path[next_state] = trace
                queue.append(next_state)

    return {
        "reachable_state_count": len(path),
        "explored_transition_count": transition_count,
        "invariant_violation_count": 0 if first_violation is None else 1,
        "minimal_counterexample": first_violation,
    }


CRITICAL_GUARD_MUTATIONS: tuple[str, ...] = (
    "service_containment_without_fallback",
    "emergency_containment_without_authority",
    "open_remedy_without_containment",
    "authorize_retirement_without_basis",
    "authorize_retirement_without_authority",
    "successor_recorded_for_wrong_disposition",
    "custodian_recorded_for_wrong_disposition",
    "responsibility_without_accepting_successor",
    "responsibility_without_successor_capacity",
    "responsibility_without_residual_custodian",
    "responsibility_without_open_case_owner",
    "decommission_without_active_containment",
    "decommission_without_retirement_decision",
    "decommission_without_preservation",
    "decommission_without_responsibility",
    "assure_without_decommission",
    "close_without_assurance",
    "close_without_notice",
    "release_without_restart_basis",
    "release_without_independent_verification",
    "release_without_approval_record",
    "release_with_expired_approval",
    "release_without_fallback",
    "release_with_active_retirement_decision",
    "redeploy_without_closure",
    "redeploy_without_restart_basis",
    "redeploy_without_independent_verification",
    "redeploy_without_approval_record",
    "redeploy_with_expired_approval",
    "redeploy_without_fallback",
)


def check_exit_protocol() -> dict[str, object]:
    baseline = explore_exit_protocol()
    counterexamples = {
        mutant: explore_exit_protocol(mutant)["minimal_counterexample"]
        for mutant in CRITICAL_GUARD_MUTATIONS
    }
    return {
        "method": "breadth_first_exhaustive_state_exploration",
        "state_semantics": (
            "selected finite event-and-authorization abstraction with three-valued "
            "retirement-basis and function-disposition fields; separate historical/current "
            "containment; and separate pre-execution approval currentness and valid-at-execution witnesses"
        ),
        "critical_guard_mutation_count": len(CRITICAL_GUARD_MUTATIONS),
        "critical_guard_mutations": list(CRITICAL_GUARD_MUTATIONS),
        "dominance_note": (
            "Notice, remedy, and branch-appropriate responsibility are rechecked at closure but are "
            "also upstream prerequisites of decommissioning in this abstraction. Their closure-level "
            "checks are defense in depth and are not misreported as independently mutation-adequate guards."
        ),
        **baseline,
        "mutant_counterexamples": counterexamples,
    }

def render_markdown(results: dict[str, object]) -> str:
    gate = results["part_i_typed_gate_contract"]
    exit_protocol = results["part_iii_exit_protocol"]
    lines = [
        "# Formal protocol check results",
        "",
        "These results establish internal consistency only. They do not estimate "
        "real-world effectiveness, prevalence, or causal effects.",
        "",
        "## Part I: typed gate contract",
        "",
        f"- Stage-1 configurations exhaustively enumerated: {gate['stage_1_configuration_count']:,}",
        f"- Stage-1 safety-invariant violations: {gate['stage_1_invariant_violation_count']}",
        "- Stage-1 routing counts: "
        + ", ".join(
            f"{name}={count:,}"
            for name, count in gate["stage_1_routing_counts"].items()
        ),
        f"- Stage-2 configurations exhaustively enumerated: {gate['stage_2_configuration_count']:,}",
        f"- Stage-2 safety-invariant violations: {gate['stage_2_invariant_violation_count']}",
        "- Stage-2 disposition counts: "
        + ", ".join(
            f"{name}={count:,}"
            for name, count in gate["stage_2_disposition_counts"].items()
        ),
        "",
        f"- Guard mutations with standalone counterexamples: {gate['guard_mutation_count']}",
        "",
    ]

    lines.extend(
        [
            "",
            "## Part III: selected proper-ending and authority-return guard abstraction",
            "",
            f"- Reachable states: {exit_protocol['reachable_state_count']:,}",
            f"- Enabled transitions explored: {exit_protocol['explored_transition_count']:,}",
            f"- Safety-invariant violations under the unmutated abstraction: "
            f"{exit_protocol['invariant_violation_count']}",
            "",
            "Minimal counterexamples after deliberate guard removal:",
            "",
            "| Disabled guard | Minimal action trace | Violation |",
            "|---|---|---|",
        ]
    )
    for mutant, counterexample in exit_protocol["mutant_counterexamples"].items():
        if counterexample is None:
            lines.append(f"| {mutant} | none found | none found |")
        else:
            lines.append(
                f"| {mutant} | {' → '.join(counterexample['trace'])} | "
                f"{'; '.join(counterexample['violations'])} |"
            )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path(__file__).parent / "results")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    results = {
        "scope_note": (
            "Finite-state internal safety verification of a selected Part III "
            "guard abstraction; the model omits lawful authorization and the full "
            "institutional semantics of transfer, learning, and closure. The "
            "invariants and mutations derive from the same authored specification. "
            "No completeness, legal-sufficiency, external-validity, predictive-"
            "validity, prevalence, or causal-effect claim."
        ),
        "part_i_typed_gate_contract": check_gate_contract_v59(),
        "part_iii_exit_protocol": check_exit_protocol(),
    }
    (args.out / "formal_protocol_results.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (args.out / "formal_protocol_results.md").write_text(
        render_markdown(results), encoding="utf-8"
    )
    print(render_markdown(results))


if __name__ == "__main__":
    main()
