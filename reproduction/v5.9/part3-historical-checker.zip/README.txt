Historical v5.9 finite-state checker (recovered 2026-11-24)

Python 3.13.5 was used for the byte-identical re-execution. No third-party packages are required.
Run: python formal_protocol_checks.py --out rerun
Expected output SHA-256:
30608277c7c8f1ede88e86699674ac4679ad7a2cf0a36ebd3c2d5507928ef952  rerun/formal_protocol_results.json
51e21af27021d1b94e20ff1b0f4f699c807f9a31303713217ba77d7a40fb6e5e  rerun/formal_protocol_results.md
Historical source SHA-256:
ca82fc325fce1ddac2dcbcc407fe3eaa96892914855decc961ab220caebc0c7d  formal_protocol_checks.py
This subset is not the full v5.9 reproducibility package. It includes Part I v5.9, NOT the Part I v6.2 reimplementation. Part III v6.2 carries forward the v5.9 results. It does not reproduce the synthetic benchmark or sensitivity grid and does not establish independent replication or field effectiveness. The checker and MIT license are unchanged.
