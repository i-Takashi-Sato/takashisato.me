#!/usr/bin/env bash
# Reproduce every verification result reported in the v6.3 trilogy.
# Requirements: Python >= 3.11 (standard library only). Quick mode ~5-10 min; FULL=1 adds the
# full re-diagnosis comparison and the 134-variant PE-R1 mutation suite (~1 h on 2 cores; resumable).
# The script exits non-zero if any required artifact is missing or differs.
set -euo pipefail
cd "$(dirname "$0")"
OUT=${OUT:-results/rerun}
mkdir -p "$OUT"
py() { python3 -I "$@"; }

echo "[Part I] typed routing/disposition/guard (two-encoding conformance)"
py code/part1/part1_v63_candidate.py            > "$OUT/part1_v63_candidate.json"
echo "[Part I] acceptance probes and targeted mutants"
py code/part1/part1_acceptance.py               > "$OUT/part1_acceptance.json"
echo "[Part I] Gate-3 regression against review candidate 0.3"
py code/part1/gate3_regression.py               > "$OUT/gate3_regression.json"
echo "[Part I] integrated static/temporal model (about 3 min)"
py code/part1/part1_integrated_model.py         > "$OUT/part1_integrated_model.json"
echo "[Part II] 81-profile GCL-PC classification"
py code/part2/part2_v63_classification.py "$OUT/part2_profiles.csv" > "$OUT/part2_v63_classification.json"
echo "[Part III] historical replica M0 and PE-R1 baseline exploration"
py code/part3/part3_baseline_check.py code/part3/audit_package > "$OUT/part3_baseline_check.json"
echo "[Part III] historical v5.9 checker (byte-identical source; outputs must match the recorded hashes)"
py code/part3/audit_package/historical/formal_protocol_checks.py --out "$OUT/part3_historical" > /dev/null
MODE=quick
if [[ "${FULL:-0}" == "1" ]]; then
  MODE=full
  echo "[Part I] full re-diagnosis comparison for the integrated model (DECISIONS D4)"
  py code/part1/part1_fulldiagnose_check.py > "$OUT/part1_fulldiagnose_check.json"
  echo "[Part III] PE-R1 mutation suite (resumable; rerun the script if interrupted)"
  until py code/part3/part3_mutation_rerun.py code/part3/audit_package "$OUT/part3_mutation" --budget 1e9; do
    echo "  partial; resuming"; done
fi
echo "Comparing with recorded results"
py code/compare_results.py results/recorded "$OUT" --mode "$MODE"
echo "Text-code consistency (headline numbers in the manuscripts vs recorded results)"
py code/text_code_consistency.py manuscripts results/recorded
