# Formal protocol check results

These results establish internal consistency only. They do not estimate real-world effectiveness, prevalence, or causal effects.

## Part I: typed gate contract

- Stage-1 configurations exhaustively enumerated: 1,024
- Stage-1 safety-invariant violations: 0
- Stage-1 routing counts: EXECUTION_ELIGIBLE=16, UNRESOLVED=567, FALLBACK=189, AUTHORIZED_REVIEW=104, EVIDENCE_HOLD=148
- Stage-2 configurations exhaustively enumerated: 1,248
- Stage-2 safety-invariant violations: 0
- Stage-2 disposition counts: AUTHORIZED_REVIEW=728, RELEASE=104, MODIFIED_ACTION=104, FINAL_STOP=104, EVIDENCE_HOLD=104, UNRESOLVED=78, FALLBACK=26

- Guard mutations with standalone counterexamples: 8


## Part III: selected proper-ending and authority-return guard abstraction

- Reachable states: 8,564
- Enabled transitions explored: 36,096
- Safety-invariant violations under the unmutated abstraction: 0

Minimal counterexamples after deliberate guard removal:

| Disabled guard | Minimal action trace | Violation |
|---|---|---|
| service_containment_without_fallback | contain_service_preserving | containment_requires_fallback_or_authorized_emergency_path |
| emergency_containment_without_authority | contain_emergency_safe_stop | emergency_safe_stop_requires_recorded_authority |
| open_remedy_without_containment | open_remedy | remedy_initiation_requires_containment_history |
| authorize_retirement_without_basis | record_proper_ending_authority → authorize_proper_ending | retirement_requires_recorded_basis_and_authority |
| authorize_retirement_without_authority | record_resolution_collapse_basis → authorize_proper_ending | retirement_requires_recorded_basis_and_authority |
| successor_recorded_for_wrong_disposition | record_accepting_successor | accepting_successor_requires_continuing_function |
| custodian_recorded_for_wrong_disposition | appoint_residual_custodian | residual_custodian_requires_abolished_function |
| responsibility_without_accepting_successor | prepare_fallback → contain_service_preserving → open_remedy → record_function_continuation → assign_open_case_owner | open_case_owner_requires_branch_appropriate_owner |
| responsibility_without_successor_capacity | prepare_fallback → contain_service_preserving → open_remedy → record_function_continuation → record_accepting_successor → assign_open_case_owner → resolve_post_exit_responsibility | post_exit_responsibility_requires_branch_specific_owner_capacity_and_case_ownership |
| responsibility_without_residual_custodian | prepare_fallback → contain_service_preserving → open_remedy → record_function_abolition → assign_open_case_owner | open_case_owner_requires_branch_appropriate_owner |
| responsibility_without_open_case_owner | prepare_fallback → contain_service_preserving → open_remedy → record_function_abolition → appoint_residual_custodian → resolve_post_exit_responsibility | post_exit_responsibility_requires_branch_specific_owner_capacity_and_case_ownership |
| decommission_without_active_containment | prepare_fallback → contain_service_preserving → preserve_evidence → open_remedy → record_resolution_collapse_basis → record_proper_ending_authority → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → establish_restart_basis → independently_verify_restart_basis → approve_containment_release → release_containment → authorize_proper_ending → decommission | decommission_requires_current_containment_retirement_preservation_and_post_exit_responsibility |
| decommission_without_retirement_decision | prepare_fallback → contain_service_preserving → preserve_evidence → open_remedy → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → decommission | decommission_requires_current_containment_retirement_preservation_and_post_exit_responsibility |
| decommission_without_preservation | prepare_fallback → contain_service_preserving → open_remedy → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → decommission | decommission_requires_current_containment_retirement_preservation_and_post_exit_responsibility |
| decommission_without_responsibility | prepare_fallback → contain_service_preserving → preserve_evidence → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → decommission | decommission_requires_current_containment_retirement_preservation_and_post_exit_responsibility |
| assure_without_decommission | independently_assure | assurance_requires_decommissioning |
| close_without_assurance | prepare_fallback → contain_service_preserving → preserve_evidence → notify_affected_people → open_remedy → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → decommission → close | closure_requires_assurance_notice_remedy_and_post_exit_responsibility |
| close_without_notice | prepare_fallback → contain_service_preserving → preserve_evidence → open_remedy → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → decommission → independently_assure → close | closure_requires_assurance_notice_remedy_and_post_exit_responsibility |
| release_without_restart_basis | independently_verify_restart_basis | restart_verification_requires_established_basis |
| release_without_independent_verification | prepare_fallback → contain_service_preserving → establish_restart_basis → approve_containment_release → release_containment | temporary_release_requires_restart_basis_verification_valid_execution_approval_fallback_and_no_retirement_decision |
| release_without_approval_record | prepare_fallback → contain_service_preserving → establish_restart_basis → independently_verify_restart_basis → release_containment | temporary_release_requires_restart_basis_verification_valid_execution_approval_fallback_and_no_retirement_decision |
| release_with_expired_approval | prepare_fallback → contain_service_preserving → establish_restart_basis → independently_verify_restart_basis → approve_containment_release → expire_containment_release_approval → release_containment | temporary_release_requires_restart_basis_verification_valid_execution_approval_fallback_and_no_retirement_decision |
| release_without_fallback | authorize_emergency_safe_stop → contain_emergency_safe_stop → establish_restart_basis → independently_verify_restart_basis → approve_containment_release → release_containment | temporary_release_requires_restart_basis_verification_valid_execution_approval_fallback_and_no_retirement_decision |
| release_with_active_retirement_decision | prepare_fallback → contain_service_preserving → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → establish_restart_basis → independently_verify_restart_basis → approve_containment_release → release_containment | temporary_release_requires_restart_basis_verification_valid_execution_approval_fallback_and_no_retirement_decision |
| redeploy_without_closure | prepare_fallback → contain_service_preserving → establish_restart_basis → independently_verify_restart_basis → approve_redeployment → redeploy_after_closure | redeployment_requires_closure_restart_basis_verification_valid_execution_approval_and_fallback |
| redeploy_without_restart_basis | independently_verify_restart_basis | restart_verification_requires_established_basis |
| redeploy_without_independent_verification | prepare_fallback → contain_service_preserving → preserve_evidence → notify_affected_people → open_remedy → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → decommission → independently_assure → close → establish_restart_basis → approve_redeployment → redeploy_after_closure | redeployment_requires_closure_restart_basis_verification_valid_execution_approval_and_fallback |
| redeploy_without_approval_record | prepare_fallback → contain_service_preserving → preserve_evidence → notify_affected_people → open_remedy → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → decommission → independently_assure → close → establish_restart_basis → independently_verify_restart_basis → redeploy_after_closure | redeployment_requires_closure_restart_basis_verification_valid_execution_approval_and_fallback |
| redeploy_with_expired_approval | prepare_fallback → contain_service_preserving → preserve_evidence → notify_affected_people → open_remedy → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → decommission → independently_assure → close → establish_restart_basis → independently_verify_restart_basis → approve_redeployment → expire_redeployment_approval → redeploy_after_closure | redeployment_requires_closure_restart_basis_verification_valid_execution_approval_and_fallback |
| redeploy_without_fallback | authorize_emergency_safe_stop → contain_emergency_safe_stop → preserve_evidence → notify_affected_people → open_remedy → record_resolution_collapse_basis → record_proper_ending_authority → authorize_proper_ending → record_function_abolition → appoint_residual_custodian → assign_open_case_owner → resolve_post_exit_responsibility → decommission → independently_assure → close → establish_restart_basis → independently_verify_restart_basis → approve_redeployment → redeploy_after_closure | redeployment_requires_closure_restart_basis_verification_valid_execution_approval_and_fallback |
