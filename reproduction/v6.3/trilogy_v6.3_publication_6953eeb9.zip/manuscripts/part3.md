---
title: "From Governance Drift to Accountable Exit"
subtitle: "Proper Ending and Authority Return in AI-Assisted Institutions"
author: "Takashi Sato"
part: "Workflow-Centric AI Governance Trilogy · Part III"
version: "Working Paper · Version 6.3"
date: "November 2026"
doi: "SSRN DOI 10.2139/ssrn.6066430"
runninghead: "GOVERNANCE DRIFT TO ACCOUNTABLE EXIT"
---

# Abstract {.unnumbered}

An AI-assisted workflow can remain technically available and procedurally complete after its institution has lost the independent judgment, corrective voice, and practical authority needed to govern it. Monitoring alone cannot resolve that failure. Institutions also need a lawful path from weak signals through investigation and reversible containment to retirement that preserves remedy and assigns decision capacity or residual responsibility. Proper Ending and Authority Return specify that path, keeping signals, research classifications, authorized determinations, containment, retirement, decommissioning, transfer and closure distinct. Closure requires preserved evidence, notice, a secured remedy route, an owner for every open case, and branch-specific post-exit responsibility: an accepting successor if the decision function continues, a residual custodian if it ends. Temporary release from containment and redeployment after closure carry distinct burdens. A finite model of events and authorization tests selected safety guards and whether closure remains reachable. The historical guard model (8,564 states and 36,096 transitions, with no safety violation) is retained unchanged; a follow-up audit finds 1,152 states with no path to closure, including 288 retirement-authorized states stranded after temporary release: safety held while authorized progress was impossible. The revised candidate PE-R1 permits one bounded re-containment and separates historical records from current assessments; its 98,948 reachable states contain no safety violation and no state from which closure is unreachable. These results establish properties of an abstraction, not lawful authority, effective remedy, unrestricted repeated episodes, or real-world safety. Fifteen evidence units from three official investigations of automated decision systems predating generative AI show only external traceability. The proposed Governance Drift Indicators remain subordinate to authorized decisions: they may route investigation but never contain, retire, resume, or redeploy a workflow.

**Keywords:** AI governance; accountable exit; authority return; decommissioning; human oversight; organizational silence; proper ending; remedy

# Introduction

AI-governance frameworks often emphasize entry: they specify impact assessment, documentation, approval, monitoring, and human oversight. Operational failure, however, raises a different question. If a workflow can no longer be justified, who may limit it, what must remain available to affected people, where do unresolved cases go, and when can the institution legitimately regard the arrangement as ended? A model can be switched off while its rules persist in queues, records, staffing, vendor interfaces, or downstream decisions. Conversely, a rushed suspension can interrupt essential service, destroy evidence, strand appeals, and shift authority to an unnamed default. Shutdown is therefore a governance transition, not an IT event.

This paper asks how an AI-assisted institution can move from suspected governance drift to accountable exit without granting indicators decision authority. The answer separates five acts that are often collapsed: measurement, investigation, authorization, containment, and institutional closure. Governance Drift Indicators (GDIs) provide defeasible traces of changing information, attention, and voice. A coupled and persistent signal may open an independent investigation. Only a named and legally competent authority may authorize containment or retirement. Proper Ending then requires evidence preservation, notice, remedy, transfer of open cases, decommissioning, assurance, and closure. Authority Return specifies who next holds the practical capacity to decide, explain, correct, and provide resources for the function.

Part I of the trilogy defines a two-stage typed gate contract for accountable human–AI decisions (Sato, 2026a). Part II develops a descriptive profile of governing-capacity loss under procedural continuity (GCL-PC) and a separately specified research question about ordinary organizational exposure (Sato, 2026b). Part III addresses the institutional endpoint left open by those papers. Its contributions are:

1. a transition ontology separating signal, candidate event, incident, containment, Resolution Collapse, Proper Ending, Authority Return, closure, temporary containment release, and post-closure redeployment;

2. an auditable nine-step Proper Ending protocol whose closure conditions include service continuity, remedy, and an accountable owner for every unresolved case;

3. an Authority Return Register that records the destination of decision rights, records, resources, queues, duties, and residual risk;

4. a finite-state abstraction of selected safety-critical transition guards, reported in two layers: the historical guard model with its exhaustive safety exploration and mutation counterexamples, and a revised candidate (PE-R1) that repairs a closure-reachability defect found in the historical model by a follow-up audit;

5. a theory-directed set of fifteen public-record traceability illustrations from three official investigations, used to demonstrate inspectable external examples rather than estimate observability, prevalence, or effect; and

6. three aggregate GDI families, one fixed illustrative subgroup rule, and a synthetic stress test that demonstrate implementability and failure modes without claiming deployment validity.

The central contribution is the specification of Proper Ending and Authority Return in Sections 7–10, together with a formal model of selected transition guards. Detailed GDI construction, sensitivity, and benchmark material appears in Technical Appendix B; the main text retains only the decision boundary and principal failure-mode results. A GDI operating point that fails or is retired must be replaced; this does not invalidate the need for accountable exit. Conversely, a successful detector cannot acquire authority to order that exit.

The claims are deliberately limited. The paper does not show that the indicators predict incidents, that the exit protocol would have prevented any documented harm, or that its sequence is legally sufficient in every jurisdiction. Formal verification answers whether the stated guards logically prevent the stated unsafe transitions within the model and whether closure remains reachable from every authorized state. The public-record illustrations locate selected governance objects in official records, independently of the historical synthetic generator; because case eligibility itself required mechanism coverage, they are not an independent validation sample. The historical synthetic runs examined whether the detector implemented the stated rules and where it failed under declared scenarios; the original generator is not included in this release. Field effectiveness, comparative institutional cost, and legal validity remain open empirical and jurisdiction-specific questions.

## Reader’s map and minimum implementation

The paper distinguishes two related but separable layers. Readers implementing accountable exit should treat Sections 3 and 5–10 as the normative and transition core: no GDI is required to preserve evidence, name a competent authority, maintain remedy, allocate open cases, or return decision capacity. Readers evaluating monitoring should treat Technical Appendix B as a supporting measurement program whose outputs stop at investigation routing. The finite model checks selected safety guards that connect these layers; it does not compress the entire protocol into software. The division also sets a limit on authority: failure of the synthetic detector does not erase the exit obligations, while a statistically attractive detector cannot acquire power to contain, retire, resume, or redeploy the workflow.

# Relation to Existing Work

Evidence hierarchy. Peer-reviewed research, enacted law or published standards, and official investigations anchor established empirical, institutional, and legal-background claims. Recent 2026 preprints, working papers, and standards still under development are used principally to map the current novelty boundary; they do not validate the protocol or GDIs, and their status must be rechecked at each public release.

## Human–AI evaluation and oversight

Accuracy alone is an inadequate measure of human–AI systems. Reliance, complementary competence, safety, and learning require separate measures and trace evidence (Lai et al., 2023; Lee, 2026). A signal-detection perspective likewise shows that oversight effectiveness depends on discriminability, decision criteria, incentives, and base rates (Langer et al., 2025). The dissent construct also sits inside a mature organizational-behavior literature: voice and silence depend on hierarchy, perceived efficacy, psychological safety, retaliation risk, and local climate, so low dissent cannot be attributed to AI influence without competing explanations (Morrison, 2014, 2023). GDIs therefore contribute workflow-level governance traces rather than pure measures of governance quality; they do not replace outcome evaluation or conventional model monitoring, and the prototype does not establish that every proposed trace is available before delayed ground truth.

## Drift detection

Statistical process control and concept-drift research provide methods for detecting distributional change, including cumulative-sum procedures (Page, 1954) and adaptive monitoring (Gama et al., 2014). The problem is different in construct but similar in discipline. A change detector must specify baseline, unit, window, direction, persistence, error tradeoff, and response. GDIs borrow that discipline while targeting governance traces. Because monitoring can change behavior and thresholds can be gamed, statistical alarms remain prompts for causal investigation.

## Rationale quality and faithfulness

Text that sounds specific may not faithfully represent the cause of a model or human decision. Faithfulness and plausibility are distinct (Jacovi & Goldberg, 2020), and rationale benchmarks emphasize task-grounded evidence rather than surface fluency (DeYoung et al., 2020). Language models can also produce persuasive explanations that are unfaithful to their actual reasoning process (Turpin et al., 2023). Accordingly, the proposed rationale metric asks whether a human-authored rationale adds held-out information beyond the model output and declared controls. It does not infer mental states or validate a rationale merely because it is linguistically diverse.

This paper does not use the term semantic entropy. In current machine-learning research it has a specific use for uncertainty over meaning-equivalent model generations (Farquhar et al., 2024). The construct here concerns the incremental information in institutional rationales and differs from that measure.

## Documentation, controllability, and termination

Documentation can support governance when it connects artifacts to decisions, owners, and downstream use; document production alone can also become ritual (Winecoff & Bogen, 2025). NIST AI RMF 1.0 includes safe decommissioning and phasing-out processes and addresses incident response, recovery, appeal, and override across its governance and management outcomes; the separately maintained NIST AI RMF Playbook and the Generative AI Profile provide more specific suggested actions around disengagement, deactivation, escalation, and remediation (National Institute of Standards and Technology [NIST], 2023a, 2023b, 2024). ISO/IEC 42001 specifies an organizational AI management system, ISO/IEC 5338 defines AI-system life-cycle processes, and ISO/IEC 8183 provides a data life-cycle framework (International Organization for Standardization and International Electrotechnical Commission [ISO/IEC], 2023a, 2023b, 2023c). ISO/IEC TS 8200:2024 is still more directly adjacent: it addresses controllability through state observability and transition, control-transfer process and cost, uncertainty during control transfer, and verification and validation (ISO/IEC, 2024). ISO/IEC 42105, which extends TS 8200 with lifecycle guidance on human control and monitoring, had completed its approval stage and was listed as under publication when this version was prepared; it is cited for its declared scope rather than for specific requirements (ISO/IEC, in press). The Australian Government’s AI Technical Standard goes further than a generic lifecycle reference by specifying a decommission stage with planning, impact analysis, service-continuity considerations, stakeholder communication, secure shutdown or repurposing, final documentation, and lessons learned (Digital Transformation Agency [DTA], 2025). Ireland’s National Cyber Security Centre similarly treats end-of-life as part of secure AI adoption. Its 2026 guidance calls for a formal decommissioning plan, termination and handover arrangements, credential and API-key revocation, secure deletion or archival, a final review, third-party confirmation where relevant, and residual-risk assessment; it also makes exit strategy and vendor lock-in explicit lifecycle concerns (National Cyber Security Centre of Ireland, 2026). The EU AI Act requires effective human-oversight capabilities for applicable high-risk systems (European Union, 2024). This paper therefore does not claim to originate life-cycle governance, controllability, control transfer, decommissioning, or human oversight. Its proposed increment is narrower: an institutional termination protocol that treats remedy continuity, ownership of unresolved cases, branch-specific post-exit responsibility (successor acceptance when the function continues; residual custody or remedy authority when it ends), reconstitution or accountable disposition of practical decision capacity, and closure as explicit exit conditions rather than assuming that technical retirement completes governance.

U.S. federal policy also supplies a direct termination comparator. OMB Memorandum M-25-21 requires agencies using high-impact AI to maintain a plan to discontinue use when the system is not performing at an appropriate level and to cease use when proper risk mitigation is not possible (OMB, 2025). That requirement narrows the contribution here further: the novelty claim cannot rest on the proposition that governance should include a discontinue-or-cease-use decision. The proposed increment concerns what institutional closure must preserve and reassign after such a decision—evidence, remedy, unresolved-case ownership, branch-specific responsibility, and practical decision capacity.

## Policy termination, organizational mortality and sunset review

Public-policy research has long treated termination as a political process rather than an administrative afterthought. Bardach (1976) described termination as a contest in which beneficiaries, staff and allied legislators mobilize against closure; Biller (1976) argued that organizations should be designed so that termination can be tolerated; deLeon (1978) explained why public programs and organizations prove so durable; Behn (1978) offered tactical advice to would-be terminators facing that resistance; and Brewer (1978) stressed the hard choices left after a decision to terminate. Later work showed that public agencies are not immortal: in the United States, termination risk is higher after changes in partisan control of government (Lewis, 2002), and reviews of the comparative evidence organize its causes around organizational persistence and political incentives (Adam et al., 2007; Kuipers et al., 2018). Recent work extends the policy-feedback perspective from continuity to the termination of policy instruments (Daugbjerg & Bazzan, 2026).

This literature explains when and why termination happens and why it is resisted. Proper Ending addresses a narrower and later question: once a competent authority has decided to retire an AI-assisted workflow, what must the exit preserve? Three findings of termination research bear directly on the protocol and are consistent with its design, although the design was not derived from them. Operators and beneficiaries of a workflow often have a stake in its continuation; the protocol therefore requires a deciding authority independent of the operating chain (Section 8.1). Termination without transition support shifts costs to affected people; remedy routes and case ownership are therefore closure conditions. Responsibilities outlive the terminated unit; post-exit responsibility is therefore branch-specific and survives closure.

Sunset legislation offers a contrasting institutional design. Under the Texas Sunset Act, an agency subject to the Act is abolished on a statutory date unless the legislature continues it, typically for twelve years, after review by the Sunset Advisory Commission (Texas Government Code ch. 325; Sunset Advisory Commission, 2025). An abolished agency may continue for one year to conclude its business, its unobligated appropriations then lapse, and the governor may designate another agency to administer any law that remains in effect (Texas Government Code §325.017). Sunset review is time-triggered and requires continuation to be justified; Proper Ending is triggered by evidence, investigation and authorization, and requires termination to be justified. The two are complementary rather than rival. Periodic reauthorization can force a review that anomaly-triggered processes might never start, and evidence on governing capacity can inform such a review. Conversely, the closure conditions specified here (preserved records, notice, remedy, case ownership and residual custody) can be written into a sunset wind-down, which in Texas is specified mainly in terms of concluding business and reassigning remaining legal functions.

## Directly adjacent frameworks and the incremental boundary

Gaube et al. (2026) already provide an architecture, process model, roles, and documentation template for effective human oversight. Langer et al. (2026) already argue that oversight compliance testing must progress beyond checklists toward context-sensitive empirical evaluation. Manheim and Homewood (2025) distinguish oversight from control and emphasize the limits of deployment controls, while Ditz et al. (2026) analyze secure oversight through socio-technical threat modeling. Bhatt and Sargeant (2024) propose algorithmic resignation as deliberate, informed disengagement during use. Frimpong (2026b) defines post-withdrawal socio-technical residue and proposes an AI Debris Decommissioning Protocol addressing decision footprints, incident review, remediation, contestability, and accountability assignment. Popchanovska et al. (2026) derive a real-world AI-risk-mitigation taxonomy from incident reports that includes system or feature withdrawal, access limitations, incident investigation, compensation, and supportive measures. That work confirms that restriction and withdrawal are recurring response categories, but it does not specify when an institution has completed a remedy-preserving transfer of decision capacity or may lawfully return a closed workflow to service. Public-sector accountability research already examines automated systems across development, procurement, use, impact, and decommissioning, and policy research documents accountability tools such as prohibitions, moratoria, appeal rights, audits, and oversight bodies (Baykurt, 2022; Ada Lovelace Institute, AI Now Institute, and Open Government Partnership [OGP], 2021). This paper therefore does not claim to originate human-oversight architecture, monitoring, deliberate disengagement, deactivation, recourse, post-withdrawal accountability, life-cycle governance, threat modeling, or decommissioning.

Peer-reviewed 2026 work makes the operational-control boundary still tighter. Zhu et al. (2026) provide layered human evaluative agency, structured rationales, circuit breakers, appeal bundles, and end-to-end oversight design patterns. Calboreanu (2026) supplies deterministic policy-as-code gates, execution authorization, escalation, and cryptographic audit for autonomous-agent operations. Proper Ending therefore does not claim novelty for circuit breakers, gated execution, audit trails, or implementable oversight patterns. Its remaining candidate contribution is the institutional exit layer that begins after or around those controls: a trace-to-authority boundary, remedy-preserving partial order, branch-specific post-exit responsibility, explicit Authority Return, and different burdens for temporary release and post-closure redeployment.

Its narrower proposed contribution is a trace-to-transition system: (1) three separately invalidatable governance-trace families with explicit latency and invalidity conditions; (2) an evidentiary grammar that blocks language-plus-time-only containment; (3) an ontology separating signal, candidate, incident, Resolution Collapse, and retirement; (4) a guard-constrained, partially ordered Proper Ending that treats remedy and service continuity as closure conditions; (5) an Authority Return Register for transferring actual decision capacity and unresolved cases; and (6) distinct burdens for temporary containment release and post-closure redeployment. Relative to algorithmic resignation, the focus is institutional closure rather than an in-use restriction or disclaimer. Relative to AI Debris, the incremental specification is the upstream trace-to-authority boundary together with executable closure guards, ownership of unresolved cases, an explicit Authority Return Register, and separate release-versus-redeployment burdens. These elements remain conceptual until field-tested. Recent 2026 work narrows the novelty boundary further. Niu (2026) describes a “chancellorization” failure in which formal authority remains downstream while effective governing capacity migrates to intermediary layers controlling information routing, drafting defaults, and evaluative signals. Havyarimana (2026) similarly distinguishes formal human authority from the practical governing capacity to frame, contest, intervene, reconstruct, remedy, and continue essential functions when AI governs in practice. Shu and Wei (2026) formalize sovereignty boundaries around irreversible decision authority, critical-resource mobilization, and self-expansion. These works mean that this paper cannot claim novelty for the diagnosis that formal authority may persist while practical governing capacity hollows out. Its proposed increment is narrower: operationalizing accountable exit through a partially ordered closure protocol that joins remedy continuity, post-exit responsibility, capacity reconstitution, evidence preservation, and bounded return to service. Recent 2026 work also narrows the neighboring lifecycle boundary. Ferrario (2026) proposes auditable trustworthiness levels with explicit lifecycle monitoring, reassessment, readable level transitions, human responsibilities, and control gates. Solozobov (2026) studies label-free governance-evidence degradation under delayed ground truth and explicitly distinguishes detectable proxy degradation from blind spots that require labels. Wang (2026) locates final authority over high-impact organizational actions with the deploying and consequence-bearing organization and proposes a portable governance layer. Burnat and Davidson (2026) model auditability, switching costs, vendor lock-in, and portability as determinants of post-deployment accountability. Han (2026) shows, in a FinTech setting, that provider-side releases and control surfaces can constrain historical verification and motivates evidence-contingent delegation. These papers do not supply the same institutional termination sequence proposed here, but they substantially overlap its neighboring terrain. Proper Ending must therefore be evaluated as an integration and closure specification, not as a claim that monitoring, control transfer, final authority, portability, or lifecycle transitions were previously absent. The 2026 OECD Due Diligence Guidance for Responsible AI further narrows the lifecycle claim: it expressly contemplates temporary or permanent suspension, a process for authorising redeployment, extensive testing and validation before recovery, and decommissioning when fixes are not sufficiently robust (OECD, 2026). Obimakinde (2026) likewise proposes an AI Sunset Protocol for high-dependency systems built around dependency-impact assessment, notification and referral, contextual asset transfer, and phased degradation. These sources preclude a claim that suspension/redeployment governance, dependency-aware de-integration, or phased AI shutdown originates here. The proposed increment remains the trace-to-authority boundary and the closure-specific combination of remedy continuity, unresolved-case ownership, branch-specific successor or residual responsibility, explicit Authority Return, and separate burdens for temporary containment release versus post-closure redeployment.

Recent work on human understanding, update opacity, governance inversion, and interpretive continuity is directly adjacent. A minimum cognitive-integrity threshold identifies the comprehension required for verification and intervention (Lin et al., 2026). Update opacity explains how system change can make previously acquired calibration unusable under real role and time constraints (Ferrario & Hatherley, 2026). Governance inversion describes how added formalization can reduce operational control through fragmented authority and symbolic governance (Frimpong, 2026a). The “khipu problem” shows why preserved logs are insufficient when institutions lose the practice required to interpret distributed cognitive episodes (Tallam, 2026). GDIs do not measure or solve these constructs. At most, they provide candidate traces that should be investigated alongside direct measures of comprehension, update accessibility, authority coherence, and interpretive continuity.

| Existing control family | Established control | Additional specification proposed here | Unestablished claim |
|---|---|---|---|
| Effective human oversight | architecture, process, roles, documentation | coupled governance-trace detector linked to institutional transitions | detector validity and workflow benefit |
| Oversight, control, and threat modeling | distinctions among monitoring, intervention capacity, and socio-technical attack surfaces | candidate-to-authority boundary, validity holds, and anti-gaming tests for governance traces | comparative security or resilience benefit |
| NIST, ISO/IEC, Irish NCSC, and public-sector life-cycle governance | management and life-cycle processes; appeal, override, disengage/deactivate, incident response, recovery, credential revocation, exit planning, and decommissioning | closure evidence for remedy, branch-specific post-exit responsibility, unresolved cases, and authority reconstitution or residual disposition | completeness, legality, and comparative value |
| Australian Government AI Technical Standard | decommission planning; impact and dependency analysis; service continuity; stakeholder communication; secure shutdown/repurposing; final documentation and lessons | explicit unresolved-case ownership, remedy completion path, successor acceptance or residual custody, and evidence that practical decision capacity or residual duties have actually been reassigned | comparative operational value and jurisdictional transferability |
| ISO/IEC TS 8200 controllability | state observability and transition; control transfer; transfer uncertainty; verification and validation | institutional successor acceptance or residual custody, remedy continuity, open-case ownership, and closure evidence after control transfer or termination | legal sufficiency and comparative operational value |
| Auditable lifecycle transitions | measurable trustworthiness dimensions, monitoring, reassessment, readable level transitions, and human control gates | termination-specific partial order joining remedy, successor capacity, decommissioning, assurance, and closure | incremental benefit over lifecycle reassessment |
| Final-authority and portability governance | deployer-centered final authority; portable governance layers; audit rights; switching-cost and lock-in analysis | evidence that authority has actually been reconstituted after exit, including independent-operability checks | feasibility across contractual and infrastructure regimes |
| Algorithmic resignation | deliberate, informed disengagement and disclosure during use | institutional closure guards, remedy continuity, authority transfer, temporary containment release, and bounded post-closure redeployment | comparative scope or practical effectiveness |
| AI Debris decommissioning | post-withdrawal residue, decision-footprint preservation, remediation, contestability | upstream trace-to-authority boundary, executable closure guards, unresolved-case ownership | comparative completeness or field effectiveness |
| Drift/process monitoring | baseline, limits, sequential change detection | construct-validity and corroboration rules for judgment, attention, and voice | external discrimination and lead time |
| Recourse and documentation | feedback, appeal, records, accountability | separate burdens for temporary containment release and post-closure redeployment, plus a closure condition that every affected case retains an accountable owner | effect on real remedies |
| Policy termination and sunset review | political resistance to termination; organizational survival; time-triggered abolition unless reauthorized, with a wind-down period | evidence-triggered, authorized exit whose closure requires remedy, case ownership and residual custody | whether such conditions are adopted or enforced |
| Cognitive and institutional legibility | comprehension thresholds, update accessibility, authority coherence, interpretive continuity | route their observable deterioration into a constrained candidate-to-authority process | validity of proxies and incremental value beyond direct measures |

Table: Incremental boundary relative to adjacent governance and control families.

## Methodological stance and evidence ladder

The paper combines design science, theory-directed public-document analysis, finite-state verification, and exploratory computational modelling. Each method answers a different question. The document analysis examines whether official records contain objects associated with the proposed mechanisms; it neither validates those mechanisms nor estimates effects. The state model asks whether the written transition guards exclude specified unsafe states; it does not establish organizational or legal completeness. Following Bankes (1993), the synthetic prototype is used to reason across declared assumptions and expose contradictions rather than to predict an institution. The historical description follows the ODD principles of purpose, entities, process, initialization, inputs, and submodels (Grimm et al., 2020). The generator itself is unavailable in this release.

The evidence falls into the following levels:

1. normative and formal specification: concepts, equations, state variables, decision rights, and closure conditions are inspectable;

2. software and model verification: tests check that code implements declared rules, prohibited label paths are absent, and the selected finite-state abstraction preserves its authored invariants;

3. public-record external traceability: purposively selected official passages provide inspectable examples of evidence, reasons, voice, review, remedy, and authority outside the author’s generator; because mechanism coverage is part of case eligibility, this level is illustrative rather than an independent estimate of observability or discriminant validity;

4. constructed-scenario failure-mode characterization: random-seed runs characterize detector behavior, diagnostic burden, and blind spots within disclosed scenario families;

5. external construct and discriminant validation: independent cases and data must show that each measure represents its intended construct and distinguishes benign alternatives;

6. prospective operating validation: new sites and future windows must establish error, delay, subgroup, burden, and nonstationarity behavior; and

7. outcome evaluation: only a governed comparative study can test whether use of the protocol improves protected functions net of intervention harm.

This paper supplies evidence only at levels 1–4. It does not establish levels 5–7. Terms such as “detects” and “misses” in the synthetic results refer solely to membership in a predeclared scenario class.

# Detection and Transition Ontology

The following terms are not interchangeable. The ontology separates measurement states, research classifications and institutional acts so that an abnormal statistic or a descriptive label cannot acquire decision authority by definition. Three layers are distinguished: a diagnostic layer (indicators, signals and candidate events), a research-classification layer (the Part II profile), and an institutional layer (authorized determinations and acts).

**Governance Drift Indicator (GDI).** A candidate, time-indexed measure of a particular governance mechanism. Depending on when its required inputs become available, a GDI may be prospective, contemporaneous, lagged or retrospective. It becomes an operational indicator—and may be described as leading only for a prospectively validated use—after independent construct and timing validation.

**Signal.** A prespecified abnormal value relative to a justified baseline, with uncertainty and data-quality status.

**Candidate event.** A persistent, coupled signal satisfying the minimum evidence rule for independent investigation.

**Incipient capacity-loss risk and GCL-PC.** Research classifications defined in Part II (Sato, 2026b). Governing-capacity loss under procedural continuity (GCL-PC) is a non-compensatory profile in which stable or improving visible procedural fidelity coexists with established, material and persistent declines in independent judgment and institutional actionability and an established impairment of a predeclared protected function; incipient capacity-loss risk reports established declines in independent judgment and institutional actionability while protected-function impairment is not established, together with the evidential status of that condition, and does not require procedural continuity. Neither classification requires nor supplies institutional decision authority.

**Governance incident.** A separate determination by a competent body, supported by appropriate evidence, that a protected function or governing capacity has been materially impaired. Such evidence may include a Part II profile but is not limited to it. A finding that relies on a GCL-PC profile must record the evidentiary basis and the authorized actor separately. Neither the descriptive classification nor an incident finding automatically authorizes containment, retirement or resumed operation.

**Resolution Collapse.** An authorized finding that ordinary remediation repeatedly fails, is structurally unavailable, or cannot restore legitimate and safe operation within the approved horizon. It supplies one sufficient basis family for a separately authorized retirement decision; other lawful bases remain available.

**Circuit Breaker.** A reversible, scoped containment action that reduces exposure while evidence is preserved and investigated.

**Proper Ending.** An auditable institutional process for retiring a workflow when continued operation cannot be justified. It is complete only through authorized closure; technical shutdown alone is insufficient.

**Post-exit responsibility.** The branch-specific assignment of continuing and residual duties before decommissioning. If the decision function continues, it requires an accepting successor with operational capacity and an accountable owner for unresolved cases. If the function is abolished, it requires a named residual custodian or remedy authority and an accountable owner for unresolved cases, records, appeals, compensation and residual liabilities. Where the absence of affected cases has been verified, no fictitious case owner is required, but branch-appropriate successor capacity or residual custody remains required.

**Authority Return.** The documented reconstitution, reassignment or residual disposition of operational decision capacity, discretion, accountability, duties, records, resources and remedy obligations after an automated socio-technical arrangement is constrained or retired. If the function continues, return is to one or more legally and normatively competent accepting successors with practical capacity to decide, explain, correct and resource the function. If the function is abolished, return resolves residual authority through a named custodian or remedy authority rather than inventing a successor to a function that no longer exists. Return denotes functional disposition and restoration of accountable capacity, not legal personhood of software or automatic reinstatement of a pre-automation status quo.

**Closure.** The authorized determination that the Proper Ending episode has satisfied its required closure evidence, including notice, a secured remedy route, assurance and post-exit responsibility. Closure ends the exit episode; it does not extinguish residual legal, record-retention, compensation or follow-up duties.

**Temporary containment release.** A bounded return to operation before decommissioning after the identified defect or risk condition is corrected or acceptably bounded, correction is independently verified, fallback capacity is ready, and a release approval is recorded and current at execution. It is not closure and does not erase the incident or remedy record. If a retirement decision is later authorized, the workflow must be able to return to containment (Section 9.4).

**Post-closure redeployment.** A new deployment decision after Proper Ending and closure. It requires a separate, current approval and the stronger re-entry burden specified in Section 10; historic approval does not revive automatically.

These distinctions guard against category errors: a statistical anomaly is not an incident; a research classification is not an institutional finding; incipient risk is not realized impairment; an incident is not automatically grounds for irreversible termination; temporary release is not closure; and post-closure redeployment is not a continuation of the old approval.

# Public-Record Traceability Illustrations

## Corpus and coding procedure

To reduce exclusive dependence on an author-designed generator, this revision adds a small set of public-record traceability illustrations. A record was eligible when it was issued by a public inquiry, legislature, auditor, regulator, or government body; concerned a consequential public decision workflow using automation, rules, or algorithmic risk selection; and documented at least two of the following: evidence handling, reasons, review or appeal, operational feedback, remedy, cessation, or responsibility. Three information-rich negative cases were purposively selected under that rule: Australia’s Robodebt scheme, the Dutch childcare-allowance scandal, and Michigan’s unemployment-insurance claimant workflow (Royal Commission into the Robodebt Scheme, 2023; Childcare Allowance Parliamentary Inquiry Committee, 2020; Michigan Office of the Auditor General, 2016). The three official investigations concern automated and algorithmic decision systems deployed before contemporary generative AI and large language models. They are not direct evidence about LLM-based workflows, and the papers neither equate those earlier systems with AI in general nor treat them as a separate category to which the analysis does not apply. The unit of analysis is a document passage or tightly bounded group of adjacent passages. Fifteen units were paraphrased, assigned a page or recommendation locator, and coded for evidence_sufficiency, reason_giving, review_path, voice_feedback, proportionality, legal_authority, decision_record, independent_scrutiny, signal_persistence, remedy_continuity, or authority_return. The row-level matrix and codebook are not part of the version 6.3 reproducibility package; the coded illustrations are reported as in version 6.2 and are not re-derived here. Coding was performed by one author and was theory-directed; no inter-coder reliability is claimed. Eligibility and purposive selection favored records with documented governance mechanisms, so the corpus is selection-enriched by construction. It therefore cannot independently establish observability in an unselected population, estimate frequency or comparative severity, identify effects, or establish discriminant validity. A future validation corpus should add at least one relatively well-managed retirement or transfer case and an independent second coder; those additions are deliberately not simulated here.

The identical fifteen units also appear in Parts I and II so that source locators and coding lineage remain stable across the trilogy. This controlled reuse creates an important limitation: all three theories were developed with knowledge of the same information-rich failures, so apparent cross-paper fit may reflect narrative accommodation rather than independent convergence. A passage that makes evidence, voice, remedy, and authority visible can inform several design questions, but it cannot count as three replications or as cumulative validation. External evaluation must freeze each theory before sampling new successful, failed, recovered, and boundary cases.

## Traceability results

| Case and official record | Independently documented workflow trace | Construct made observable | What the record does not show |
|---|---|---|---|
| Robodebt Royal Commission | Recommendations call for documented legal foundations, clear review paths, public explanation of automation, independent scrutiny, frontline feedback, dispute-sensitive recovery, and records of important decisions. | legal authority; reason giving; review; voice; independent scrutiny; remedy continuity | that this paper’s indicators would have predicted the scheme or that this exit sequence would have prevented its harms |
| Dutch parliamentary inquiry | The report describes inflexible, group-based and all-or-nothing administration, documented warning signals, discriminatory risk selection, and delayed recognition and compensation. | proportionality; signal persistence; corrective voice; remedy delay | a prospective measurement baseline, an identified counterfactual, or the performance of any proposed detector |
| Michigan performance audit | The audit records digital appeal access but also inadequate fact gathering and reasons in some misrepresentation determinations, weak communication access, and limited systematic use of claimant feedback. | evidence sufficiency; reason giving; practical review capacity; feedback routing | that MiDAS alone caused the findings or that the proposed protocol has superior costs or outcomes |

Table: Public-record traceability illustrations and the claims they do not establish.

Across the corpus, the relevant governance objects are not limited to model accuracy. They include whether evidence is obtained before a consequential determination, whether reasons make review usable, whether feedback reaches a responsible manager, whether disputes pause coercive action, and whether remedy persists after institutional recognition of failure. This supports only an external traceability claim: selected examples of the mechanisms targeted by the trace-to-transition architecture can be located and audited in official records outside the author-designed generator. Because mechanism coverage influenced eligibility and selection, this is not an independent test of whether the constructs would be observable in an unselected corpus. It does not support predictive validity or a prevention counterfactual.

The records also expose a gap in the proposed construct. They contain substantial evidence about review, explanation, feedback, and remedy, but less direct evidence of an explicit, signed transfer of decision capacity after retirement. authority_return is therefore retained as a normative design requirement whose empirical prevalence and legal form remain unestablished, not reported as a pattern found across the three cases.

# Circuit Breaker

A Circuit Breaker is a reversible containment control with a named owner, scope, trigger record, review deadline, and exit criteria. Its ordinary form is service-preserving containment, which requires a tested fallback and aims to reduce expected exposure while preserving essential service and evidence. A separate emergency safe-stop is available when credible evidence indicates imminent severe harm and continued operation is less defensible than temporary service interruption. The emergency path does not assume that a fallback is ready: it requires separately documented legal authority, proportionality, immediate triage, preservation of evidence where feasible, and a time-bounded plan to restore a lawful service path.

| Mode | Illustrative action | Required protection |
|---|---|---|
| Throttle | cap volume or restrict low-confidence automation | no silent queue abandonment |
| Shadow | model runs without controlling action | independent decision capacity |
| Narrow | remove high-risk populations or action types | monitor displacement and unequal access |
| Escalate | require second review or independent authority | protected time and non-retaliation |
| Fallback | return to approved non-model process | tested capacity and continuity |
| Suspend | halt affected workflow or model version | notice, remedy, evidence preservation |

Table: Circuit Breaker modes, illustrative actions, and required protections.

Containment can itself cause harm through delay, denial, or unsafe manual overload. The decision record therefore includes expected benefit, service impact, affected groups, fallback capacity, legal authority, uncertainty, and the next review time. Simulation and tabletop exercises should test the fallback before an incident whenever service-preserving containment is the intended mode. If no tested fallback exists and imminent severe harm justifies an emergency safe-stop, the record must state why the emergency path was necessary and what temporary continuity and remedy arrangements apply.

# Resolution Collapse

Resolution Collapse is established only when an authorized independent body finds that ordinary remediation cannot restore acceptable operation within the approved horizon. Evidence may include repeated recurrence after corrective action, inability to identify or measure the failure, structural authority mismatch, unavailable safe fallback, unlawful operation, or an adverse residual risk exceeding a declared limit.

The determination must distinguish a lack of capacity from a lack of willingness to act. It records remedies attempted, responsible owners, verification results, outstanding uncertainty, distributional effects, and why less restrictive alternatives are inadequate. Where law requires a different process, that process governs. Resolution Collapse is one sufficient entry basis for Proper Ending, not the sole trigger. A competent authority may also authorize retirement on another recorded basis, including a legal or mandate change, security necessity, provider exit, redesign, obsolescence, or abolition of the decision function. Every entry therefore records a controlled retirement_basis category, the competent authority, reasons, scope, record time, and effective time. The recorded category cannot replace the applicable substantive or legal test.

# Proper Ending

A Proper Ending is not deleting a model file. It comprises nine institutional steps:

1. Authorize: identify the lawful decision maker, scope, effective time, and review path.

2. Contain: use a tested fallback for service-preserving containment, or invoke a separately authorized emergency safe-stop when imminent severe harm makes continued operation less defensible than temporary interruption.

3. Preserve: freeze relevant versions, logs, decisions, notices, and investigative evidence under lawful retention controls.

4. Notify: give affected people, operators, owners, and oversight bodies accurate, accessible notice appropriate to their rights and risks.

5. Remedy: identify affected decisions, enable review and appeal, begin urgent or interim protective relief where delay would compound harm, correct records, compensate where required, and prioritize severe cases. When lawful and necessary, urgent relief may begin before individual notice; the exception and later notice must be recorded.

6. Transfer: if the decision function continues, move decision rights, duties, budgets, personnel, queues, records, unresolved cases, and incomplete remedy obligations to an authorized accepting successor or partition them among authorized successors when authority is federated. If the function is abolished, assign a named residual custodian or remedy authority for records, unresolved cases, appeals, compensation, incomplete remedies, and residual liabilities. Transfer records acceptance and ownership; it does not falsely certify that every remedy is complete.

7. Decommission: revoke integrations and credentials, archive or dispose of components safely, and verify that shadow use has ceased.

8. Assure: obtain independent confirmation of continuity, remedy progress, security, and absence of unauthorized restart or redeployment through a declared assurance cutoff.

9. Learn and close: publish a proportionate account, assign follow-up owners, retain lessons, conduct the final closure review after the assurance cutoff, and record the closure effective time.

The numbers identify evidence-producing functions, not a rigid nine-box waterfall. The controlling partial order is: retirement authorization precedes any new containment undertaken for Proper Ending, although an already active Circuit Breaker may satisfy the containment prerequisite; containment history then enables preservation, notice, and remedy initiation in parallel. Urgent protective remedy may precede notice where the applicable authority permits and delay would compound harm. Branch-specific transfer requires an open remedy path and explicit acceptance of every incomplete obligation and unresolved case, but not completion of all remedies. Preservation and resolved branch-specific responsibility must converge before decommissioning; decommissioning precedes assurance; and assurance through the declared cutoff precedes the final closure review. Closure additionally requires completed notice and a secured remedy route; where harm has been found, it also requires recorded initiation of remedy or an assigned incomplete remedy obligation. Work may proceed in parallel whenever these incoming dependencies are satisfied. Closure is incomplete while any affected case or remedy obligation lacks an accountable owner. Closure does not extinguish continuing compensation, record-retention, appeal, or follow-up duties. Material evidence discovered after the cutoff remains subject to the applicable reopening, follow-up, and residual-duty rules; the cutoff is not an evidence-destruction date.

![Proper Ending is a dependency-constrained institutional transition rather than a single shutdown event. Preservation, notice and remedy may proceed in parallel after containment; urgent remedy may precede notice, and transfer may accept incomplete remedy obligations, but preservation and branch-specific responsibility must converge before decommissioning, and notice is required again at closure. Dashed boxes are distinct return paths: temporary release before decommissioning (with one bounded re-containment in PE-R1) and post-closure redeployment.](figures/part3_fig1_proper_ending.pdf){#fig:pe width=92%}

# Authority Return

Authority Return is the substantive core of Proper Ending. Automation redistributes practical decision capacity and discretion into data definitions, ranking rules, defaults, access controls, and queue architecture, even when legal authority formally remains with a public or corporate actor. Ending the software does not by itself restore the human competence, resources, records, or remedy capacity displaced by that arrangement. Unlike ordinary task handover or technical offboarding, Authority Return requires the institution to identify power embedded across those structures, dismantle or neutralize its residual operation, and affirmatively reconstitute or reassign the capacity to decide, explain, correct, and resource the function. Return is therefore a functional term: it does not imply that software held legal personhood or that the pre-automation allocation was legitimate and should automatically be restored. This is a proposed institutional design requirement, not a claim of established legal effect.

An Authority Return Register identifies, for each decision function: the prior human or public authority; what was operationally delegated or displaced; the legal and policy basis; the accepting successor role when the function continues or the residual custodian/remedy authority when it ends; competence, staffing, and budget or residual-duty capacity; records and tools transferred; open cases; appeal and escalation channel; affected-party participation or representation; vendor and infrastructure dependencies; contractual exit and audit rights; portability of data, logs, credentials, and operating knowledge; effective time; and accepting signature. If the function continues, Return is complete only when the accepting successor can actually decide, explain, correct, and resource the function, can operate without an undisclosed dependency that defeats the transfer, and the destination has been reviewed under the applicable legal and participatory process. If the function is abolished, completion instead requires a named residual custodian or remedy authority with usable access to records, unresolved cases, appeal and compensation pathways, and residual liabilities; no fictitious successor is required.

| Register field | Minimum evidence | Closure question |
|---|---|---|
| decision function and legal basis | approved function map; current delegation instrument | what lawful power is moving, and under which authority? |
| predecessor and accepting successor / residual custodian | named roles; accepting signature and effective time | has a competent actor accepted the continuing function, or has a custodian accepted the residual duties if the function ends? |
| people and capacity | staffing level; competence record; protected review time; residual-duty capacity where the function ends | if the function continues, can the successor exercise judgment rather than merely inherit a queue; if it ends, can the custodian perform the residual duties? |
| records, tools, and interpretive knowledge | inventory; access test; retention basis; operating notes | can past decisions be reconstructed, explained, and corrected? |
| vendor exit and portability | contract exit rights; export inventory; portable logs and data; credential/API transfer; post-termination audit access; dependency map; independent-operability test | after provider exit, can a continuing successor operate and audit independently, or can a residual custodian reconstruct and audit the closed function? |
| open cases and remedies | case-level owner; severity priority; appeal route; service deadline | does every unresolved case retain an accountable owner and usable remedy? |
| affected-party standing and participation | consultation record; representative sign-off or reasoned response; accessible challenge route | were the people whose rights or services are affected able to contest the destination and terms of return? |
| residual risks and follow-up | risk owner; control; assurance date; publication rule | who owns what remains after technical decommissioning? |

Table: Minimum evidence and closure questions for the Authority Return Register.

Return may be to a redesigned human process, a lower-risk technical system, a different institution, a federated set of successors, or—for personal decisional control—affected individuals. Decision authority is often a bundle rather than a single object, so a plural-successor case should partition functions, duties, records, budgets, and escalation rights rather than forcing a fictitious one-to-one handover. Return of personal decisional control to an affected individual does not discharge institutional duties to preserve records, investigate, compensate, provide remedy, or remain answerable for prior decisions. The legitimate destination is a normative and legal question, not a technical default.

## Independent Authority Test

Because the detector is not allowed to retire or reactivate a workflow, the independence of the deciding authority is a substantive safeguard, not merely a label. For this paper, an authority counts as independent for a specific transition only if the decision record addresses, at minimum: organizational separation from the deployment owner; conflicts of interest and recusal; protected access to relevant evidence; competence to assess technical, legal, and service-continuity questions; authority to compel records or obtain equivalent access; power to pause, narrow, or escalate the workflow within its mandate; reasons that are documented and reviewable; and a review or appeal route appropriate to the decision. Direct performance incentives tied to continued deployment must be disclosed and, where material, neutralized or independently reviewed. This is an operational test for the proposed protocol, not a universal legal definition of independence.

## When no competent authority exists

Proper Ending presupposes an actor with lawful authority to retire the workflow and with sufficient independence from its operation. An institution that has lost governing capacity may lack exactly such an actor: the board, executive or minister formally competent to decide may depend on the workflow, may have delegated the relevant knowledge away, or may be captured by the interests the workflow serves. Four routes to an authorized decision are distinct and are not interchangeable: internal governance (a board, an audit or risk committee, an internal inspector), external regulators and supervisors, courts, and legislatures. Each has its own trigger, standard of review and remedial reach, and an institution may lack some or all of them for a given workflow.

If none of these routes provides a competent and sufficiently independent authority, the protocol cannot be executed. Nothing in this specification creates the political or legal authority it requires: a well-formed Authority Return Register, a validated indicator or a complete closure checklist does not authorize anyone to act. In that situation the specification can still define what an authorized decision would need and what evidence should be preserved for a body that may later acquire jurisdiction, but it cannot substitute for that body. The finite-state model in Section 9 assumes an authorizing actor; its results say nothing about settings where none exists.

# Finite-State Safety Verification

## Historical guard model

This subsection describes the guard abstraction as executed for version 5.9 and reported unchanged in v6.2. It is retained as a historical artifact; Sections 9.3–9.6 report a follow-up audit of that model and the revised candidate.

The executable artifact is a selected finite event-and-authorization abstraction of safety-critical guards from retirement authorization through containment, closure, temporary containment release, and post-closure redeployment. It is not a translation of the full nine-step Proper Ending protocol and it is not a clocked operational state machine. The historical model contains 31 state variables: twenty-nine Boolean event, status, witness, or authorization fields plus two three-valued fields. retirement_basis distinguishes UNRECORDED, RESOLUTION_COLLAPSE, and OTHER_AUTHORIZED_BASIS; function_disposition distinguishes UNDECIDED, CONTINUES, and ABOLISHED. Twenty-nine named actions change those variables.

The state semantics deliberately separate history, current status, and execution evidence. containment_initiated records that containment occurred, while currently_contained must still be true at decommissioning and becomes false after temporary release. Approval-recorded and approval-current fields describe the state before an execution; distinct valid-at-execution witnesses record whether the approval was actually current when release or redeployment occurred. A later retirement decision cannot retroactively make an earlier temporary release invalid, but an active retirement decision blocks a new temporary release. Expiry is represented as a finite event; actual dates, renewal periods, jurisdiction-specific duration rules, and revocation procedures remain outside the abstraction.

Retirement also has an explicit two-stage basis-and-authority structure. Resolution Collapse is one sufficient basis family, not a universal prerequisite: law, mandate, security, vendor exit, redesign, obsolescence, or abolition may supply another authorized basis. A retirement decision can be recorded only after both a basis family and a competent Proper Ending authority have been recorded. Remedy initiation requires containment history but not prior notice, permitting urgent protective relief. Incomplete remedies may then be accepted by the branch-specific owner; remedy_opened records an initiated path and obligation, not successful completion. Post-exit responsibility is branch-specific. A continuing function must record an accepting successor, reconstitute successor operational capacity, and assign an owner for unresolved cases and incomplete remedies; an abolished function must instead appoint a residual custodian or remedy authority and assign that ownership.

The model preserves the distinction between two return-to-service routes:

1. temporary containment release may occur before decommissioning when a restart basis is established and independently verified, fallback capacity is ready, no retirement decision is active, and a release approval is recorded, current, and valid at execution; and

2. post-closure redeployment may occur only after closure and is modeled as a new deployment decision requiring an established and independently verified restart basis, fallback readiness, and a separate redeployment approval that is recorded, current, and valid at execution.

The guards encode ten safety propositions:

1. service-preserving containment requires a ready fallback;

2. emergency safe-stop requires separately recorded emergency authority;

3. remedy initiation requires containment history but may precede notice;

4. retirement requires a recorded basis family and a recorded competent authority;

5. successor acceptance is valid only for a continuing function, while residual custody is valid only for an abolished function;

6. resolved post-exit responsibility requires branch-appropriate ownership, successor operational capacity when the function continues, and an accountable owner for unresolved cases and incomplete remedies;

7. decommissioning requires current containment, an authorized retirement decision, evidence preservation, and resolved post-exit responsibility;

8. closure requires decommissioning, independent assurance, notice, an initiated remedy path, and resolved post-exit responsibility;

9. temporary containment release requires an established and independently verified restart basis, fallback readiness, no active retirement decision, and a release approval that is recorded, current, and valid at execution; and

10. post-closure redeployment requires closure, an established and independently verified restart basis, fallback readiness, and a separate redeployment approval that is recorded, current, and valid at execution.

Breadth-first search exhaustively applied every enabled modeled action. The historical model reached 8,564 distinct states and examined 36,096 enabled transitions. No reachable state violated any authored safety invariant. The larger state space reflects the removal of the unnecessary notice-before-remedy ordering while preserving containment before remedy, plus retirement-basis taxonomy and authority, containment history versus current status, branch-specific responsibility, generalized restart basis, and execution-time approval witnesses.

| Proper Ending / recovery element | Executable representation | Scope deliberately left outside the model |
|---|---|---|
| Containment | fallback_ready; emergency_safe_stop_authorized; containment_initiated; currently_contained; emergency_safe_stop_used; separate normal/emergency actions | proportionality, essential-service adequacy, substantive imminent-harm finding, distributional effects |
| Retirement basis and authority | three-valued retirement_basis; proper_ending_authority_recorded; retirement_decision_authorized | substantive and legal adequacy of the basis, scope, authority, reasons, and effective time |
| Preserve | evidence_preserved; preservation-before-decommissioning guard | completeness, lawful retention, provenance, interpretation, access |
| Notify | affected_people_notified; notice required for closure | intelligibility, accessibility, timeliness, rights-specific content |
| Remedy | remedy_opened; containment-before-remedy guard; initiated remedy required for ownership and closure; notice may follow urgent initiation | practical accessibility, merits, compensation, completion, timeliness |
| Function disposition | three-valued function_disposition; branch-specific successor/custodian actions | legal legitimacy of abolition or continuation decision; jurisdictional authority |
| Authority Return / post-exit responsibility | accepting_successor_recorded; residual_custodian_recorded; successor_operational_capacity_ready; open_case_owner_assigned; post_exit_responsibility_resolved | adequacy of staffing/budget/competence, plural allocation, participation, substantive successor legitimacy |
| Decommission | decommissioned; current-containment, authorized-retirement, preservation, and responsibility guards | credential revocation, disposal, vendor obligations, shadow use, technical completeness |
| Assure and close | independently_assured; closed | substantive independence, audit quality, publication, lessons, contested closure, later backsliding |
| Release temporary containment | restart basis and verification; fallback; no-retirement-decision witness; approval-recorded, approval-current, and valid-at-execution fields; explicit expiry | substantive adequacy of the restart basis, real calendar duration, renewal and revocation law, field validity, subgroup effects, post-release monitoring |
| Redeploy after closure | closure; restart basis and verification; fallback; separate approval-recorded, approval-current, and valid-at-execution fields; explicit expiry | new legal approval substance, real calendar duration, field validity, subgroup effects, post-redeployment monitoring |

Table: Executable coverage and deliberate exclusions of the historical guard abstraction (version 5.9). PE-R1 adds re-containment, assessment epochs, the distinction between a secured remedy route and remedy initiation, verified absence of cases, and post-decommissioning boundary events.

## Historical mutation checks

Internal consistency can be manufactured by permissive invariants, so the verification includes 30 separately isolated, mutation-adequate guard mutations. Breadth-first search returns the first unsafe trace for every weakened guard. Table 6 groups the complete suite by guard family; the machine-readable report preserves every mutation identifier, complete state, and unabridged action sequence.

| Removed or weakened guard family | Mutations | First unsafe action pattern and violated proposition |
|---|---|---|
| containment | 2: missing fallback; missing emergency authority | the first containment action creates containment without its required readiness or authority |
| urgent remedy initiation | 1: remedy before containment history | open remedy creates a remedy episode before any containment action |
| retirement authorization | 2: missing basis; missing competent authority | authorize proper ending creates a retirement decision without both recorded prerequisites |
| disposition branch | 2: successor on wrong branch; custodian on wrong branch | the first owner-recording action contradicts the function disposition |
| post-exit responsibility | 4: missing successor; successor capacity; residual custodian; open-case owner | assignment or resolution occurs without branch-appropriate capacity and ownership |
| decommissioning | 4: missing current containment; retirement decision; preservation; responsibility | decommission executes without one required incoming guard |
| assurance and closure | 3: assurance without decommissioning; closure without assurance; closure without notice | assurance or closure executes without its required predecessor or closure notice |
| temporary containment release | 6: missing restart basis; independent verification; approval record; current approval; fallback; or absence of active retirement | release containment executes without a valid restart-and-authorization state |
| post-closure redeployment | 6: missing closure; restart basis; independent verification; approval record; current approval; or fallback | redeploy after closure executes without a valid new-deployment state |

Table: Isolated guard mutations and first unsafe action paths.

The exercise supports a narrow proposition: within this selected finite abstraction, the tested guards are necessary relative to the authored invariants and the unmutated transition function enforces them. Notice is now an independent closure prerequisite and its removal is mutation-adequate. Remedy initiation and branch-appropriate responsibility remain upstream prerequisites of decommissioning and are checked again at closure as defense in depth; remedy completion is not modeled or claimed. The invariants and mutations still derive from the same authored specification, so this is executable consistency testing rather than independent validation. The extension does not show that a successor is legally legitimate or sufficiently resourced, that a residual custodian can actually deliver remedy, that notice is intelligible, that a remedy succeeds, that an emergency-authority record was substantively justified, that an organization records facts honestly, or that the legal order permits the sequence. It also does not model repeated incidents, contested facts, parallel authorities, partial-population rollback, or arbitrary later backsliding.

## Follow-up reachability audit of the historical model

The historical results above are safety results: no reachable state violates an authored invariant. Safety does not imply that authorized progress remains possible. A follow-up audit re-explored a replica of the historical guard model (M0), which reproduces the historical state and transition counts exactly, and computed backward reachability to closure. In the historical reachable graph, 1,152 of 8,564 states (13.45%) have no path to closure. Of these, 864 follow a temporary release without an active retirement authorization and are compatible with restoration of service within the single-episode boundary. The remaining 288 are retirement-authorized but unclosed states with no path to closure; sixteen are defect terminal states in which no modeled action is enabled. The witness path is short: containment, release, and a subsequent retirement authorization leave the workflow running with an authorized retirement that can never be decommissioned, because decommissioning requires current containment and no action re-establishes it after release. These are new reachability findings about the historical finite abstraction. They are not results claimed by v6.2, not counterexamples to its reported safety invariants, and not a frequency of institutional failure. They show that the original safety invariants can hold even where authorized progress is impossible.

## The revised candidate PE-R1

The revised specification PE-R1 (Proper Ending revision candidate 1; the audit code and outputs retain the key B3_S1, which is unrelated to Table B3) permits one re-containment after release and authorized retirement, through either service-preserving containment or a separately authorized emergency safe-stop. Evidence preservation and currently valid harm, case, ownership and responsibility assessments are invalidated on re-containment, whereas historical records and obligations are retained; a new containment epoch is required for fresh evidence and assessments. A previous discovery of harm cannot disappear from the historical ledger through a later negative assessment, and the closure rules require the relevant remedy-initiation history. Where cases have existed, the model conservatively disallows a later declaration that there are no cases, because it does not represent individual case resolution. The restart basis and release approval cannot survive as current across re-containment.

PE-R1 also separates two distinctions that the historical model collapsed. A secured remedy route is distinguished from the recorded initiation of remedy where harm has been found, so that closure does not require a fictitious remedy where no harm was found but does require initiation where it was. A verified absence of cases is distinguished from cases requiring an accountable owner, so that a residual custodian or successor is still required but no fictitious case owner is manufactured. The model does not require that evidence preservation universally follow containment: a domain contract may require or permit earlier preservation, and any order requirement imposed in an implementation must be justified and tested against its normative specification. Approval-time checks and execution-time witnesses are not conflated; actual execution always requires the current applicable authorization. A recorded successor or custodian flag does not establish the party’s competence or legitimacy.

PE-R1 is a revised specification, not a strict extension of the historical state graph, so compatibility and intentional differences are reported separately in the reproducibility package. Table 7 compares the two graphs. The figures were obtained by re-executing the audit implementation, including backward reachability and an exact strong-fairness subgraph search, and agree with the audit's recorded outputs. This is a rerun of the audit implementation, not an independently authored model checker.

| Measure | Historical M0 replica | PE-R1 (audit key B3_S1) |
|---|---:|---:|
| Reachable states | 8,564 | 98,948 |
| Labeled transitions | 36,096 | 479,880 |
| Violating states / edges | 0 / 0 | 0 / 0 |
| Closed states | 180 | 7,380 |
| States with no closure path | 1,152 | 0 |
| Retirement-authorized unclosed states with no closure path | 288 | 0 |
| Defect terminal states | 16 | 0 |
| Strongly fair closure-avoiding subgraphs | 0 | 0 |

Table: Historical guard model and revised candidate PE-R1. Counts are properties of finite abstractions, not frequencies of institutional outcomes.

The progress property checked is $\mathrm{AG}(\mathit{authorized} \wedge \neg\mathit{closed} \Rightarrow \mathrm{EF}\,\mathit{closed})$: from every retirement-authorized unclosed state, some path reaches closure. It is not $\mathrm{AG}(\mathit{authorized} \Rightarrow \mathrm{AF}\,\mathit{closed})$, which would require that every path eventually closes; that stronger property does not hold without fairness assumptions, because modeled environment events can recur. The fairness search treats modeled environment events and institutional actions as fair action labels and finds no strongly fair closure-avoiding subgraph in either graph. Because PE-R1 also has no unintended terminal state, every strongly fair run of the abstraction that reaches a retirement authorization eventually reaches closure; this conditional result depends on the strong-fairness assumption. The assumption is a modeling choice, and no claim about real environments or stronger liveness should be inferred from it. Absence of fair closure-avoiding subgraphs also does not exclude finite deadlocks, as M0 demonstrates: its sixteen defect terminals are finite dead ends rather than infinite fair runs. PE-R1 bounds the number of re-containments, uses truthful abstract predicates, and does not represent real clocks or arbitrary parallel proceedings.

## PE-R1 mutation suite

The PE-R1 mutation suite contains 134 variants: the 30 historical named guard mutations, 37 mutations of guards added by the revision, and 67 mutations generated systematically from the guard syntax. Each variant is explored to a cap of 250,000 states; a variant that reaches the cap after producing a violation witness counts as detected, whereas a truncated search without a witness would be inconclusive rather than a successful kill. Re-executed for this version, the suite reproduced the audit’s recorded classification of every variant. Eighty-three variants are detected with a violation witness: 52 by the historical invariants and 31 only by invariants added in PE-R1; nine of these reached the cap after producing their witness. Forty-two variants are equivalent, producing a labeled graph identical to the baseline; they include three of the thirty historical named mutations, whose guards are redundant in PE-R1 because other guards enforce the same condition. Nine variants survive.

The nine surviving variants change reachable behavior without violating an authored invariant, and they fall into two requirement-level groups. Five weaken order requirements that the normative specification deliberately leaves to the domain contract: evidence preserved while not currently contained, notice before containment, function continuation or abolition recorded before a remedy path (two variants), and a restart basis established before containment. Four remove the independent-verification or fallback conjunct from a release or redeployment approval; the corresponding execution actions still require a verified basis and a ready fallback, so these approval-time guards are defense in depth rather than the guard on which safety rests. Each survivor is detected by an explicit candidate invariant (C1–C6) that the audit defines but the specification does not adopt. Whether to adopt those order and approval-time invariants is a normative choice for a domain contract, not a defect revealed by the model. The mutation report therefore includes surviving variants and their interpretation rather than treating a perfect detection score as the objective. The historical thirty-mutant results remain historical and are not merged with these counts.

## Boundary after technical decommissioning and closure

PE-R1 includes one-shot boundary events for a case or a harm discovered after technical decommissioning. They do not reopen closure. The encoded checks require existing responsibility resolution, a secured remedy path and a recorded receiving party, and allow or require certain owner and remedy flags depending on the event and closure status. Because these flags are not indexed to individual cases or findings, an earlier owner assignment or remedy initiation can satisfy a later flag. The model therefore tests a bounded interface for residual responsibility, not a new assignment or remedial act for every subsequent discovery. It does not establish completion of individual remedies or safety under an unbounded stream of new cases. In the institutional protocol, each newly discovered matter must receive traceable case-specific handling by the competent party, with scope, resources, remedy, escalation and lawful record retention specified outside this abstraction.

# Temporary Release and Post-Closure Redeployment Burdens

A reversible Circuit Breaker and a completed Proper Ending create different burdens.

Temporary release from containment is available only before decommissioning and while no retirement decision is active. The proponent must establish a restart basis—which may be correction, acceptable risk bounding, replacement, or another authorized recovery basis—have it independently verified, show that fallback capacity is ready, define the release scope, and obtain a bounded approval with monitoring and renewed-containment criteria. Release does not erase the incident record or terminate remedy obligations already opened.

Redeployment after Proper Ending is a new deployment decision. The proponent bears the stronger burden of showing that:

- the causal defect has been identified rather than merely hidden;
- corrective controls have been independently verified;
- constructs and thresholds remain valid under the new configuration;
- fallback capacity and remedy are operational;
- affected groups have been considered in the risk decision;
- shadow testing and adversarial exercises meet prespecified criteria;
- and an authorized body signs a bounded approval with monitoring and exit conditions.

Historic approval, sunk cost, or the absence of a new incident is insufficient. The authorization record for either route must carry an approval identifier, authority, scope, conditions, recorded and effective times, expiry time, revocation status, and renewal criteria. The present specification distinguishes a historical approval record, pre-execution currentness, and a valid-at-execution witness; an approval that was once current but expired or was revoked before the act cannot authorize it. This proves only the corresponding finite guard. Real calendar duration, renewal substance, revocation law, jurisdiction-specific authority, and the accuracy of recorded timestamps must still be enforced and audited by the operational authorization system.

# Measurement Boundary and Principal Synthetic Result

The GDI layer supports investigation routing; it neither confers authority nor constitutes a prerequisite for Proper Ending. Three aggregate trace families ask whether rationale text adds held-out information beyond declared controls, review time remains responsive to legitimate complexity, and corrective voice is supplied and acted upon. A Level-1 crossing prompts data-quality review. Aggregate Level 2 requires at least two governance-trace families, dissent or estimable outcome corroboration, two-window persistence in one measurement regime, and no validity hold. Language and time alone cannot satisfy it. Because some inputs depend on later adjudication, the prototype is mixed-observability and does not establish prospective lead time.

The historical v5.9 implementation added Level 2-S to address the aggregate rule’s blind spot. The illustrative subgroup—synthetic risk at least 0.56—was fixed in code before benchmarking and required at least 35 subgroup cases per 250-case window. The rule uses subgroup rationale contribution and risk-adjusted dissent, with an estimable subgroup adverse-outcome ratio as corroboration; it excludes the fixed-effects time family at the smaller sample size. A field study must replace and justify this constructed subgroup and threshold before inspecting outcomes, and must preregister multiplicity control if more than one subgroup is tested.

| Frozen rule | Localized candidates / 100 | Exact 95% interval | Median delay, cases | Candidates in each of six benign scenarios |
|---|---|---|---|---|
| Aggregate Level 2 | 8 | 3.52%–15.16% | 1,500 | 0/100 |
| Level 2-S subgroup | 97 | 91.48%–99.38% | 1,000 | 0/100 |
| Union | 98 | 92.96%–99.76% | 1,000 | 0/100 |

Table: Constructed localized-collapse recovery. The subgroup definition matches the generator’s declared failure boundary, so these are internal implementation results—not field sensitivity, specificity, discovery, or proof that 0.56 defines real-world risk. These are historical values from the version 5.9 computational artifact, reproduced as reported in version 6.2; they cannot be regenerated from the version 6.3 package.

In the historical benchmark, aggregate monitoring missed 92/100 streams. Level 2-S addressed that constructed failure mode; it did not validate subgroup measurement or performance outside the generator.

The historical sensitivity audit of the aggregate rule comprised 9,450 run-configurations. At the frozen MAD-3, persistence-2 setting, an independent 25-stream sample detects 1/25 localized collapses (4%), compared with 8/100 in the frozen benchmark; the exact intervals overlap and the difference reflects finite seeded replication. Across nearby settings, localized detection ranges from 0% to 100%, confirming that no operating point is validated. Benign efficiency produces a mean Level-1 window burden of 0.338 despite zero Level-2 candidates, so investigation burden must be measured separately from false containment candidates.

Before operational use, independent teams must validate requirements, constructs, timing, subgroups, manipulation resistance, burden, and decision utility. Requirements review must include applicable legal and service duties, workers, and affected-person representatives; validation samples must include successful, recovered, failure, and boundary workflows with blinded independent coders. RIC can reward predictive semantic padding; the synthetic permutation audit does not establish faithfulness, and matched swaps, boilerplate stripping, evidence ablation, and source-grounding review remain required. Full equations, control limits, leakage diagnostics, scenario definitions, sensitivity tables, and the preregistration program appear in Technical Appendix B; the underlying v5.9 computational artifact is not redistributed with this version (see Data, Code, and Reproducibility).

The rationale-information, time-complexity and corrective-voice measures are also candidate inputs to the joint-trace test P4 of Part II, not independently validated indicators. Independent outcome reconstruction must not reuse the same adjudication or the contemporaneous measurement that constitutes the protected-function condition as a validation target. Where such sources overlap, their lineage and uncertainty must be specified or a different held-out target used; duplicated evidence must not be counted as corroboration. The decision to investigate, contain, retire or redeploy remains a separately recorded authorized act.

# Limitations

The historical prototype was entirely synthetic and intentionally separable from the exit protocol. Its near-boundary and 100/100 benchmark counts arise from constructed families selected with knowledge of the proposed indicators; they do not estimate open-world error rates, prevalence, positive predictive value, or field sensitivity and specificity. Exact binomial intervals quantify seed-to-seed variation conditional on each synthetic scenario and omit uncertainty from scenario selection, model choice, threshold tuning, and site heterogeneity. The carried-forward v5.9 8/100 aggregate localized-collapse result shows that aggregate windows hide severe subgroup failure in most constructed streams. The fixed illustrative Level 2-S rule detects 97/100 and its union with the aggregate rule detects 98/100, but the generator and detector share the same declared subgroup boundary. Those counts demonstrate implementation of a known repair, not external subgroup validity, discovery, or a justified real-world threshold. The simultaneous policy-shift stress demonstrates the opposite safety tradeoff: a validity hold can prevent automated overreach while also delaying a true containment candidate. The carried-forward v5.9 9,450-run-configuration sensitivity audit confirms substantial parameter dependence, especially for localized and mild gradual collapse; it is neither an optimization study nor evidence of a validated operating point.

Repeated testing across five dependent measures is not calibrated to a family-wise or false-discovery criterion. The carried-forward v5.9 benchmark also shows that benign efficiency generates Level-1 signals in 33.8% of post-stress windows despite zero Level-2 candidates, and reviewer-composition shift creates a time-model validity hold in 26% of streams. Operational burden and conservative holds therefore remain material unvalidated properties. RIC depends on a valid downstream target and may reward leakage or predictive semantic padding. The added policy/interface controls and permutation audit narrow specified leakage routes, but the proposed boilerplate ablation, matched-swap, source-grounding, and predictive-padding attacks have not been executed on field rationales and cannot establish rationale independence, causal sufficiency, or faithfulness. A detailed but surface-predictive rationale can score well while recording no genuine human reasoning. The review-time contract now reports rank, condition number, minimum cell size, classical and HC3 uncertainty, and a ridge sensitivity delta; its thresholds are illustrative, and these diagnostics do not solve small-sample instability, misspecification, dependence, or worker-level privacy risk. A screen based on the maximum standardized marginal mean shift cannot detect all multivariate distribution changes. The measurement-regime signature covers observed policy- and interface-version sets but can miss consequential changes elsewhere in the workflow. Dissent eligibility and remedy judgments can be contested. Outcome label coverage may exceed analyzable coverage, and outcomes, verified errors, issue opportunities, and adjudicated classes may be delayed or selectively observed. The delayed-outcome scenario still does not delay every adjudication-dependent variable, so it does not establish prospective lead time. The missing-adjudication path produces a validity hold rather than an exception, but that is software-safety behavior, not evidence that the traces work under realistic label delay. Windowing can hide short severe events or fragment slow change. Bootstrap limit ranges remain wide for sparse dissent and outcome measures. Robust limits do not solve nonstationarity, multiplicity, site dependence, causal ambiguity, or institutional adaptation.

The public-record illustrations have separate limitations. They use three purposively selected failure cases and fifteen author-coded units. Official reports offer greater detail and authority than press summaries, but reflect particular mandates, legal systems, and evidentiary records. Single-author, theory-directed coding is vulnerable to confirmation bias, and the matrix contains no positive or matched comparison cases. It supports traceability of mechanisms, not frequency, necessity, sufficiency, prediction, or prevention.

Parts I and II draw on the same corpus. This keeps source lineage consistent but compounds theory-first narrative-fit risk and does not create independent triangulation, replication, or cumulative validation across the trilogy.

The finite-state models establish only properties of the selected abstractions. The historical model separates retirement basis and authority, containment history and current status, branch-specific post-exit responsibility, restart basis and verification, and pre-execution approval state from validity at execution. Those additions narrow earlier abstractions but do not establish semantic adequacy. State flags cannot reveal whether a retirement basis was lawful, notice was intelligible, remedy was accessible, staffing and budget were sufficient, a successor or custodian was legitimate, evidence was complete, or assurance was independent in substance. The follow-up audit showed that its safety invariants held while 288 retirement-authorized states could not reach closure, which is why safety and progress are now reported separately. PE-R1 repairs that defect only within a bound of one re-containment; it does not represent individual cases, so post-decommissioning findings test a bounded residual-responsibility interface rather than case-specific remedy. Nine mutation variants survive and are reported with an interpretation, and the progress result under fairness depends on an explicit strong-fairness assumption. Both models still omit unrestricted repeated incidents, arbitrary later backsliding, contested facts, parallel authorities, partial populations, real calendar time, and jurisdictional conflict. The invariants and mutations derive from the same authored specification. Formal verification is therefore exhaustive state exploration of a selected guard model, not certification or independent validation of the nine-step protocol or a real institution. The framework may itself create institutional risks. Indicators can become performance targets, a Circuit Breaker can deny essential service, and an “independent” authority can be independent in name only. The independence test of Section 8.1 narrows that ambiguity but is itself a proposed operational criterion rather than a validated legal test, and where no competent and independent authority exists the protocol is not executable (Section 8.2). Proper Ending can be used to destroy evidence or abandon claimants if preservation, remedy, and Authority Return are weak. These risks call for constraints and audit, not further automation.

# Conclusion

Silent governance failure may leave observable traces, but detection alone is not governance. The proposed GDI families examine whether rationales still add information, attention still responds to complexity, and corrective voice still exists and works; they distinguish traces available at decision time from metrics that become available only after adjudication. Coupling, persistence, corroboration, validity holds, and independent authorization restrict what can be inferred from those traces. The historical synthetic prototype was reported to implement this logic and expose three consequential limits: localized failure can disappear in aggregates, a justified validity hold can delay escalation, and nearby threshold/persistence choices can materially change detection. It does not establish prospective lead time under delayed adjudication. The historical fixed Level 2-S implementation detected 97/100 constructed localized streams, against 8/100 for the aggregate rule. Because it used the generator’s known subgroup boundary, this was an internal repair test, not discovery, field sensitivity, or subgroup validation. The generator is unavailable in the current package.

The central proposal concerns institutional structure. An accountable exit is incomplete if service collapses, evidence disappears, affected people lose remedy, or unresolved decisions have no accountable owner. Proper Ending therefore treats authorization, containment, preservation, notice, remedy initiation, transfer, decommissioning, assurance, and closure as separate evidence-producing acts connected by an explicit partial order. Urgent remedy may begin before notice, and transfer may accept incomplete remedy obligations, without allowing closure to erase those obligations. Authority Return makes the disposition of practical decision capacity explicit for both continuing and abolished functions. Exhaustive exploration of the historical abstraction reaches 8,564 states and 36,096 enabled transitions with no authored-invariant violation, and weakening each of 30 mutation-adequate guards exposes a minimal counterexample. The same model, however, strands 288 retirement-authorized states without a path to closure; the revised candidate PE-R1 removes that defect within a bounded re-containment, with no safety violation and no closure-unreachable state among 98,948 reachable states. The model separates current containment from containment history, Resolution Collapse from other authorized retirement bases, retirement basis from authority, successor from residual-custodian branches, restart basis from a narrow defect flag, and approval currentness from validity at execution. It still does not verify the substantive retirement basis, legal legitimacy, semantic adequacy or completion of notice and remedy, or real calendar authorization rules. The public-record illustrations provide traceable external examples of facts, reasons, review access, operational feedback, remedy, and responsibility, but their mechanism-based selection prevents treating them as an independent estimate of observability.

The result is neither a universal shutdown checklist nor a validated detector. It is an auditable and partially executable design specification: every transition has an owner and evidence requirement; every indicator has invalidity conditions; every decisive act remains outside the detector; and every unresolved case blocks closure until responsibility and remedy survive the exit. Within the framework proposed here, governance of a high-stakes AI-assisted workflow remains incomplete if the institution cannot also stop using it without abandoning the people, unresolved cases, records, remedy obligations, and decision capacity that the workflow reorganized.

# Appendix A. Trilogy Terminology Map {.unnumbered}

The terms below belong to different levels of analysis. None may acquire decision authority merely because it appears earlier in the chain.

| Term | Primary level | Meaning and authority boundary |
|---|---|---|
| Gate state | Case (Part I) | PASS, REVIEW, BLOCK or UNKNOWN; a diagnostic output, never an institutional act |
| Hard admissibility | Case (Part I) | Typed assessment (CLEAR, PROHIBITED, UNVERIFIED or CORRECTABLE) of the current proposed action; not created by a signature |
| Route and signed disposition | Case (Part I) | Separate typed outputs of Stage 1 and Stage 2; a signed disposition is not an execution |
| Execution event | Case (Part I) | Separately authorized act requiring current admissibility, Gate 1 and Gate 3 PASS, a bound snapshot, authority and a durable record |
| Incipient capacity-loss risk | Institution (Part II) | Research report of established J and G decline with N impairment not established; not an institutional determination |
| GCL-PC | Institution (Part II) | Research classification: procedural continuity, persistent J and G decline, protected-function impairment |
| Ordinary-exposure causal specification | Population (Part II) | Research estimand with separate identification and effect assessment; replaces the former PAC subtype |
| GDI and validity hold | Monitoring (Part III) | Candidate measure and investigation boundary; cannot authorize action |
| Governance incident | Institution (Part III) | Determination by a competent authority; may use but is not defined by a Part II profile |
| Resolution Collapse | Transition (Part III) | Authorized finding that remediation cannot restore operation within the approved horizon; one sufficient basis for retirement, not the only one |
| Circuit Breaker | Transition (Part III) | Authorized, scoped, reversible containment; not retirement or closure |
| Proper Ending and Authority Return | Institution (Part III) | Authorized retirement process and accountable disposition of decision capacity and residual duties |
| Closure and redeployment | Institution (Part III) | Completion of the exit episode, which does not extinguish residual duties; redeployment is a separate new deployment decision |

Table: Trilogy terminology map and authority boundaries. The same map appears in all three papers.

# Technical Appendix B. Governance Drift Indicators and Synthetic Stress Tests {.unnumbered #appendix-b}

This appendix is part of the same Part III SSRN paper. It contains the detailed measurement protocol, candidate Governance Drift Indicators, sequential decision rules, synthetic stress tests, sensitivity audit, and required external-validation program. The normative authority, Proper Ending, Authority Return, and transition guards remain in the main text; no indicator in this appendix may authorize containment, retirement, release, or redeployment.

## B.1 Construct-Validity Protocol {.unnumbered}

Before any threshold is activated, the institution must publish an indicator specification containing:

1. the protected function and hypothesized failure mechanism;

2. unit of analysis, time window, population, and exclusions;

3. construct definition and rationale for the measure;

4. source fields, provenance, missingness, retention, and access rules;

5. controls for case mix, model version, policy, workload, staffing, and reviewer experience;

6. expected behavior under failure and at least two benign alternatives;

7. baseline period, calibration sample, direction, threshold, persistence, and multiplicity handling;

8. subgroup and measurement-invariance tests;

9. alert recipient, investigative authority, response time, fallback, and a prespecified method for measuring diagnostic-review burden; and

10. scheduled review, retirement conditions, and anti-gaming tests.

The specification also includes a field-level availability and latency contract. For each rationale, review-time, dissent, remedy, verified-error, and outcome field it records the source event, source-system timestamp, earliest valid availability, expected and maximum latency, revision rule, censoring rule, and the escalation cutoff at which the field may be used. A prospective score may use only information available by its declared cutoff; late adjudication can update a retrospective reconstruction but cannot be backdated into a purportedly prospective alert.

Measures must be validated against independently reconstructed cases. A dashboard correlation with another dashboard is insufficient. Affected people and reviewers should participate in defining the protected function, while access to worker-level data must be proportionate and safeguarded against punitive secondary use.

## B.2 Candidate Governance-Drift Indicators {.unnumbered}

The following families are candidate measurement specifications, not validated instruments. They are not all prospective in the same sense. Review-time telemetry can be available contemporaneously; RIC requires a task-relevant target after the decision; and dissent-opportunity or verified-error variables may depend on later adjudication. Each family therefore requires an explicit availability timestamp and latency model before anyone may describe it as a leading indicator. Each targets a different component of meaningful oversight, has distinct invalidity conditions, and remains subordinate to independent investigation and authority.

### B.2.1 Rationale Information Contribution {.unnumbered}

Let Y be a task-relevant target available after the decision, C declared controls including case features and model output, R the rationale text, and Φ(R) a text representation fit only on training data. Fit a baseline predictor $f_0(C)$ and an augmented predictor $f_1(C,\Phi(R))$. For a proper held-out loss $L$,

$$\mathrm{RIC}_t = \bar L\big(Y, f_0(C)\big)_t - \bar L\big(Y, f_1(C,\Phi(R))\big)_t .$$

Positive RIC means that rationales add out-of-sample predictive information beyond the controls; a sustained decline is Rationale Information Decay. The target might be an independently adjudicated error class, appeal finding, or downstream outcome. It must not be the reviewer’s own approval decision, which would reward self-description.

In the historical prototype, C denotes a specified set of controls. The baseline includes standardized ai_score, model_confidence, complexity, risk, and workload, together with one-hot encoded policy_version and interface_version; the augmented model adds only the training-fitted text representation. Both models use the identical controls, training split, target, and loss. This is an implementation contract for the synthetic prototype, not a claim that the set blocks all confounding in a deployment.

In the reported historical prototype, the adjudicated class and rationale were generated separately from latent case facts. The text function accepts noisy observed facts—record age, source conflict, document availability, burden pattern, and policy version—but has no target-label argument. This removes the v3.0 pipeline’s direct class-to-template path. It does not create real independence: both products still come from one declared synthetic world.

RIC does not prove faithful reasoning. It can rise because rationales leak outcome labels, reproduce sensitive attributes, or are generated by the same model. Safeguards include temporal splitting, pipeline separation, source labeling, prohibited-token and permutation tests, human/model authorship distinction, adversarial boilerplate tests, and qualitative evidence audits. RIC is invalid if the target is unavailable, selectively observed without adequate correction, or normatively irrelevant. If the target arrives only after appeal, adjudication, or downstream harm, RIC is a retrospective or lagged diagnostic for that period rather than a prospective leading signal.

A harder gaming path is predictive semantic padding: a template or generator can add case-specific names, dates, risk-language, citations, and plausible detail that predicts the downstream label without recording the reviewer’s actual evidentiary reasoning. This can raise held-out RIC while oversight is hollow. A deployment test should therefore preregister adversarial padding and template-copy attacks; repeat RIC after stripping boilerplate, named entities, and policy tokens; swap rationales among matched cases; ablate cited evidence; measure template edit distance and source-grounding validity; and require blinded qualitative reconstruction of whether the cited evidence supports the disposition. Failure under any one diagnostic does not prove unfaithfulness, but a score that survives only surface-specificity features must not be treated as governance evidence. Secondary measures—case-specific entity grounding, evidence citation validity, within-template variation, and semantic clustering—can diagnose why RIC changed. They should not replace the held-out incremental test.

### B.2.2 Complexity-Responsive Review Time {.unnumbered}

Raw review time is ambiguous: both expertise and disengagement can make work faster. The relevant construct is whether attention remains responsive to legitimate complexity. Estimate, within a declared workflow and period,

$$\log T_i = \alpha_t + \beta_t K_i + \gamma_t^{\top} Z_i + u_{r(i)} + \varepsilon_i ,$$

where $T_i$ is active review time, $K_i$ an independently defined complexity or risk measure, $Z_i$ controls for workload, model confidence, policy, interface, and experience, and $u_{r(i)}$ reviewer effects where appropriate. The signal is a persistent, unexplained decline in $\beta_t$, especially when high-risk error or appeal residuals rise.

The prototype implements this equation on $\log T$ and encodes reviewer, policy, and interface categories as within-window fixed effects. The reported coefficient is the complexity coefficient after controlling for risk, workload, model confidence, reviewer experience, reviewer identity, policy version, and interface version. It does not report a raw-time slope or silently omit the declared controls.

Every window also records the design rank, number of columns, a condition number computed after scaling the numeric columns, and the minimum reviewer, policy-version, or interface-version cell count. The illustrative validity contract requires full rank, condition number no greater than 10,000, and every fixed-effect cell to contain at least three cases. A failed contract makes the reported slope not estimable and creates a validity hold. Classical and HC3 standard errors and an L2-regularized ridge-slope sensitivity delta are retained as diagnostics; they do not convert an invalid window into a valid estimate.

Instrumentation must exclude idle tabs, batch artifacts, and accessibility-related interaction patterns. Worker-level monitoring can create surveillance and speed pressure; governance should prefer aggregated windows, restricted access, minimum cell sizes, and a prohibition on using this GDI as an individual productivity score.

### B.2.3 Dissent Supply and Efficacy {.unnumbered}

Let $D_i=1$ when an authorized reviewer raises a material challenge, and let $O_i$ estimate the opportunity for justified dissent using independent adjudication or a validated error-opportunity model. The windowed dissent supply ratio is

$$\mathrm{DSR}_t = \frac{\sum_{i\in t} D_i}{\sum_{i\in t} \hat p^{D}_i}, \qquad \hat p^{D}_i = \widehat{\Pr}(D_i=1 \mid O_i, Z_i).$$
 A ratio below one indicates fewer dissent events than expected under baseline opportunity and controls. The denominator is a model and must be recalibrated when case mix, policy, or model quality changes. If the opportunity label is itself adjudication-dependent, the resulting DSR is likewise lagged unless a separately validated prospective opportunity model is available.

Let $E_i=1$ only when a recorded dissent event meets the preregistered eligibility rule for evaluating institutional response, and let $M_i=1$ only when that eligible event receives a substantive remedy within the declared horizon. Define remedy efficacy as

$$\mathrm{DE}_t = \frac{\sum_{i\in t} M_i}{\sum_{i\in t} E_i}.$$

Thus the numerator is timely substantive remedies for eligible dissent events, and the denominator is eligible dissent events—not all cases, all challenges, or all remedy records. The eligibility rule and the remedy horizon must be frozen before monitoring. In the synthetic code these are distinct fields (dissent_event, dissent_eligible, substantive_remedy, and remedy_within_horizon) so the denominator cannot silently revert to all dissent events. The prototype uses eight eligible events per window as an illustrative engineering floor, not as a power-derived or field-validated threshold. Below that minimum the value is not estimable (NE)—not zero. The choice prevents the prototype from presenting a remedy fraction based on only a handful of events as though it were stable, but it does not establish adequate statistical precision. A deployment study must preregister the minimum event count and report sensitivity to alternative floors (for example 4, 8, and 12) or justify a different rule through a domain-specific precision or power analysis. Sparse dissent plus adverse outcomes can itself be corroborating evidence, but the institution must not fabricate precision.

Raw disagreement is not a virtue. High dissent can reflect a poor model, unclear policy, or misaligned reviewers. The construct of interest is risk-adjusted corrective voice and the institution’s response to substantiated concerns.

## B.3 Coupling, Corroboration, and Sequential Decision Rule {.unnumbered}

### B.3.1 Outcome and Remedy Safeguards {.unnumbered}

Because governance traces are vulnerable to alternative explanations, containment requires a governance-relevant corroborating family. The prototype uses an adverse-outcome observed/expected ratio:

$$\mathrm{OER}_t = \frac{\sum_{i\in t} Y_i}{\sum_{i\in t} \hat p^{Y}_i}, \qquad \hat p^{Y}_i = \widehat{\Pr}(Y_i=1 \mid X_i, Z_i).$$

 Depending on the domain, corroboration can also come from independent case reconstruction, validated appeal findings, delayed safety events, substantiated dissent with failed remedy, or an external regulator. Observed outcomes are often selected and delayed. Monitoring must disclose censoring, appeal access, label source, delay distribution, and subgroup coverage. The prototype therefore reports two different quantities:

outcome_label_coverage, the fraction with an observed outcome label, and outcome_analyzable_coverage, the fraction with both that label and every required covariate for the frozen observed/expected model. Only the latter may establish estimability.

### B.3.2 Sequential Decision Rule {.unnumbered}

The prototype calibrates each indicator on a healthy development phase held out from model fitting but used to set control limits. It is therefore not an independent test set. Lower limits apply to RIC, time responsiveness, dissent supply, and remedy efficacy; an upper limit applies to adverse outcomes. Outcome corroboration is disabled below 60% outcome-analyzable coverage, even if nominal label coverage is higher. More than 20% unseen policy or interface versions, a declared case-mix hold based on the maximum absolute standardized mean shift across the numeric controls, or incomplete adjudication-dependent fields required by the current prototype, or an invalid review-time design creates a validity hold: the signal is preserved for investigation, but the prototype will not issue a Level-2 candidate until the measurement model is revalidated or the missing evidence arrives. This prototype check is a conservative collection of marginal mean-shift screens, not a general multivariate distribution test. A real deployment may use CUSUM, hierarchical control charts, or Bayesian updating, but it must validate operating characteristics under dependence and multiplicity. The escalation logic is intentionally asymmetric.

**Level 1—diagnostic signal.** Any indicator crosses its limit. The workflow owner checks data integrity and obvious changes, preserves evidence, and reports the signal. No automated punitive action follows. Operational burden is a separate operating characteristic, not a synonym for false Level-2 candidates. For an eligible monitoring period, let $W_1$ denote eligible windows with at least one Level-1 signal and $W_E$ denote all eligible monitored windows. Define the Level-1 diagnostic-window burden as

$$B_1 = W_1 / W_E .$$

Here an eligible Level-1 window means a complete, non-overlapping window of the declared size that the scorer evaluated; a validity hold remains in the denominator because it can itself require diagnostic work. A partial terminal window is excluded. Level-2 eligibility is narrower and is not substituted for $W_E$. A prospective study should pair $B_1$ with observed staff-minutes, queue delay, and investigation disposition per signal; low Level-2 false-candidate rates do not establish acceptable operational burden.

**Level 2—containment candidate.** At least two of the three governance-trace families—rationale, time, and dissent—are abnormal; dissent or estimable outcome evidence is among the abnormal or corroborating evidence; no policy, interface, covariate, or required-trace-availability hold is active; and the condition persists for two consecutive windows within the same measurement regime. A change in the observed policy-version or interface-version set marks a regime boundary and resets persistence; a validity hold in either window also breaks the chain. Language and time alone can never satisfy Level 2. The current synthetic prototype is a mixed-observability diagnostic because some components use adjudicated or verified-error fields. It therefore does not establish a fully prospective Level-2 detector. In a real prospective deployment, only variables available by the decision time for that escalation may contribute to the candidate; later adjudication may confirm, refute, or retrospectively reconstruct it. An authority satisfying the independence test in Section 8.1 determines whether scoped containment is justified.

**Level 2-S—predeclared subgroup containment candidate.** Aggregate normality does not override a severe localized pattern. For a safety-critical subgroup declared before monitoring, the Level-2 logic may be applied within that subgroup only when its minimum effective sample size, estimability contract, measurement regime, and multiplicity procedure were frozen in advance. A candidate requires either two abnormal governance-trace families within the subgroup or one abnormal trace plus independently reconstructed subgroup outcome/remedy evidence; persistence for two consecutive subgroup windows; no active validity hold; and an independent authority. Hierarchical shrinkage or another validated small-cell method should be used where appropriate, with family-wise or false-discovery error reported across the subgroup family. The authorized response is initially scoped to the affected subgroup unless broader evidence supports wider containment. The historical v5.9 synthetic reference implementation uses exactly one code-frozen subgroup, risk at least 0.56, a minimum of 35 cases per 250-case window, rationale and risk-adjusted dissent trace families, and an estimable adverse-outcome corroborator. It excludes the fixed-effects time family at that sample size. Because the subgroup boundary is also the generator’s constructed failure boundary, the result is an internal implementation and failure-recovery test only; a field protocol must replace and justify the subgroup, threshold, sample floor, and multiplicity method before any data are inspected.

**Level 3—emergency containment.** Credible evidence of imminent severe harm can trigger immediate action without waiting two windows. If a tested fallback exists, service-preserving containment remains preferred. If no tested fallback exists, the separately authorized emergency-safe-stop path may be used only when the record explains why continued operation is less defensible than temporary interruption, identifies triage and continuity measures, preserves evidence where feasible, and names the reviewing authority.

This is not an automated shutdown rule. It is a minimum evidentiary grammar for routing a case to an accountable decision maker.

## B.4 Synthetic Construct Stress Test {.unnumbered}

### B.4.1 Design {.unnumbered}

The historical prototype was reported to generate latent case facts, noisy reviewer-observed facts, a separately derived adjudicated class, case risk, workload, model confidence, policy and interface versions, reviewer identity and experience, outcomes, dissent events, remedy events, active review time, and synthetic rationale strings. Healthy rationales cite observed facts without class names. The primary constructed collapse phase substitutes generic boilerplate, weakens complexity-responsive attention and dissent, reduces remedy, and raises adverse outcomes. The adjudicated class is derived from latent facts and is not accepted as an input by the rationale generator. Latent facts, adjudication, noisy observations, institutional-process variables, and rationale text use five deterministic child streams spawned from each phase seed. This structural and random-stream separation narrows direct leakage and order-coupling routes but does not establish statistical independence. The pipeline uses 6,000 training cases to fit text and control models, 12,000 healthy development cases—48 non-overlapping windows—to set limits, and three monitoring phases of 3,000 cases each: healthy, benign efficiency, and abrupt collapse. The test suite also includes a deterministic safety test in which adjudication-dependent fields are withheld from part of a monitoring window; the scorer must enter a validity hold and suppress a containment candidate rather than crash or impute the missing labels. That test verifies fail-safe software behavior under missing evidence, not prospective detection performance. Monitoring windows contain 250 cases. Text features are fit on training data only. A leakage audit searches for prohibited target phrases and permutes development-phase rationales to test whether case alignment carries information beyond the marginal text distribution. The benign-efficiency phase is a negative contrast: review is faster, but the log-time complexity coefficient remains intact, rationale information remains useful, dissent remains opportunity-responsive, and outcomes remain near expectation. A window bootstrap reports how the finite development sample changes the limits; its ranges are stability diagnostics, not field confidence intervals.

All prototype thresholds are illustrative design constants, not empirically established operating points. The frozen choices include a three-scaled-MAD control limit, 250-case windows, two consecutive abnormal windows, a two-of-three governance-trace-family rule, a minimum of eight eligible dissent events for remedy efficacy, 60% outcome analyzable coverage, 20% unseen policy or interface versions, a 0.80 marginal case-mix shift limit, a maximum time-design condition number of 10,000, and a minimum fixed-effect cell count of three. They were fixed before benchmark generation to make the implementation auditable, not because theory or field data identifies them as optimal. A prospective study must preregister and justify its own constants, evaluate threshold and window sensitivity, and control false alerts under repeated, dependent, multi-indicator monitoring. Level 2-S adds one frozen illustrative subgroup: synthetic risk at least 0.56, with at least 35 subgroup cases in a 250-case window. It uses subgroup RIC and risk-adjusted dissent as the two governance-trace families and an estimable subgroup adverse-outcome ratio as corroboration; the fixed-effects time family is excluded at this smaller sample size. A candidate requires both traces, or one trace plus outcome corroboration, over two consecutive windows in one measurement regime. Only one subgroup family is tested, so the synthetic prototype applies no multiplicity adjustment; a field study with any additional subgroup must preregister and control the enlarged family. The 0.56 boundary is a generator-defined design constant, not an externally justified risk cutoff.

The historical benchmark generated 100 independent streams for each of 14 scenarios. Six are non-collapse contrasts: benign efficiency, benign rationale standardization, reviewer-composition shift, case-mix shift, policy shift, and delayed outcomes. Seven are constructed positive stresses: abrupt collapse, gradual collapse, mild gradual collapse, high-risk-localized collapse, copied-rationale collapse, collapse with the time channel masked, and collapse with the dissent-supply channel masked. One final stress combines collapse with a simultaneous policy shift and therefore tests the validity-hold rule. Case-mix and policy shifts are expected to preserve evidence while withholding an automated candidate. All thresholds and rules are frozen before benchmark generation. The masked-channel scenarios are not stand-alone “gaming” cases: the remaining collapse mechanisms and adverse outcomes are still active.

The historical design tested implementation behavior, negative controls, and discrimination within constructed scenario families. It is not a validation dataset, human-subjects study, or estimate of prevalence. The delayed_outcomes scenario delays the observed outcome channel but does not delay the synthetic adjudicated issue class, issue-opportunity variable, or verified-error field used elsewhere in the detector. The benchmark therefore does not demonstrate prospective operation under delayed adjudication. A field implementation must either use only contemporaneously available proxies for prospective routing or classify adjudication-dependent metrics as lagged diagnostics.

### B.4.2 Parameter Sensitivity Audit {.unnumbered}

A separate aggregate-rule local sensitivity audit varied monitoring-window size (125, 250, 500 cases), scaled-MAD multiplier (2, 3, 4), and persistence requirement (1, 2, 3 windows) across 25 independent runs for each of the 14 benchmark scenarios. This yields 9,450 run-configuration combinations. The audit is diagnostic rather than an optimization exercise: it asks whether the frozen aggregate operating point is locally fragile. Because changing window size also changes the number and timing of analyzed windows over a fixed stream, cross-window-size comparisons are not interpreted as clean causal effects. The most direct comparison therefore holds the window at 250 cases and varies only threshold and persistence.

| Scenario at 250-case window | MAD 2 / P1 | MAD 2 / P2 | MAD 2 / P3 | MAD 3 / P1 | MAD 3 / P2 | MAD 3 / P3 | MAD 4 / P1 | MAD 4 / P2 | MAD 4 / P3 |
|---|---|---|---|---|---|---|---|---|---|
| Mild gradual collapse | 100% | 100% | 100% | 100% | 100% | 84% | 96% | 44% | 12% |
| High-risk-localized collapse | 100% | 84% | 52% | 64% | 4% | 0% | 8% | 0% | 0% |

Table: Local sensitivity at 250-case monitoring windows. These are historical values from the version 5.9 computational artifact, reproduced as reported in version 6.2; they cannot be regenerated from the version 6.3 package.

The frozen design uses MAD 3 and persistence 2. In this 25-run sensitivity sample that setting detects 100% of mild gradual streams but only 4% of localized-collapse streams. Nearby settings move localized-collapse detection from 0% to 100% and mild-gradual detection from 12% to 100%. These figures do not replace the frozen 100-run benchmark below, which uses a different replication set. The 4% result is exactly 1 detection in 25 runs (Clopper–Pearson 95% interval 0.10%–20.35%), whereas the frozen benchmark reports 8 in 100 (3.52%–15.16%). The intervals overlap substantially; 4% versus 8% is ordinary finite-replication variation, not evidence that the operating point changed definition. Together the two replication sets show that the apparent operating characteristics are highly parameter-dependent and that no validated operating point has been established. A deployment study must therefore preregister thresholds, report a sensitivity surface, and evaluate subgroup-capable alternatives rather than presenting one convenient configuration as a property of the construct.

### B.4.3 Frozen Benchmark: Failure-Mode Characterization {.unnumbered}

| Phase | RIC | Log-time complexity slope | Dissent supply ratio | Dissent efficacy | Outcome O/E |
|---|---|---|---|---|---|
| Healthy monitoring | 0.295 | 0.788 | 1.001 | 0.575 | 0.899 |
| Benign efficiency | 0.184 | 0.762 | 0.965 | 0.530 | 1.021 |
| Constructed abrupt collapse | −0.491 | 0.083 | 0.110 | NE | 1.733 |

Table: Primary synthetic phase diagnostics at the frozen operating point. NE = not estimable. These are historical values from the version 5.9 computational artifact, reproduced as reported in version 6.2; they cannot be regenerated from the version 6.3 package.

The robust development limits are 0.166 for RIC, 0.617 for the log-time complexity slope, 0.460 for dissent supply, 0.243 for dissent efficacy, and 1.536 for outcome O/E. Across 400 resamples of the 48 non-overlapping development windows, the corresponding 2.5th–97.5th percentile limit ranges are 0.128–0.214, 0.576–0.659, 0.233–0.687, 0.169–0.436, and 1.282–1.697. These are resampling stability ranges under the constructed development data, not uncertainty intervals for deployment performance. Collapse-phase dissent efficacy is not estimated because fewer than eight eligible dissent events occur per window. The phase table’s healthy-monitoring RIC (0.295) and the following development-set diagnostic refer to different samples. On the full healthy development set, RIC is 0.298. Across 1,000 case-text permutations, the null contribution has mean -0.383 (2.5th-97.5th percentile -0.397 to -0.368), and 0/1,000 permuted values equal or exceed the observed RIC. No prohibited class phrase appears, and the adjudicated class is not an argument accepted by the rationale generator. These are leakage diagnostics, not proof that real rationales are independent or faithful.

![Synthetic GDI behavior across declared phases in the historical v5.9 execution, reproduced unchanged from version 6.2; it cannot be regenerated from the version 6.3 package. Dashed lines are calibration limits; the candidate is eligible for investigation routing only after the coupled rule persists for two windows.](figures/part3_figB1_gdi_v59.jpg){#fig:b1 width=78%}

The constructed abrupt collapse begins at case 24,000. The first Level-2 candidate is associated with the second collapse window and becomes available when that window closes at case 24,500: an availability delay of 500 cases. Reporting the window start would understate the actionable delay.

| Benchmark scenario | Expected class | Candidates per 100 | Exact 95% interval | Median delay (IQR), cases | Validity hold |
|---|---|---|---|---|---|
| Benign efficiency | negative | 0 | 0.00%–3.62% | — | 0% |
| Benign rationale standardization | negative | 0 | 0.00%–3.62% | — | 0% |
| Reviewer-composition shift | negative / revalidate | 0 | 0.00%–3.62% | — | 26% |
| Case-mix shift | negative / revalidate | 0 | 0.00%–3.62% | — | 100% |
| Policy shift | negative / revalidate | 0 | 0.00%–3.62% | — | 100% |
| Delayed outcomes | negative | 0 | 0.00%–3.62% | — | 0% |
| Abrupt collapse | positive | 100 | 96.38%–100% | 500 (500–500) | 0% |
| Gradual collapse | positive | 100 | 96.38%–100% | 1,500 (1,250–1,750) | 0% |
| Mild gradual collapse | positive | 100 | 96.38%–100% | 2,250 (2,000–2,750) | 0% |
| High-risk-localized collapse | positive | 8 | 3.52%–15.16% | 1,500 (1,375–2,125) | 0% |
| Copied-rationale collapse | positive | 100 | 96.38%–100% | 500 (500–500) | 0% |
| Collapse with time channel masked | positive | 100 | 96.38%–100% | 500 (500–500) | 0% |
| Collapse with dissent-supply channel masked | positive | 100 | 96.38%–100% | 500 (500–500) | 0% |
| Collapse plus concurrent policy shift | validity hold | 0 | 0.00%–3.62% | — | 100% |

Table: Frozen 14-scenario aggregate benchmark from the historical v5.9 computational artifact, carried forward unchanged. These are historical values from the version 5.9 computational artifact, reproduced as reported in version 6.2; they cannot be regenerated from the version 6.3 package.

| Rule at frozen setting | Localized candidates / 100 | Exact 95% interval | Median delay, cases | Candidates in each benign scenario |
|---|---|---|---|---|
| Aggregate Level 2 | 8 | 3.52%–15.16% | 1,500 | 0/100 |
| Level 2-S subgroup | 97 | 91.48%–99.38% | 1,000 | 0/100 |
| Union of Level 2 and 2-S | 98 | 92.96%–99.76% | 1,000 | 0/100 |

Table: Constructed localized-collapse recovery after adding the one fixed illustrative subgroup rule. These within-generator rates are not field sensitivity or specificity. These are historical values from the version 5.9 computational artifact, reproduced as reported in version 6.2; they cannot be regenerated from the version 6.3 package.

No benchmark stream produces a candidate during its pre-stress healthy segment; its 0/100 exact interval is again 0.00%–3.62%. The frozen v5.9 100-run-per-scenario benchmark, carried forward unchanged, also records Level-1 diagnostic burden. Among negative contrasts without a universal validity hold, benign efficiency has the highest mean post-stress Level-1 window rate at 0.338 even though it generates no Level-2 candidate; benign rationale standardization, reviewer-composition shift, and delayed outcomes are 0.0167, 0.0117, and 0.0058, respectively. Reviewer-composition shift places 26% of streams on a time-model validity hold because the frozen minimum-cell/rank contract is not always satisfied; this is conservative diagnostic behavior, not a false containment candidate. Thus absence of Level-2 false candidates does not imply negligible investigative burden: a benign operational change can still create frequent low-level signals. Level-1 burden must therefore be evaluated separately in any prospective study. The full and one-channel-masked collapses are deliberately easy for the remaining coupled indicators, and the mild stress reaches 100/100 only within this constructed replication set. More importantly, aggregate monitoring misses 92/100 high-risk-localized-collapse streams. The fixed Level 2-S rule recovers 97/100, and the union of aggregate and subgroup rules recovers 98/100, without a candidate in any of the 600 benign-scenario streams. This improvement is deliberately constructed: the subgroup boundary matches the generator’s declared localized-failure boundary, so it establishes only that the code can recover a predeclared subgroup failure rather than discover one. The concurrent policy shift suppresses every candidate by design while placing every stream on hold. These results are not evidence of a perfect detector. Every scenario remains a member of a generator designed with knowledge of the indicator families. The tests expose code behavior and specific blind spots; they do not reproduce open-world heterogeneity, dependence, institutional adaptation, or adversarial novelty. Because localized collapse remains almost always invisible to the aggregate rule, an aggregate-only implementation fails a necessary deployment precondition. Level 2-S demonstrates a bounded repair inside the generator, but subgroup definitions, measurement validity, multiplicity, stability, burden, and open-world performance must still be independently and prospectively evaluated before operational use.

## B.5 Retrospective Use and Required External Validation {.unnumbered}

A retrospective analysis can ask whether coupled traces preceded a known governance incident, but it must avoid hindsight thresholding. A defensible protocol freezes indicator definitions and thresholds using only pre-incident training data, reconstructs contemporaneously available evidence, models reporting delays, and compares the incident trajectory with unaffected workflows and placebo dates.

Public accounts of the Dutch childcare-benefits scandal illustrate why an algorithmic system, organizational incentives, procedural treatment, appeal, and remedy must be analyzed together (Dutch Data Protection Authority, 2020). That case is not used here as validation of the prototype. Without case-level data, prespecified measures, and a credible counterfactual, it is a motivating governance record rather than evidence of sensitivity or lead time.

### B.5.1 Required External Validation and Adversarial Test Program {.unnumbered}

Before operational use, a GDI system should pass at least the following tests:

1. independent requirements validation: before instrument fitting, a team independent of the author, vendor, and operational owner traces each transition and measurement requirement to applicable law, service obligations, affected-person priorities, worker constraints, and failure evidence; legal counsel and an affected-person advisory group record disagreements and unresolved requirements rather than being treated as ceremonial approvers;

2. content and convergent validity: expert and affected-party review plus agreement with independent case reconstruction;

3. discriminant validity: distinguish benign efficiency, learning, model improvement, policy change, and record-channel displacement;

4. temporal validation: fit on past periods and evaluate genuinely future windows;

5. external and subgroup validation: test new teams, sites, model versions, and protected or high-risk subgroups without silent recalibration, including subgroup-specific charts capable of detecting localized collapse;

6. operating characteristics: report Level-1 diagnostic-window burden, follow-up staff-minutes, queue delay, investigation disposition, Level-2 false-alert rates, detection probability, delay, positive predictive value under plausible prevalence, and intervention burden;

7. missingness and delay stress: simulate selective appeals, delayed adjudication, verified-error lag, outcome censoring, reporting lags, and sparse dissent;

8. dissent-estimability sensitivity: justify the minimum eligible-event rule through domain-specific precision or power analysis and report alternative event-count floors;

9. manipulation-resistance tests: copied rationales, model-generated prose, predictive semantic padding, artificial dwell time, strategic dissent tokens, and metric-target changes, including matched swaps, boilerplate and policy-token stripping, cited-evidence ablation, and blinded source-grounding review;

10. comparative case validation: add independently sampled successful, recovered, failure, and boundary workflows—including at least one relatively well-managed retirement or transfer—and at least two blinded coders to test discriminant validity, agreement, and coding reliability;

11. governance tabletop: exercise recipients, evidence preservation, ordinary containment, emergency safe-stop, notice, remedy, plural-successor Authority Return, and vendor exit; and

12. sunset review: retire indicators that lose meaning, create disproportionate surveillance, or fail to improve decisions.

Thresholds should be registered before prospective evaluation. Tuning a detector on the same incident used to evaluate it invalidates the claim about its operating characteristics. Machine-readable preregistration and data-dictionary templates are not included in the version 6.3 package; a prospective study would need to prepare them as part of a protocol with staged decision gates, role separation, a frozen analysis plan, readiness checks, and explicit no-claim rules when the event or site count is inadequate. Such templates are planning artifacts, not evidence that a field study has begun.

# Data, Code, and Reproducibility {.unnumbered}

The version 6.3 reproducibility package contains three layers that are kept separate. The historical layer contains only the v5.9 finite-state checker, byte-identical to the published file, together with its re-executed invariant and thirty-mutation outputs, whose SHA-256 values match those recorded for the historical run. It does not contain the other components of the v5.9 computational artifact: the public-record evidence matrix and codebook, the synthetic generator, the rationale-alignment and sensitivity audits, and the benchmark outputs could not be recovered for this version. The synthetic benchmark numbers, Tables B1–B4 and Figure B1 are therefore carried forward as reported in version 6.2 and are not reproduced by this package. The audit layer contains the follow-up reachability audit, which layers experimental models on the unmodified historical checker, computes backward reachability, deadlock classes and an exact strong-fairness subgraph search, and defines the PE-R1 candidate (audit key B3_S1). The revision layer contains the version 6.3 reproduction scripts. For this version, the baseline exploration of the historical replica M0 and of PE-R1 was re-executed and matched the recorded audit outputs, and the full 134-variant PE-R1 mutation suite was re-executed under the 250,000-state cap; the recomputed classification of all 134 variants matched the recorded audit output exactly. No participant or field data are introduced. A SHA-256 manifest covers every file in the package.

# Generative AI Use Disclosure {.unnumbered}

Generative AI systems were used throughout the preparation of this trilogy. OpenAI ChatGPT/Codex assisted during versions 5.0–6.2 with literature discovery, structural and language revision, code review, document generation and quality assurance; for version 6.3 it drafted revision specifications and candidate texts and code, and audited the release candidate by re-executing its verification code. Anthropic Claude reviewed Part II version 6.2, audited the revision candidates and constructed the counterexamples that led to corrections, conducted the follow-up reachability audit of the Part III guard model, wrote the Part I integrated model, re-executed the verification code, updated bibliographic records, and drafted the version 6.3 manuscripts under the author's direction.

Some AI review sessions were instructed to assess the supplied material without other systems’ conclusions. Actual isolation cannot be independently guaranteed. Information-isolated AI review is a procedural control on one source of bias; it is not independent human scholarly peer review. Several systems involved in review also helped write or revise the work; agreement among AI systems does not independently establish correctness. The trilogy has not undergone independent human peer review. The author directed the work, made every final decision, and remains responsible for every claim, citation, analysis and conclusion.

# Conflicts of Interest and Funding {.unnumbered}

The author declares no conflict of interest and received no external funding for this work.

# References {.unnumbered}

::: {.references}
Ada Lovelace Institute, AI Now Institute, and Open Government Partnership. (2021). *Algorithmic accountability for the public sector: Learning from the first wave of policy implementation*. Official report.

Adam, C., Bauer, M. W., Knill, C., & Studinger, P. (2007). The termination of public organizations: Theoretical perspectives to revitalize a promising research area. *Public Organization Review, 7*(3), 221–236. <https://doi.org/10.1007/s11115-007-0033-4>

Bankes, S. (1993). Exploratory modeling for policy analysis. *Operations Research, 41*(3), 435–449. <https://doi.org/10.1287/opre.41.3.435>

Bardach, E. (1976). Policy termination as a political process. *Policy Sciences, 7*(2), 123–131.

Baykurt, B. (2022). Algorithmic accountability in U.S. cities: Transparency, impact, and political economy. *Big Data & Society, 9*(2), Article 20539517221115426. <https://doi.org/10.1177/20539517221115426>

Behn, R. D. (1978). How to terminate a public policy: A dozen hints for the would-be terminator. *Policy Analysis, 4*(3), 393–413.

Bhatt, U., & Sargeant, H. (2024). When should algorithms resign? A proposal for AI governance. *Computer, 57*(10), 99–103. <https://doi.org/10.1109/MC.2024.3431328>

Biller, R. P. (1976). On tolerating policy and organizational termination: Some design considerations. *Policy Sciences, 7*(2), 133–149. <https://doi.org/10.1007/BF00143911>

Brewer, G. D. (1978). Termination: Hard choices, harder questions. *Public Administration Review, 38*(4), 338–344.

Burnat, F. A. D., & Davidson, B. I. (2026). Scaling, lock-in, and proxy compliance: A political economy of responsible AI. *Proceedings of the AAAI/ACM Conference on AI, Ethics, and Society*, 9(1). <https://doi.org/10.1609/aies.v9i1.43162>

Calboreanu, E. (2026). LATTICE: A governance-first architecture for authorized autonomous AI operations. *Frontiers in Artificial Intelligence, 9*, 1800407. <https://doi.org/10.3389/frai.2026.1800407>

Childcare Allowance Parliamentary Inquiry Committee. (2020). *Ongekend onrecht: Verslag Parlementaire ondervragingscommissie Kinderopvangtoeslag*. House of Representatives of the States General of the Netherlands. Official Dutch report.

Daugbjerg, C., & Bazzan, G. (2026). When negative feedback becomes self-undermining: Instrument termination in environmental regulation. *Policy and Society*, Article puaf050. <https://doi.org/10.1093/polsoc/puaf050>

deLeon, P. (1978). Public policy termination: An end and a beginning. *Policy Analysis, 4*(3), 369–392.

DeYoung, J., Jain, S., Rajani, N. F., Lehman, E., Xiong, C., Socher, R., & Wallace, B. C. (2020). ERASER: A benchmark to evaluate rationalized NLP models. *Proceedings of ACL 2020*, 4443–4458. <https://doi.org/10.18653/v1/2020.acl-main.408>

Digital Transformation Agency. (2025). *Technical standard for government’s use of artificial intelligence: Decommission (Statements 40–42)*. Australian Government. Official standard.

Ditz, J. C., Lazar, V., Lichtmeß, E., Plesch, C., Heck, M., Baum, K., & Langer, M. (2026). Secure human oversight of AI: Threat modeling in a socio-technical context. *Proceedings of the AAAI/ACM Conference on AI, Ethics, and Society*, 9(2). <https://doi.org/10.1609/aies.v9i2.43187>

Dutch Data Protection Authority. (2020). *Methods used by Dutch Tax Administration unlawful and discriminatory*. Official page.

European Union. (2024). *Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence, Article 14*. Official Journal of the European Union. Official text.

Farquhar, S., Kossen, J., Kuhn, L., & Gal, Y. (2024). Detecting hallucinations in large language models using semantic entropy. *Nature, 630*, 625–630. <https://doi.org/10.1038/s41586-024-07421-0>

Ferrario, A., & Hatherley, J. (2026). *Update opacity: Epistemic accessibility and governance under AI system change*. arXiv preprint arXiv:2606.00037. <https://doi.org/10.48550/arXiv.2606.00037>

Ferrario, A. (2026). *A methodology for auditable trustworthiness levels in AI lifecycle governance*. arXiv preprint arXiv:2607.16130. <https://doi.org/10.48550/arXiv.2607.16130>

Frimpong, V. (2026a). *The Governance Inversion Hypothesis: Why more AI regulation may produce less organisational control (version 2)*. arXiv preprint arXiv:2606.26117. <https://doi.org/10.48550/arXiv.2606.26117>

Frimpong, V. (2026b). *AI Debris: Residual risk and the afterlife of failed AI systems*. arXiv preprint arXiv:2606.12432. <https://doi.org/10.48550/arXiv.2606.12432>

Gama, J., Žliobaitė, I., Bifet, A., Pechenizkiy, M., & Bouchachia, A. (2014). A survey on concept drift adaptation. *ACM Computing Surveys, 46*(4), Article 44. <https://doi.org/10.1145/2523813>

Gaube, S., Langer, M., Miller, T., Baum, K., Dachselt, R., Feit, A. M., Gadiraju, U., Kaur, H., Keane, M. T., Landers, R., Laux, J., Liao, Q. V., Lim, B., Onnasch, L., Schrills, T., Sonenberg, L., Tan, C., Tintarev, N., Xiao, Z., & Zhang, H. (2026). *Keeping an eye on AI: A framework for effective human oversight of AI systems*. arXiv preprint arXiv:2605.16278. <https://doi.org/10.48550/arXiv.2605.16278>

Grimm, V., Railsback, S. F., Vincenot, C. E., Berger, U., Gallagher, C., DeAngelis, D. L., Edmonds, B., Ge, J., Giske, J., Groeneveld, J., Johnston, A. S. A., Milles, A., Nabe-Nielsen, J., Polhill, J. G., Radchuk, V., Rohwäder, M.-S., Stillman, R. A., Thiele, J. C., & Ayllón, D. (2020). The ODD protocol for describing agent-based and other simulation models: A second update to improve clarity, replication, and structural realism. *Journal of Artificial Societies and Social Simulation, 23*(2), 7. <https://doi.org/10.18564/jasss.4259>

Han, H. (2026). *Governing agentic AI in FinTech*. arXiv preprint arXiv:2608.11344, version 2. <https://doi.org/10.48550/arXiv.2608.11344>

Havyarimana, J. C. (2026). *The hollowing of office: Human sovereignty, compelled assent, and the loss of discernment when AI governs in practice*. SSRN Working Paper 7218298. <https://doi.org/10.2139/ssrn.7218298>

International Organization for Standardization and International Electrotechnical Commission. (2023a). *ISO/IEC 42001:2023: Information technology—Artificial intelligence—Management system*. Official standard page.

International Organization for Standardization and International Electrotechnical Commission. (2023b). *ISO/IEC 5338:2023: Information technology—Artificial intelligence—AI system life cycle processes*. Official standard page.

International Organization for Standardization and International Electrotechnical Commission. (2023c). *ISO/IEC 8183:2023: Information technology—Artificial intelligence—Data life cycle framework*. Official standard page.

International Organization for Standardization and International Electrotechnical Commission. (2024). *ISO/IEC TS 8200:2024: Information technology—Artificial intelligence—Controllability of automated artificial intelligence systems*. Official standard page.

International Organization for Standardization and International Electrotechnical Commission. (in press). *ISO/IEC 42105: Information technology—Artificial intelligence—Guidance for human oversight of AI systems*. Stage: under publication when this version was prepared. Official project page.

Jacovi, A., & Goldberg, Y. (2020). Towards faithfully interpretable NLP systems: How should we define and evaluate faithfulness? *Proceedings of ACL 2020*, 4198–4205. <https://doi.org/10.18653/v1/2020.acl-main.386>

Kuipers, S., Yesilkagit, K., & Carroll, B. (2018). Coming to terms with termination of public organizations. *Public Organization Review, 18*(2), 263–278. <https://doi.org/10.1007/s11115-017-0376-4>

Lai, V., Chen, C., Smith-Renner, A., Liao, Q. V., & Tan, C. (2023). Towards a science of human–AI decision making: An overview of design space in empirical human-subject studies. *Proceedings of FAccT 2023*, 1369–1385. <https://doi.org/10.1145/3593013.3594087>

Langer, M., Baum, K., & Schlicker, N. (2025). Effective human oversight of AI-based systems: A signal detection perspective on the detection of inaccurate and unfair outputs. *Minds and Machines, 35*, Article 1. <https://doi.org/10.1007/s11023-024-09701-0>

Langer, M., Lazar, V., & Baum, K. (2026). *On the complexities of testing for compliance with human oversight requirements in AI regulation*. In B. Steffen (Ed.), Bridging the Gap Between AI and Reality: AISoLA 2025 (Lecture Notes in Computer Science, Vol. 16220, pp. 160–169). Springer. <https://doi.org/10.1007/978-3-032-07132-3_11>

Lee, M. H. (2026). From accuracy to readiness: Metrics and benchmarks for human–AI decision-making: An initial exploration. *Extended Abstracts of the 2026 CHI Conference on Human Factors in Computing Systems*, Article 310, 1–10. <https://doi.org/10.1145/3772363.3798377>

Lewis, D. E. (2002). The politics of agency termination: Confronting the myth of agency immortality. *The Journal of Politics, 64*(1), 89–107. <https://doi.org/10.1111/1468-2508.00119>

Lin, F., Ge, Q., Xu, L., Li, P., Gao, X., Xing, S., Yamada, K., Zhang, Z., Zhang, H., & Tu, Z. (2026). *Position: Human-centric AI requires a minimum viable level of human understanding*. arXiv preprint arXiv:2602.00854. <https://doi.org/10.48550/arXiv.2602.00854>

Manheim, D., & Homewood, A. (2025). *Limits of safe AI deployment: Differentiating oversight and control (version 2)*. arXiv preprint arXiv:2507.03525. <https://doi.org/10.48550/arXiv.2507.03525>

Michigan Office of the Auditor General. (2016). *Claimant Services: Unemployment Insurance Agency (Performance Audit Report 641-0318-14)*. Official report.

Morrison, E. W. (2014). Employee voice and silence. *Annual Review of Organizational Psychology and Organizational Behavior, 1*, 173–197. <https://doi.org/10.1146/annurev-orgpsych-031413-091328>

Morrison, E. W. (2023). Employee voice and silence: Taking stock a decade later. *Annual Review of Organizational Psychology and Organizational Behavior, 10*, 79–107. <https://doi.org/10.1146/annurev-orgpsych-120920-054654>

National Cyber Security Centre of Ireland. (2026, June 30). *Securing AI adoption in the public sector: Cyber security guidelines for AI deployments*. Official guidance.

National Institute of Standards and Technology. (2023a). *Artificial Intelligence Risk Management Framework (AI RMF 1.0) (NIST AI 100-1)*. <https://doi.org/10.6028/NIST.AI.100-1>

National Institute of Standards and Technology. (2023b). *NIST AI RMF Playbook*. Official companion resource.

National Institute of Standards and Technology. (2024). *Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile (NIST AI 600-1)*. <https://doi.org/10.6028/NIST.AI.600-1>

Niu, X. (2026). *The chancellor trap: Administrative mediation and the hollowing of sovereignty in the algorithmic age*. arXiv preprint arXiv:2602.18474. <https://doi.org/10.48550/arXiv.2602.18474>

Obimakinde, K. (2026). *The AI Sunset Protocol: Operationalizing exit, semantic portability, and migration for high-dependency systems*. SSRN Working Paper 6157026 (revised; first posted as The AI Sunset Protocol: A socio-technical framework for high-dependency AI decommissioning). <https://doi.org/10.2139/ssrn.6157026>

OECD. (2026). *OECD Due Diligence Guidance for Responsible AI*. OECD Publishing, Paris. <https://doi.org/10.1787/41671712-en>

Office of Management and Budget. (2025). *M-25-21: Accelerating Federal Use of AI through Innovation, Governance, and Public Trust*. Executive Office of the President, 3 April 2025.

Page, E. S. (1954). Continuous inspection schemes. *Biometrika, 41*(1/2), 100–115. <https://doi.org/10.1093/biomet/41.1-2.100>

Popchanovska, E., Gjorgjevikj, A., Rizinski, M., Chitkushev, L. T., Vodenska, I., & Trajanov, D. (2026). *When AI fails, what works? A data-driven taxonomy of real-world AI risk mitigation strategies*. arXiv preprint arXiv:2603.04259. <https://doi.org/10.48550/arXiv.2603.04259>

Royal Commission into the Robodebt Scheme. (2023). *Report of the Royal Commission into the Robodebt Scheme*. Australian Government. Official report and recommendations.

Sato, T. (2026a). *Workflow-Centric AI Governance: A Typed Gate Contract for Accountable Human–AI Decisions (working paper v6.3)*. SSRN. <https://doi.org/10.2139/ssrn.5911063>

Sato, T. (2026b). *Procedural Continuity and Governing-Capacity Loss in AI-Assisted Institutions: A Descriptive Profile Model and a Rejection-Oriented Research Program (working paper v6.3)*. SSRN. <https://doi.org/10.2139/ssrn.5913703>

Shu, W., & Wei, P. (2026). *AI safety as control of irreversibility: A systems framework for decision-energy and sovereignty boundaries*. arXiv preprint arXiv:2605.01415. <https://doi.org/10.48550/arXiv.2605.01415>

Solozobov, O. (2026). *Label-free detection of governance evidence degradation in risk decision systems*. arXiv preprint arXiv:2604.17836. <https://doi.org/10.48550/arXiv.2604.17836>

Sunset Advisory Commission. (2025). *Sunset in Texas: 90th Legislature, 2026–27*. Texas Sunset Advisory Commission.

Tallam, K. (2026). *The khipu problem: Institutional legibility under distributed cognition*. arXiv preprint arXiv:2606.12414. <https://doi.org/10.48550/arXiv.2606.12414>

Texas Government Code. (n.d.). *Chapter 325: Sunset Law (Texas Sunset Act)*, including §325.017, Procedure after termination. Texas Legislature. <https://statutes.capitol.texas.gov/Docs/GV/htm/GV.325.htm>

Turpin, M., Michael, J., Perez, E., & Bowman, S. R. (2023). Language models don’t always say what they think: Unfaithful explanations in chain-of-thought prompting. *Advances in Neural Information Processing Systems*, 36, 74952–74965. <https://doi.org/10.52202/075280-3275>

Wang, Z. (2026). *Final authority in AI governance: Frontier-provider sovereignty and action-centered deployer governance*. arXiv preprint arXiv:2607.13040. <https://doi.org/10.48550/arXiv.2607.13040>

Winecoff, A. A., & Bogen, M. (2025). Improving governance outcomes through AI documentation: Bridging theory and practice. *Proceedings of the 2025 CHI Conference on Human Factors in Computing Systems*, Article 1194, 1–18. <https://doi.org/10.1145/3706598.3713814>

Zhu, L., Lu, Q., Ding, M., Lee, S. U., & Wang, C. (2026). Designing meaningful human oversight in AI. *AI and Ethics, 6*, Article 286. <https://doi.org/10.1007/s43681-026-01147-7>

:::
