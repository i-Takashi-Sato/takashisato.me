| Term | Primary level | Meaning and authority boundary |
|---|---|---|
| Gate state | Case (Part I) | PASS, REVIEW, BLOCK or UNKNOWN; a diagnostic output, never an institutional act |
| Hard admissibility | Case (Part I) | Typed assessment (CLEAR, PROHIBITED, UNVERIFIED or CORRECTABLE) of the current proposed action; not created by a signature |
| Route and signed disposition | Case (Part I) | Separate typed outputs of Stage 1 and Stage 2; a signed disposition is not an execution |
| Execution event | Case (Part I) | Separately authorized act requiring current admissibility, Gate 1 and Gate 3 PASS, a bound snapshot, authority and a durable record |
| Incipient capacity-loss risk | Institution (Part II) | Research report of established J and G decline with N impairment not established; not an institutional determination |
| GCL-PC | Institution (Part II) | Research classification: procedural continuity, persistent J and G decline, protected-function impairment |
| Ordinary-exposure causal specification | Population (Part II) | Research estimand with separate identification and effect assessment; replaces the former PAC subtype |
| GDI and validity hold | Monitoring (Part III) | Candidate measure and investigation boundary; cannot authorize action |
| Governance incident | Institution (Part III) | Determination by a competent authority; may use but is not defined by a Part II profile |
| Resolution Collapse | Transition (Part III) | Authorized finding that remediation cannot restore operation within the approved horizon; one sufficient basis for retirement, not the only one |
| Circuit Breaker | Transition (Part III) | Authorized, scoped, reversible containment; not retirement or closure |
| Proper Ending and Authority Return | Institution (Part III) | Authorized retirement process and accountable disposition of decision capacity and residual duties |
| Closure and redeployment | Institution (Part III) | Completion of the exit episode, which does not extinguish residual duties; redeployment is a separate new deployment decision |

Table: Trilogy terminology map and authority boundaries. The same map appears in all three papers.
