---
title: "Workflow-Centric AI Governance"
subtitle: "A Typed Gate Contract for Accountable Human–AI Decisions"
author: "Takashi Sato"
part: "Workflow-Centric AI Governance Trilogy · Part I"
version: "Working Paper · Version 6.3"
date: "November 2026"
doi: "SSRN DOI 10.2139/ssrn.5911063"
runninghead: "WORKFLOW-CENTRIC AI GOVERNANCE"
---

# Abstract {.unnumbered}

The mere presence of a reviewer does not make a human–AI decision accountable. A decision workflow must distinguish diagnostic findings, routing, authenticated dispositions, and actual actions. This paper specifies a typed two-stage gate contract and a separate execution boundary. Stage 1 maps three four-valued diagnostic outputs to a unique route; Stage 2 records a typed instruction only within authorized review. Neither routing nor an authenticated instruction replaces legal admissibility, current evidence, execution authority, or a durable decision record. The revised design separates correctable objections from prohibitions and requires revalidation of the candidate action when its evidence or authorization becomes stale. Finite conformance tests check that routing and disposition clauses are mutually exclusive and exhaustive. An integrated finite model applies the same routing, disposition and execution guards to diagnosis, review, waiting, re-entry, evidence expiry and fallback. Among 134,672 reachable abstract states, no commitment violates the separately encoded requirements, no nonterminal state is deadlocked, and every state has a path to a recorded outcome. These exercises do not establish the legality, operational effectiveness, or real-world safety of a deployment. The contribution is a testable workflow specification and implementation contract, not a claim that human oversight alone suffices.

**Keywords:** AI governance; accountable decisions; contestability; human oversight; sociotechnical systems; typed protocols; workflow governance

# Introduction

AI governance often begins with model properties—data quality, accuracy, robustness, fairness, explainability, and monitoring. Those properties matter, but the model does not govern its own use. Consequential outcomes arise from an institutional sequence that defines the task, selects evidence, configures interfaces, sets production expectations, allocates authority, routes exceptions, and turns a recommendation into action. A technically adequate model can therefore participate in an inadequately governed decision.

A human reviewer alone does not cure this defect. Automation can shift attention and response criteria in ways associated with complacency and automation bias (Parasuraman & Manzey, 2010). Cognitive forcing can reduce overreliance, but at a measurable cost in time and user preference (Buçinca et al., 2021). Effective oversight consequently depends on discriminability, incentives, task conditions, and an actual ability to intervene rather than on a human job title alone (Langer et al., 2025). Recent frameworks specify the conditions more directly: meaningful oversight requires defined roles, process architecture, epistemic capacity, cognitive space, decisional authority, and effective intervention channels (Gaube et al., 2026; van de Sande et al., 2026).

This paper shifts the primary unit of governance from the model alone to the decision workflow. The question is whether a common typed contract can preserve distinct diagnostic functions without allowing preliminary machine states, missing evidence, or absent institutional capacity to become a final action by default. The proposed answer is a case-level routing specification. It deliberately does not solve the larger questions addressed by Parts II and III of the trilogy: whether a nominally compliant institution is losing governing capacity over time, and how a failing workflow can be contained and ended without abandoning remedy or decision responsibility.

The paper makes five contributions within this scope. First, three diagnostic functions share one four-state type without being collapsed into one score. Second, a total triage function separates preliminary diagnostic states from routing status: all-PASS yields only S1_EXECUTION_ELIGIBLE, while a separate authorized-disposition function prevents authority availability from masquerading as a decision event in reviewed cases. Third, a proposed append-only record would connect each action to the evidence, execution authority, fallback, and subsequent correction. Fourth, both finite-stage semantics are checked over their declared input domains, and an integrated finite model links them to the execution guard and to temporal re-entry, with selected behavioral and source mutations. Fifth, the contract is compared with official public records and research on human oversight to define both what is externally traceable and what remains unvalidated.

# Relation to Existing Work and the Incremental Boundary

Evidence hierarchy. Peer-reviewed research and official investigations anchor established empirical and institutional claims. Recent 2026 preprints and working papers are used principally to map the limits of the contribution and emerging terminology; they are not treated as independent validation of this contract, and claims that depend only on them remain provisional.

## Sociotechnical accountability and workflow as unit of analysis

Internal algorithmic auditing has already extended accountability beyond model evaluation into organizational processes and documentation (Raji et al., 2020). Fairness research has shown that technical abstractions can erase social context and that invalid measurement can defeat an apparently rigorous analysis (Selbst et al., 2019; Jacobs & Wallach, 2021). These literatures establish that model performance cannot be separated from the institutional conditions under which a system is used.

The contribution is narrower. It specifies what must remain explicit between a model output and a final institutional act: the state of required evidence, the nature of a diagnostic concern, the authority allowed to change an action, the availability of review capacity and a workable fallback, and the disposition of cases that cannot be resolved on time.

## Reliance, contestability, and practical authority

Human–AI performance is not captured by accuracy alone. Evaluation must distinguish appropriate reliance, complementary competence, safety, learning, and error recovery (Lai et al., 2023; Lee, 2026). Contestability likewise cannot be reduced to a post-hoc appeal form: meaningful intervention requires an opportunity, intelligible grounds, and an actor who can alter the decision (Almada, 2019). Elish's moral-crumple-zone analysis further warns that responsibility can be concentrated on a frontline human who lacks meaningful control (Elish, 2019).

The contract therefore separates diagnostic state from authority. A human reviewer who cannot slow, modify, reject, defer, or reach an independent authority does not supply effective arbitration simply by approving a proposal. Bainbridge (1983) showed that automation can leave people responsible for exactly the situations it has made them least practiced to handle; the contract therefore treats review capacity as an explicit routing condition rather than an assumption.

## Recent work narrows the novelty claim

By 2026, research had addressed human gates, meaningful oversight, resource-constrained supervision, action-boundary control, or the requirement that humans retain understanding and intervention capacity. Gaube et al. (2026) provide a cross-disciplinary framework for effective human oversight; Langer et al. (2026) explain why compliance testing must move beyond checklist evidence; Manheim and Homewood (2025) distinguish oversight from operational control and foreground feasibility limits; Azevedo (2026) formalizes uncertainty-aware oversight allocation; Lin et al. (2026) define a cognitive-integrity threshold below which oversight becomes merely procedural; and van de Sande et al. (2026) identify epistemic capacity, cognitive space, decisional authority, and intervention effectiveness as conditions for meaningful medical-AI oversight. Mazzocchetti (2026) separately specifies runtime action-boundary control with trusted provenance, fail-closed execution, and a settlement layer. These works preclude a novelty claim based on 'humans must be able to intervene' or on separating a model proposal from executable action. Peer-reviewed work from 2026 further narrows this boundary. Zhu et al. (2026) provide a layered-agency framework, a catalogue of oversight mechanisms, and end-to-end design patterns for meaningful human oversight. Calboreanu (2026) supplies a governance-first agent architecture with deterministic policy gates, execution authorization, escalation, and cryptographic audit. These contributions likewise rule out any claim that structured rationales, circuit breakers, end-to-end oversight patterns, deterministic gates, or gated execution are novel here.

The proposed contribution is a cross-domain, typed institutional case contract that distinguishes diagnostic state, routing status, authority credential, service capacity, fallback authorization, fallback readiness, and the actual signed disposition. Missing evidence remains UNKNOWN; preliminary machine states cannot directly become institutional denials; and unresolved cases remain visible rather than disappearing from performance denominators. The paper does not claim the trusted-provenance or execution-isolation contribution developed for agentic runtime systems. Whether this institutional contract improves real oversight remains an empirical question.

## Regulatory and standards boundary

Article 14 of the EU AI Act requires effective human-oversight capabilities for applicable high-risk systems and addresses awareness of automation bias and the ability, where appropriate, to disregard, override, reverse, or interrupt outputs (European Union, 2024). NIST AI RMF 1.0 addresses roles, human–AI configurations, contextual limits, monitoring, appeal, override, incident response, recovery, and decommissioning (NIST, 2023). ISO/IEC 42105, which had completed its approval stage and was listed as under publication when this version was prepared, provides lifecycle guidance on human control and monitoring and explicitly extends ISO/IEC TS 8200 (ISO/IEC, in press). This paper may supply evidence useful to selected practices in those instruments, but it does not establish legal conformity, standards conformity, regulatory sufficiency, or sector-specific compliance.

| Family (representative sources) | Already established | Proposed incremental specification | Unestablished |
|---|---|---|---|
| Effective human oversight (Gaube et al., 2026; van de Sande et al., 2026; Zhu et al., 2026) | Architectures, roles, epistemic and decisional conditions, design patterns | Common diagnostic type and total routing for each case | Comparative usability and effectiveness |
| Reliance and cognitive capacity (Parasuraman & Manzey, 2010; Buçinca et al., 2021; Lin et al., 2026) | Automation bias, cognitive forcing, cognitive-integrity thresholds | Explicit evidence and capacity conditions in routing | Preservation of cognition |
| Oversight versus control (Manheim & Homewood, 2025; Azevedo, 2026) | Conceptual distinction, feasibility limits, uncertainty-aware allocation of oversight | Separation of diagnosis, signed disposition and execution | Security and organizational feasibility |
| Runtime authorization architectures (Calboreanu, 2026; Mazzocchetti, 2026) | Deterministic policy verdicts, gated tool execution, escalation, fail-closed execution, signed or hash-linked audit | Institutional case contract: typed hard admissibility, signed disposition only within authorized review, unresolved cases kept visible | Runtime security and performance |
| Contestability and accountability (Almada, 2019; Elish, 2019; Raji et al., 2020) | Challenge, explanation, appeal, internal audit | Record binding reasons, authority and action | Real remedy effects |
| Regulation and standards (European Union, 2024; NIST, 2023; ISO/IEC, in press; Langer et al., 2026) | Oversight, override, appeal, lifecycle governance, compliance testing | Auditable state and disposition evidence | Legal sufficiency or conformity |

Table: Incremental boundary relative to adjacent accounts. Sources are representative; the comparison establishes neither priority nor completeness.

# Method and Claim Boundary

The paper follows a design-science logic: identify a recurrent governance failure, construct an artifact, expose its assumptions, and test whether the artifact behaves consistently under declared conditions (Hevner et al., 2004). The primary evaluation is the finite contract itself, complemented by execution-boundary, temporal and integrated exercises. The public-record analysis establishes traceability only.

| Evaluation | Evidence | Excluded inference |
|---|---|---|
| Finite routing and disposition | 1,024 Stage-1 and 1,144 Stage-2 inputs; two same-author encodings | Independent proof of specification correctness |
| Execution boundary | Finite guard grid; selected denial and positive witnesses | Truth of externally supplied predicates, legal compliance |
| Temporal projection | Finite transition exploration and DEFER history monitor | Integrated domain execution, unconditional liveness |
| Integrated model | Static functions driven through a finite temporal model under abstraction lemmas L1–L3 | Real clocks, identities, payload binding, records infrastructure, unconditional progress |
| Public-record traceability | Shared fifteen-unit corpus | Causal identification, prevalence, prevention |
| Literature boundary | Direct comparisons with related work | Priority or effectiveness by citation count |

Table: Evaluation scope.

The contribution concerns architectural separation, conformance of finite functions to stated clauses, traceability of governance objects, and explicit treatment of unresolved evidence and institutional unavailability. A checker can faithfully implement an erroneous specification. The validity of the legal, factual and organizational requirements remains a separate question.

# Domain Contract

Before any gate is used, the institution defines a versioned domain contract. The contract states the protected decision function, admissible inputs, model recommendations, permissible institutional actions, hard constraints, value and impact questions, temporal-validity rules, role and authority matrix, fallback process, review service levels, record-retention rules, and monitoring plan. A recommendation is not an institutional action; the contract must state the transition between the two.

| Contract object | Minimum content | Failure condition |
|---|---|---|
| Decision scope | Affected parties, consequences, excluded uses | Scope drift without review |
| Evidence | Required fields, provenance, missingness, validity | Evidence missing or uninterpretable |
| Authority | Review, execution, modify, reject, defer, escalate | Nominal responsibility without power |
| Execution | Action and version, bound evidence, current credentials, separation of duties, audit | Eligibility mistaken for execution |
| Capacity | Queue, protected time, deadline, owner | Unresourced review |
| Fallback | Authorized alternative, independently assessed readiness | Nominal service continuity |
| Record and remedy | Reasons, notice, appeal, correction, retention | Action cannot be reconstructed or challenged |

Table: Minimum domain contract objects.

The domain contract must state whether an all-PASS proposal may be executed automatically, requires an additional human or service authorization, or must enter another domain-specific control. It must also specify the executor, permissible action, scope, credential freshness and revocation, separation-of-duties rules, audit witness or logging, and failure behavior. S1_EXECUTION_ELIGIBLE is therefore never self-executing. The architecture is inappropriate where the institution cannot define a lawful fallback, cannot grant reviewers or executors effective authority, cannot retain the minimum evidence lawfully, or cannot resource review without systematic pressure to bypass it. In such conditions, the appropriate response may be to forgo, narrow, or suspend deployment rather than refine the interface. The case-time inputs r, c, b, and f are route-local availability variables; they are not a substitute for deployment-level readiness. Before the case contract is activated, the domain contract must separately state which capabilities—including fallback, review service, identity/authorization services, record infrastructure, and emergency handling—are mandatory as standing deployment preconditions. A domain may therefore prohibit execution even when Stage 1 returns S1_EXECUTION_ELIGIBLE if a required deployment-level readiness condition is not met. This separation prevents a truth-table flag from being mistaken for a complete operating-readiness judgment.

The domain contract SHALL identify the proposed action and its version, the evidence and policy snapshots on which each decision depends, the applicable hard constraints, the authority to issue a disposition, and the distinct authority to execute it. Each waiting route SHALL identify a responsible owner, a condition for re-entry, a review deadline, an escalation recipient, and a lawful protective response if the deadline cannot be met. Expiry is not approval. When neither review nor fallback can be provided, the institution SHALL record the unresolved condition and seek a competent resolution; automatic action is not licensed by resource failure. Deployment-level readiness remains separate from case-time routing availability.

A committed action requires an accountable execution record binding the case, candidate action, evidence, policy, actor, authority, disposition (where required), time, and result. The domain must define a durable commit or a recoverable, auditable protocol that prevents an unrecorded action from being treated as a completed decision. Recording failure, authority failure, and loss of evidence are distinct failure modes. Technical completion does not extinguish obligations of notice, challenge, and remedy.

# Three Diagnostic Gates and Authorized Arbitration

Each gate returns PASS, REVIEW, BLOCK or UNKNOWN. PASS means the gate's own predicate is satisfied, not final authorization. REVIEW identifies a question requiring authorized judgment; BLOCK pauses the proposed action and is not a final rejection. UNKNOWN identifies missing, stale, contradictory or uninterpretable evidence. Diagnostic functions remain distinct; the routing decision consumes their tuple rather than treating a gate as permission to skip another.

## Gate 1: Hard constraints and admissibility

BLOCK is a diagnostic finding, not a final denial. Gate 1 SHALL distinguish an action affirmatively admissible under applicable hard constraints (CLEAR), an action prohibited by a non-waivable rule (PROHIBITED), a constraint whose satisfaction cannot yet be established (UNVERIFIED), and a correctable impediment (CORRECTABLE). These are typed external assessments; the checker does not establish their truth. No mode may commit the candidate unless its current hard assessment is CLEAR and Gate 1 is PASS. A correctable impediment must first be corrected or authoritatively re-evaluated; signing does not itself clear it. A signed disposition cannot transform a prohibited or unverified action into an admissible one. Gate 3 must also return PASS for the current candidate in every execution mode. A non-PASS temporal diagnostic requires reassessment; an authenticated instruction or a separately asserted freshness flag cannot override it. Both current Gate-3 PASS and a valid, bound snapshot are necessary; the latter protects against expiry or a change after diagnosis. Gate 2 REVIEW or BLOCK may be resolved through the authorized review process when no non-waivable constraint remains. Authorized judgment can correct a factual or interpretive error, establish that a rule is inapplicable, or propose a materially different action; it cannot waive a non-waivable constraint. MODIFY identifies a changed candidate, whose binding and admissibility are assessed anew. A separately authorized fallback is assessed against its own evidence and constraints; the original proposal's UNKNOWN state is not permission to execute an inadequately evidenced alternative.

## Gate 2: Value, impact and conflict

Gate 2 identifies material tensions between values, proportionality concerns, conflicting objectives, and distributional or rights-sensitive issues that should not be collapsed into a single optimization score. It can return REVIEW when tradeoffs require contextual judgment even if no hard prohibition is present. A generic ethics score cannot compensate for a failure to specify the relevant values.

## Gate 3: Temporal validity and evidence reliability

Gate 3 asks whether the evidence, policy, system version, and relevant assumptions are current enough for the decision. Temporal validity matters because even a formally complete record can be stale. The gate distinguishes 'known adverse' from 'unknown because the basis is no longer trustworthy.'

In every committing mode, Gate 3 must be PASS for the current candidate and its evidence, policy, version and action snapshot must remain fresh. A signed instruction may initiate reassessment, not override a non-PASS temporal diagnosis. The execution service must establish binding and recheck validity when an earlier decision basis changes.

## Authorized human arbitration

Missing evidence and authorized review capacity permit an evidence-hold route; other non-PASS cases with review authority and capacity permit an authorized review route. The reviewer must receive the proposal, gate reasons, evidence, uncertainty, available alternatives and scope of authority. A disposition is an authenticated instruction from a competent authority, distinct from execution. Authorization of the instruction and authorization of the actual executor are separate. The domain contract specifies authentication, scope, credential issue and revocation, freshness, any dual-control requirement and failure behavior. The finite checker treats these services' predicates as truthful inputs, not as validated credentials. A signed disposition can resolve reviewable Gate-2 objections; it cannot substitute for current Gate-1 and Gate-3 PASS. A valid REJECT yields a final stop for the candidate; DEFER is a waiting state, not final denial.

# Total Routing Semantics and Finite-Domain Verification

Let P denote the all-PASS tuple, U the presence of UNKNOWN, R = r ∧ c, and B = b ∧ f. The Stage-1 route type is disjoint from the Stage-2 disposition type. Exactly one of the following clauses holds:

| Stage-1 route | Necessary and sufficient condition |
|---|---|
| S1_EXECUTION_ELIGIBLE | P |
| S1_EVIDENCE_HOLD | ¬P ∧ U ∧ R |
| S1_AUTHORIZED_REVIEW | ¬P ∧ ¬U ∧ R |
| S1_FALLBACK | ¬P ∧ ¬R ∧ B |
| S1_UNRESOLVED | ¬P ∧ ¬R ∧ ¬B |

Table: Stage-1 routing clauses. Each route is defined by its necessary and sufficient condition.

Only a valid review route permits entry into Stage 2. An instruction is either Absent or Present(command, validity); Absent has no validity flag. The five command variants are RELEASE, MODIFY, REJECT, DEFER, and INVOKE_FALLBACK. An absent or invalid instruction yields S2_PENDING_REVIEW. A present valid instruction maps respectively to RELEASE_PENDING_EXECUTION, MODIFY_PENDING_RECHECK, FINAL_STOP, AUTHORIZED_DEFER, or FALLBACK_PENDING_EXECUTION if B is true; an unavailable signed fallback yields S2_UNRESOLVED. These outputs describe dispositions; none establishes that execution occurred. Actual signature, credential and legal validation remain separately defined domain services.

The execution boundary evaluates the current candidate action rather than relying on a stale route label. Every committing action requires affirmative hard admissibility, current PASS at Gates 1 and 3, a current bound evidence/policy/action snapshot, execution authority and standing readiness, and a durable decision record. Relevant evidence classified as UNKNOWN cannot support commitment. Direct execution requires current all-PASS diagnostics. A reviewed RELEASE can resolve Gate-2 REVIEW or BLOCK, but cannot override Gate 1 or Gate 3. It requires resolution of reviewable objections plus the current instruction bound to the exact action. A MODIFY requires fresh assessment of the changed action; in the conservative candidate implemented here, it must satisfy all-PASS or return for a new adjudication. If executed specifically under a MODIFY disposition, the current bound instruction is required. A separately assessed all-PASS proposal may instead enter the ordinary direct route, if the domain contract permits that route and no unresolved defer or other binding restriction remains; its provenance must retain the earlier disposition. A fallback requires independently established evidence and constraints for the alternative, authorization, operational readiness, and a current bound invocation when required by Stage 2. Expiry invalidates an unused execution binding, not an action correctly executed before expiry. The model must distinguish instruction acceptance from actual execution and completion.

Waiting statuses are not terminal actions. A signed DEFER suspends action until a documented authorized resume following satisfaction of the specified re-entry condition, or an authorized reassignment after escalation. Escalation alone is not permission to execute; neither a fresh diagnosis nor an all-PASS result bypasses the defer. Resume and reassignment return to an unbound assessment state. An unresolved case may be re-routed after repair or referred to a competent authority; a fallback has a separately recorded start and completed or failed outcome. A deadline triggers escalation; it creates neither authority, evidence, nor approval. Liveness depends on explicit assumptions about responsive authorities, resources and environmental updates. No unconditional guarantee of institutional completion follows from the routing functions.

## Example of a bounded re-entry

Suppose a case enters authorized review with a Gate-2 BLOCK and current PASS at Gates 1 and 3. A valid RELEASE records an authorized resolution of that objection. If the underlying policy or evidence changes before action, the unused binding expires. A fresh diagnosis and current snapshot must be established; the existing signature alone does not establish validity. A signed DEFER cannot be bypassed by ordinary re-routing; only the specified authorized re-entry or escalation followed by reassignment can lift the waiting restriction. Figure 1 summarizes the resulting process; the integrated model in Section 6.2 executes these sequences.

![Case-level process. Stage 1 routes every diagnostic tuple to exactly one status; Stage 2 records a signed disposition only inside authorized review; the execution boundary re-checks the current candidate regardless of route or signature. Dashed arrows return to diagnosis from EVIDENCE HOLD after new evidence, from UNRESOLVED after repair or referral, from DEFER after authorized resume or reassignment, and from the execution boundary when a candidate is stale or changed. A MODIFY creates a changed candidate that must be diagnosed again before it can be executed.](figures/part1_fig1_process.pdf){#fig:process width=100%}

## Verification and claim boundary

The comparison retains the historical v6.2 counts. The candidate Stage 1 preserves the 1,024-input distribution (16, 148, 104, 189, 567 in the order above). Stage 2 has 26 eligible diagnostic tuples × 11 instruction variants × 4 fallback-flag settings = 1,144 inputs, conditional on a valid review entry. Removing the 104 structurally impossible absent-but-valid instruction inputs reduces pending-review configurations from 728 to 624; the other historical category counts are unchanged under the typed disposition mapping. The checker compares two encodings over all 1,024 and 1,144 inputs respectively; their outputs agree. Both encodings were written by the same author from the same specification interpretation. Agreement tests implementation conformance, not the correctness of that interpretation. Counting alternative output labels does not measure mutation coverage. A separate requirement-probe suite executes twelve selected source mutants, including a shared error in which both route encodings omit fallback readiness; all twelve are detected. This is a bounded set of seeded faults, not a measure of all possible faults.

A conservative execution-guard exercise enumerates 655,360 syntactic combinations (five modes, three four-valued diagnostics, four hard-assessment values, and nine external Boolean predicates). Among these, 614,400 have a non-CLEAR hard assessment or non-PASS Gate 1; the explicit denial probe rejects all of them. A further probe rejects every one of the 491,520 combinations with Gate 3 other than PASS, even if freshness is asserted and all other predicates are favorable. The union of hard-admissibility and temporal-diagnostic denial conditions comprises 645,120 combinations (overlap counted once). Of the full syntactic grid, 114 combinations permit execution, compared with 162 in candidate 0.3; the 48 removed combinations were RELEASE with non-PASS Gate 3. These counts describe a Boolean abstraction; they estimate neither risk nor decision frequencies. The selected source mutants include omission of the Gate-3 guard from the implementation alone and from both encodings; the separate requirement probe detects both. The two same-author guard encodings agree; this is not an independent proof of safety. The temporal projection has 1,254 reachable states and 8,908 non-self labeled transitions. A separate history monitor tracks an outstanding signed DEFER through 1,286 product states and 9,156 labeled edges including self-loops; it finds no commit before an explicit authorized resume or reassignment, and detects a seeded reroute bypass. Positive witnesses reach both resume and reassignment, fallback completion and failed-fallback escalation. These are synthetic configuration and transition counts, not institutional cases or probabilities. The temporal projection abstracts actual diagnostic, instruction, and fallback changes and does not contain an independent Gate-3 state.

The integrated model connects these previously separate checks. Its commit transitions call the same `triage`, `disposition` and `can_execute` functions as the static exercises, so the transition model uses the same guard as the static tests; safety is checked against separately written requirement predicates that do not call `can_execute`. Each state carries the candidate, its three gate values and hard assessment, snapshot freshness, the conjunctions R and B, authority, record readiness, the execution mode, the current instruction and its binding, and any pending DEFER and re-entry condition. Environment events may change any of these; a deadline initiates escalation but cannot create authority or evidence; every authority change invalidates an unused instruction; and a changed candidate (MODIFY or fallback alternative) is unassessed until it has been diagnosed again. The state space is reduced by three lemmas checked exhaustively before exploration over 656,384 cases: REVIEW and BLOCK are interchangeable for routing and the execution guard (L1); PROHIBITED, UNVERIFIED and CORRECTABLE are interchangeable for the guard (L2); and routing depends on availability only through R = r ∧ c and B = b ∧ f (L3). Diagnosis is applied one component at a time by default; a full re-diagnosis variant reaches the same states and the same commit set.

Breadth-first exploration reaches 134,672 states and 1,787,292 transitions. No reachable commitment violates the following requirements:

- Hard admissibility CLEAR, Gate 1 and Gate 3 PASS in every mode, and no UNKNOWN evidence.
- A current bound snapshot, authority, and a record.
- No elapsed deadline and no pending DEFER.
- All-PASS for a direct, modified or fallback candidate; a ready fallback where one is used; and a current bound instruction where a disposition is required.

 Every state has a path to a terminal outcome (executed, rejected, or fallback completed), and no non-terminal state is deadlocked; this is existential progress (EF), not a guarantee that every run terminates, which would depend on responsive authorities and environment. Nine mutants test the model. Six are detected with a witness: a reroute out of DEFER, a signature outside a valid review route, a commit without a current bound snapshot, a resume without its re-entry condition, and source mutants that drop the Gate-3 guard or the hard-admissibility type from `can_execute`. Three are equivalent only with respect to commitments: a RELEASE that survives re-diagnosis, a commit that ignores a pending DEFER, and a guard without the fallback-readiness conjunct each produce exactly the baseline set of reachable commit transitions. This is not equivalence of the transition systems. The first mutant reaches 135,632 states rather than 134,672, so its graph differs; for the other two the state counts coincide, but identity of their transition graphs was not tested. In each case another guard (snapshot binding, the DEFER waiting state, or fallback routing) blocks the same commitments, so within the model the mutated check is redundant defense in depth for the commit requirements rather than an untested requirement.

| Measure | v6.2 historical reported abstraction | v6.3 |
|---|---:|---:|
| Stage 1 inputs | 1,024 | 1,024 |
| Stage 2 inputs | 1,248 | 1,144 |
| Stage 2 pending review | 728 | 624 |
| Other Stage 2 categories (release, modify, reject, defer, fallback, unresolved) | 104 / 104 / 104 / 104 / 26 / 78 | 104 / 104 / 104 / 104 / 26 / 78 |
| Selected source mutants detected | 9 of 9 (historical report) | 12 of 12 (candidate tests, different suite) |
| Guard grid | Not reported | 655,360 |
| Current G3 non-PASS permitted | Not evaluated | 0 |
| Integrated model: reachable states / transitions | Not reported | 134,672 / 1,787,292 |
| Integrated model: violations / deadlocks / states without path to outcome | Not reported | 0 / 0 / 0 |
| Integrated model mutants | Not reported | 6 detected, 3 commit-set equivalent |

Table: Historical versus revised verification. The original v6.2 author checker was not obtained; the historical mutation definitions and the current suite are not identical.

The integrated model remains an abstraction: it assumes truthful predicates, represents one candidate at a time, and does not verify real clocks, identity, actual authority, payload binding, authenticated data, records infrastructure, or unconditional progress. Agreement between the guard and the requirement predicates is agreement between two same-author encodings of one specification.

# Decision Record and Accountability

Every consequential case should generate an append-only decision record sufficient to reconstruct the transition from recommendation to institutional action. At minimum it contains contract and model versions; recommendation and proposed action; gate inputs, outputs, and reason codes; Stage-1 routing status; evidence provenance and temporal status; review, execution, and fallback credentials and their scopes; the actual Stage-2 instruction where applicable, its authority validity, and the separate execution event and result; fallback or override; decision latency; notice and challenge route; downstream correction where lawfully measurable; and any later amendment. For an all-PASS case, the record must distinguish the S1_EXECUTION_ELIGIBLE timestamp from the later action timestamp and identify the rule and actor or service that authorized execution.

The record is not a demand to retain every datum indefinitely. Retention, access, minimization, security, and deletion are domain-specific controls. A useful implementation can separate operational, audit, and notice views while preserving a verifiable chain of responsibility.

| Role | Non-delegable accountability | Evidence |
|---|---|---|
| Policy owner | Purpose, legal basis, protected interests, exception policy | Approved contract and change record |
| System owner | Model limits, versions, technical monitoring | Validation, incident and release records |
| Workflow owner | Staffing, queue, thresholds, fallback, bypass controls | Workload and routing review |
| Case reviewer | Case disposition within scope | Case decision record |
| Executor | Actual action within scope, durable result record | Bound execution witness |
| Independent / competent authority | Escalation or suspension within mandate | Recorded reviewable rationale |

Table: Accountability roles.

This allocation does not eliminate shared responsibility. Leadership decisions about staffing, interfaces and fallback cannot be transferred to the last operator by requiring a signature. The decision record must preserve waiting conditions, re-entry, commitment and outcome, including fallback completion or failure. A durable commit or recoverable auditable failure protocol is required, but not implemented by the finite checker.

# Public-Record Traceability Illustrations

The trilogy uses a shared, frozen corpus of fifteen passage-level evidence units from three official investigations: Australia's Robodebt Royal Commission, the Dutch parliamentary inquiry into the childcare-allowance scandal, and Michigan's unemployment-insurance claimant-services audit (Royal Commission into the Robodebt Scheme, 2023; Childcare Allowance Parliamentary Inquiry Committee, 2020; Michigan Office of the Auditor General, 2016). The cases are purposively selected negative illustrations. They are not a representative sample, do not classify cases under this contract, and cannot establish that the architecture would have prevented harm. The three official investigations concern automated and algorithmic decision systems deployed before contemporary generative AI and large language models. They are not direct evidence about LLM-based workflows, and the papers neither equate those earlier systems with AI in general nor treat them as a separate category to which the analysis does not apply.

| Contract object | Official-record trace | Design implication | Unsupported inference |
|---|---|---|---|
| Sufficient evidence | Michigan fact gathering and reason giving | Preserve provenance and missingness | Typed gate would have produced correct result |
| Facts, reasons, review | Michigan and Robodebt review pathways | Intelligible challenge grounds | Effect on appeal success |
| Lawful authority and records | Robodebt legal foundations, assumptions, scrutiny | Versioned ownership of records and decisions | Documentation creates lawful oversight |
| Proportionality | Dutch group-based all-or-nothing administration | Categorical signal cannot settle value judgment | Generic gate meets legal standard |
| Remedy and continuity | Robodebt and Dutch delayed dispute handling and compensation | Keep unresolved cases visible | Routing order sufficient in any jurisdiction |

Table: Traceability, not prevention evidence. Original corpus and source locators are retained from v6.2.

The evidence establishes only traceability: independent official investigations treat evidence, reasons, review, authority, proportionality, records, and remedy as consequential workflow objects. The same records also show the limit of the artifact. Typed states cannot decide whether a legal basis is valid, a reason is adequate, a review pathway is accessible, or a protected interest has been weighed legitimately.

The same frozen fifteen-unit corpus is reused in Parts II and III to keep source locators and coding lineage comparable across the trilogy. Reusing the corpus risks fitting the narrative to the theory: the same negative records cannot serve as three independent validations merely because each paper asks a different traceability question. The papers claim neither cross-paper convergence, triangulation, replication, nor cumulative validation. Each theory requires new positive, negative, and boundary cases selected independently of its own terminology.

# Deployment Evaluation and Failure Criteria

Before deployment, pre-specify construct validity of diagnostics and reason codes, reviewer comprehension, actual authority, review capacity, fallback continuity under realistic interruption, record integrity and contestability, comparative burden and protected-function performance, and sunset conditions. Include tests for revoked credentials, expired or changed evidence, Gate-3 disagreement with freshness, unavailable record services, re-entry after DEFER, failed fallback and lawful remedy. Evaluate subgroup and accessibility effects, protected review time and privacy. A lower-complexity workflow is preferable if it provides comparable protection with less burden. Reject, narrow or suspend the architecture if queues systematically remain unresolved, review authority is nominal, UNKNOWN is bypassed, fallback is illusory or substantive reasons become ritual.

# Relationship to Parts II and III

Part I addresses individual cases; Part II examines institutional capacity over time; Part III specifies the authorized response and disposition of institutional functions (Sato, 2026b, 2026c).

No Part I route, disposition, or execution event establishes governing-capacity loss under procedural continuity (GCL-PC), an institutional incident, or Resolution Collapse by definition. Part II provides a research classification; Part III specifies a separate institutional determination and authorized response. The distinction prevents a local decision label from acquiring organizational retirement authority.

| Part I concept | Not equivalent to |
|---|---|
| BLOCK | Final denial, institutional incident or retirement |
| S2_FINAL_STOP | Proper Ending of the entire workflow |
| S1_UNRESOLVED or S2_UNRESOLVED | Proof of GCL-PC, normality or automatic retirement authority |
| Persistent routing failure | Authorized institutional determination |

Table: Cross-level separation.

# Limitations

The finite specification represents selected properties of an organization, not the organization as a whole. Its inputs are assumed to be correctly classified; it does not verify the semantic adequacy of evidence, legal rules, value judgments, or authority. The same organization that misreports capacity or fallback readiness can make a formally safe routing function operationally unsafe.

Neither the three-diagnostic decomposition nor the two-stage priority is claimed to be universal or optimal. Some domains require additional diagnostics, emergency containment, multiple signatures, appeal before execution, or a different priority order. Others may be safer with fewer state transitions. Any extension should preserve the distinction among preliminary diagnosis, routing status, credentialed authority, and an actual disposition event and should be subjected to its own exhaustive or property-based tests. The public-record corpus is narrow, negative, purposive, and author-coded. It supports source traceability but not causal identification, prevalence, specificity, or comparative effectiveness. No participant, field, or prospective operational data are analyzed.

The contract can itself create harm through delay, surveillance, bureaucratic ritual, or over-documentation. A workflow has not succeeded if it prevents one class of error by making lawful service inaccessible. Governance therefore requires service, remedy, and capacity outcomes in addition to formal state correctness.

Both encodings and the current requirement probes derive from the same specification process. Selected mutants do not measure all fault classes. The legal-status type and Gate-3 guard reject inconsistent non-PASS configurations, but cannot establish the truth of external evidence or detect every shared interpretation error. The integrated model checks one candidate at a time under abstraction lemmas, truthful predicates and existential progress. It does not establish unconditional liveness or a real institution's implementation of records, remedy, or authority, and three of its mutants are equivalent only in their reachable commitments because other guards block the same commitments.

# Conclusion

Accountable oversight requires evidence, substantive judgment, actual capacity to intervene, lawful alternatives, and responsibility for unresolved cases. The revised typed contract separates case diagnosis, routing, authenticated disposition and execution. Its finite exercises demonstrate the specified separation within bounded abstractions and detect selected implementation faults, including a temporal-gate omission and a DEFER bypass. They neither establish optimality nor guarantee legal or field effectiveness. The contract serves as the case-level entry point of a trilogy in which institutional diagnosis and authorized exit remain separate levels of analysis.

# Appendix A. Trilogy Terminology Map {.unnumbered}

The terms below belong to different levels of analysis. None may acquire decision authority merely because it appears earlier in the chain.

| Term | Primary level | Meaning and authority boundary |
|---|---|---|
| Gate state | Case (Part I) | PASS, REVIEW, BLOCK or UNKNOWN; a diagnostic output, never an institutional act |
| Hard admissibility | Case (Part I) | Typed assessment (CLEAR, PROHIBITED, UNVERIFIED or CORRECTABLE) of the current proposed action; not created by a signature |
| Route and signed disposition | Case (Part I) | Separate typed outputs of Stage 1 and Stage 2; a signed disposition is not an execution |
| Execution event | Case (Part I) | Separately authorized act requiring current admissibility, Gate 1 and Gate 3 PASS, a bound snapshot, authority and a durable record |
| Incipient capacity-loss risk | Institution (Part II) | Research report of established J and G decline with N impairment not established; not an institutional determination |
| GCL-PC | Institution (Part II) | Research classification: procedural continuity, persistent J and G decline, protected-function impairment |
| Ordinary-exposure causal specification | Population (Part II) | Research estimand with separate identification and effect assessment; replaces the former PAC subtype |
| GDI and validity hold | Monitoring (Part III) | Candidate measure and investigation boundary; cannot authorize action |
| Governance incident | Institution (Part III) | Determination by a competent authority; may use but is not defined by a Part II profile |
| Resolution Collapse | Transition (Part III) | Authorized finding that remediation cannot restore operation within the approved horizon; one sufficient basis for retirement, not the only one |
| Circuit Breaker | Transition (Part III) | Authorized, scoped, reversible containment; not retirement or closure |
| Proper Ending and Authority Return | Institution (Part III) | Authorized retirement process and accountable disposition of decision capacity and residual duties |
| Closure and redeployment | Institution (Part III) | Completion of the exit episode, which does not extinguish residual duties; redeployment is a separate new deployment decision |

Table: Trilogy terminology map and authority boundaries. The same map appears in all three papers.

# Data, Code, and Reproducibility {.unnumbered}

The reproducibility package contains `part1_v63_candidate.py` (typed routing, disposition and execution guard), `part1_acceptance.py` (two-encoding conformance, guard grid and requirement probes), `gate3_regression.py` (regression for the Gate-3 counterexample of an earlier candidate), `part1_integrated_model.py` (the integrated finite model, lemmas, mutants and progress analysis), `part1_fulldiagnose_check.py` (comparison of the default single-component diagnosis with full re-diagnosis), their JSON outputs, run instructions and a SHA-256 manifest. All scripts use the Python standard library only. The historical author-side v6.2 checker is not included because it was not available; historical counts are reported as published and are not merged with the revised suite. No operational or participant data are used.

# Generative AI Use Disclosure {.unnumbered}

Generative AI systems were used throughout the preparation of this trilogy. OpenAI ChatGPT/Codex assisted during versions 5.0–6.2 with literature discovery, structural and language revision, code review, document generation and quality assurance; for version 6.3 it drafted revision specifications and candidate texts and code, and audited the release candidate by re-executing its verification code. Anthropic Claude reviewed Part II version 6.2, audited the revision candidates and constructed the counterexamples that led to corrections, conducted the follow-up reachability audit of the Part III guard model, wrote the Part I integrated model, re-executed the verification code, updated bibliographic records, and drafted the version 6.3 manuscripts under the author's direction.

Some AI review sessions were instructed to assess the supplied material without other systems’ conclusions. Actual isolation cannot be independently guaranteed. Information-isolated AI review is a procedural control on one source of bias; it is not independent human scholarly peer review. Several systems involved in review also helped write or revise the work; agreement among AI systems does not independently establish correctness. The trilogy has not undergone independent human peer review. The author directed the work, made every final decision, and remains responsible for every claim, citation, analysis and conclusion.

# Conflicts of Interest and Funding {.unnumbered}

The author declares no conflict of interest and received no external funding for this work.

# References {.unnumbered}

::: {.references}
Almada, M. (2019). Human intervention in automated decision-making: Toward the construction of contestable systems. *Proceedings of the Seventeenth International Conference on Artificial Intelligence and Law*, 2–11. <https://doi.org/10.1145/3322640.3326699>

Azevedo, C. R. B. (2026). *Minimal oversight: Uncertainty-aware governance for delegated AI systems*. arXiv preprint arXiv:2606.15563. <https://doi.org/10.48550/arXiv.2606.15563>

Bainbridge, L. (1983). Ironies of automation. *Automatica, 19*(6), 775–779. <https://doi.org/10.1016/0005-1098(83)90046-8>

Buçinca, Z., Malaya, M. B., & Gajos, K. Z. (2021). To trust or to think: Cognitive forcing functions can reduce overreliance on AI in AI-assisted decision-making. *Proceedings of the ACM on Human-Computer Interaction*, 5(CSCW1), Article 188. <https://doi.org/10.1145/3449287>

Calboreanu, E. (2026). LATTICE: A governance-first architecture for authorized autonomous AI operations. *Frontiers in Artificial Intelligence, 9*, 1800407. <https://doi.org/10.3389/frai.2026.1800407>

Childcare Allowance Parliamentary Inquiry Committee. (2020). *Ongekend onrecht: Verslag Parlementaire ondervragingscommissie Kinderopvangtoeslag*. House of Representatives of the States General of the Netherlands. Official report.

Elish, M. C. (2019). Moral crumple zones: Cautionary tales in human-robot interaction. *Engaging Science, Technology, and Society, 5*, 40–60. <https://doi.org/10.17351/ests2019.260>

European Union. (2024). *Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence, Article 14*. Official Journal of the European Union.

Gaube, S., Langer, M., Miller, T., Baum, K., Dachselt, R., Feit, A. M., Gadiraju, U., Kaur, H., Keane, M. T., Landers, R., Laux, J., Liao, Q. V., Lim, B., Onnasch, L., Schrills, T., Sonenberg, L., Tan, C., Tintarev, N., Xiao, Z., & Zhang, H. (2026). *Keeping an eye on AI: A framework for effective human oversight of AI systems*. arXiv preprint arXiv:2605.16278. <https://doi.org/10.48550/arXiv.2605.16278>

Hevner, A. R., March, S. T., Park, J., & Ram, S. (2004). Design science in information systems research. *MIS Quarterly, 28*(1), 75–105. <https://doi.org/10.2307/25148625>

International Organization for Standardization and International Electrotechnical Commission. (in press). *ISO/IEC 42105: Information technology—Artificial intelligence—Guidance for human oversight of AI systems*. Stage: under publication when this version was prepared. Official project page.

Jacobs, A. Z., & Wallach, H. (2021). Measurement and fairness. *Proceedings of the 2021 ACM Conference on Fairness, Accountability, and Transparency*, 375–385. <https://doi.org/10.1145/3442188.3445901>

Lai, V., Chen, C., Smith-Renner, A., Liao, Q. V., & Tan, C. (2023). Towards a science of human-AI decision making: An overview of design space in empirical human-subject studies. *Proceedings of FAccT 2023*, 1369–1385. <https://doi.org/10.1145/3593013.3594087>

Langer, M., Baum, K., & Schlicker, N. (2025). Effective human oversight of AI-based systems: A signal detection perspective on the detection of inaccurate and unfair outputs. *Minds and Machines, 35*, Article 1. <https://doi.org/10.1007/s11023-024-09701-0>

Langer, M., Lazar, V., & Baum, K. (2026). *On the complexities of testing for compliance with human oversight requirements in AI regulation*. In B. Steffen (Ed.), Bridging the Gap Between AI and Reality: AISoLA 2025, LNCS 16220, 160–169. Springer. <https://doi.org/10.1007/978-3-032-07132-3_11>

Lee, M. H. (2026). From accuracy to readiness: Metrics and benchmarks for human-AI decision-making: An initial exploration. *Extended Abstracts of the 2026 CHI Conference on Human Factors in Computing Systems*, Article 310, 1–10. <https://doi.org/10.1145/3772363.3798377>

Lin, F., Ge, Q., Xu, L., Li, P., Gao, X., Xing, S., Yamada, K., Zhang, Z., Zhang, H., & Tu, Z. (2026). *Position: Human-centric AI requires a minimum viable level of human understanding*. arXiv preprint arXiv:2602.00854. <https://doi.org/10.48550/arXiv.2602.00854>

Manheim, D., & Homewood, A. (2025). *Limits of safe AI deployment: Differentiating oversight and control (version 2)*. arXiv preprint arXiv:2507.03525. <https://doi.org/10.48550/arXiv.2507.03525>

Mazzocchetti, A. (2026). *Runtime governance for agentic AI: Action-boundary control with trusted provenance and fail-closed execution*. arXiv preprint arXiv:2608.16891. <https://doi.org/10.48550/arXiv.2608.16891>

Michigan Office of the Auditor General. (2016). *Claimant Services: Unemployment Insurance Agency (Performance Audit Report 641-0318-14)*. Official report.

National Institute of Standards and Technology. (2023). *Artificial Intelligence Risk Management Framework (AI RMF 1.0) (NIST AI 100-1)*. <https://doi.org/10.6028/NIST.AI.100-1>

Parasuraman, R., & Manzey, D. H. (2010). Complacency and bias in human use of automation: An attentional integration. *Human Factors, 52*(3), 381–410. <https://doi.org/10.1177/0018720810376055>

Raji, I. D., Smart, A., White, R. N., Mitchell, M., Gebru, T., Hutchinson, B., Smith-Loud, J., Theron, D., & Barnes, P. (2020). Closing the AI accountability gap: Defining an end-to-end framework for internal algorithmic auditing. *Proceedings of the 2020 Conference on Fairness, Accountability, and Transparency*, 33–44. <https://doi.org/10.1145/3351095.3372873>

Royal Commission into the Robodebt Scheme. (2023). *Report of the Royal Commission into the Robodebt Scheme*. Australian Government. Official report and recommendations.

Sato, T. (2026b). *Procedural Continuity and Governing-Capacity Loss in AI-Assisted Institutions: A Descriptive Profile Model and a Rejection-Oriented Research Program (working paper v6.3)*. SSRN. <https://doi.org/10.2139/ssrn.5913703>

Sato, T. (2026c). *From Governance Drift to Accountable Exit: Proper Ending and Authority Return in AI-Assisted Institutions (working paper v6.3)*. SSRN. <https://doi.org/10.2139/ssrn.6066430>

Selbst, A. D., Boyd, D., Friedler, S. A., Venkatasubramanian, S., & Vertesi, J. (2019). Fairness and abstraction in sociotechnical systems. *Proceedings of FAT\* 2019*, 59–68. <https://doi.org/10.1145/3287560.3287598>

van de Sande, D., Economou-Zavlanos, N., & van Genderen, M. E. (2026). Meaningful oversight of medical AI beyond human in the loop. *npj Digital Medicine, 9*, 569. <https://doi.org/10.1038/s41746-026-02971-1>

Zhu, L., Lu, Q., Ding, M., Lee, S. U., & Wang, C. (2026). Designing meaningful human oversight in AI. *AI and Ethics, 6*, Article 286. <https://doi.org/10.1007/s43681-026-01147-7>

:::
