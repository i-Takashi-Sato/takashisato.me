---
title: "Procedural Continuity and Governing-Capacity Loss in AI-Assisted Institutions"
subtitle: "A Descriptive Profile Model and a Rejection-Oriented Research Program"
author: "Takashi Sato"
part: "Workflow-Centric AI Governance Trilogy · Part II"
version: "Working Paper · Version 6.3"
date: "November 2026"
doi: "SSRN DOI 10.2139/ssrn.5913703"
runninghead: "GOVERNING-CAPACITY LOSS"
---

# Abstract {.unnumbered}

An AI-assisted institution may fulfill its procedural obligations while independent epistemic contribution, practical corrective authority, and the performance of a protected function deteriorate. Procedural completion alone then provides little assurance that human control remains intact. This paper develops a middle-range model of this pattern. Governing-capacity loss under procedural continuity (GCL-PC) is a non-compensatory profile of four jointly established conditions within a declared workflow, population and interval: stable or improving procedural fidelity; material and persistent decline in independent judgment; material and persistent decline in institutional actionability; and material impairment of a predeclared protected function. Each condition is coded established, not met or indeterminate, so that missing evidence is not mistaken for evidence of sound governance. The profile implies neither concealment nor a particular cause. A separate causal question asks whether, under a well-defined intervention that disables a named adversarial pathway, a declared ordinary organizational exposure materially harms the protected outcome; identification status and effect assessment are reported on separate axes. Four candidate mechanisms, five testable propositions with rejection conditions, a measurement protocol that separates contribution from actionability, and retention and retirement rules that must be preregistered before evaluation define a research program. Fifteen public-record units from three official investigations of automated decision systems predating generative AI show only that objects associated with the proposed mechanisms are traceable; no field validation, individual causation, prevalence or predictive superiority is claimed. Whether the profile adds value beyond means–ends decoupling and effective-oversight frameworks is an empirical hypothesis, and the binary label must be retired for any use in which it fails to improve a declared decision beyond its continuous components and established baselines.

**Keywords:** AI governance; governing capacity; human oversight; means–ends decoupling; organizational silence; procedural fidelity; sociotechnical systems

# Introduction

Governance failure is conspicuous when an attacker exploits a model, an organization conceals known bias, or a defective system causes visible harm. The harder case is an institution in which people follow approved procedures, a system remains within technical tolerances, and the workflow nevertheless loses the ability to identify, contest, correct, explain, remedy, or stop consequential decisions.

Decisions arise not from a model alone but from representations, targets, interfaces, queues, review roles, escalation channels, managerial responses, vendor dependencies, and remedies. Each local adaptation may be defensible. Together, they can still remove decision-relevant information and redistribute practical authority away from the actors nominally charged with oversight. Procedural completion can then remain stable, or improve, while the procedure's protective function decays.

This paper names that descriptive pattern governing-capacity loss under procedural continuity (GCL-PC).^[Version 6.2 used the term procedurally masked governing-capacity loss. "Masked" implied that observers were misled, but the definition never required evidence of misperception, and several of the public records used here document warnings that were raised and not acted upon. Misperception, suppressed warnings and deliberate concealment may still be studied as mechanisms; they are not constitutive conditions.] The paper also separates the profile from a causal question. Version 6.2 retained Pre-Abuse Collapse (PAC) as a provisional etiological subtype. AI-assisted review identified two defects in that construction: it attached a population-level causal contrast to individual units that need not have been exposed, and it left the reference level of the adversarial pathway free, so that harm arising only in the presence of abuse could satisfy a "pre-abuse" condition. PAC is therefore withdrawn from the classification, and the underlying question is restated as an ordinary-exposure causal specification (Section 4.4).

The research question is: under what conditions can visible procedural fidelity coexist with a persistent loss of independent judgment, effective governing capacity, and protected-function performance in an AI-assisted workflow, and what additional evidence would be needed to claim that ordinary organizational exposures, rather than adversarial conduct alone, produce protected-outcome harm? The paper answers by separating four descriptive conditions from the causal question, locating the model against mature adjacent literatures, specifying a provisional and non-exhaustive set of four candidate mechanisms, deriving five propositions with rejection conditions, and defining retention and retirement rules that must be preregistered before evaluation.

The aim is a middle-range model for diagnosis. The paper does not claim a universal law of bureaucracy, a deterministic life cycle, a validated construct, or a quantitative prediction system. Its strongest current result is a disciplined specification whose components can be traced in independent official records and whose proposed added value is open to empirical rejection.

# Method and Claim Discipline

## Problem-driven theory synthesis

This is a theory-development article with a bounded document analysis, not a systematic review or an empirical outcome study. The conceptual method follows a problem-driven synthesis: define the focal phenomenon; separate the what, how, why, and where/when of the theory; compare the conjunction with established alternatives; derive countervailing conditions, rival explanations, and observations that would count against it; and cap every conclusion at the level of evidence that supports it (Whetten, 1989; Jaakkola, 2020).

Evidence hierarchy. Peer-reviewed sources and official investigations anchor established mechanisms and public-record statements. Recent 2026 preprints and working papers are used mainly to delineate the emerging novelty boundary; they do not validate GCL-PC, the causal specification, or any measurement instrument, and their status must be rechecked at each public release.

1. Declare the protected function, unit, and temporal interval before labeling failure.
2. Distinguish directly observable traces from latent mechanisms, profile classifications, and realized outcomes.
3. Specify the ordinary exposure, adversarial-pathway intervention, protected outcome, population, causal estimand, graph, assumptions, support, and sensitivity analysis rather than infer etiology from claims about actor intent.
4. Compare the proposed conjunction with established component theories and the closest recent alternatives.
5. Derive moderators, rival explanations, temporal predictions, intervention implications, and falsifiers, including an incremental-validity test on outcomes not reused to define the profile.
6. Prefer the simpler established explanation if the composite profile adds no discriminant or intervention value.

## Public-record mechanism probe

The document analysis asks a narrower question than case validation: can an independent reader locate the proposed objects associated with the proposed mechanisms in official records without relying on this paper's terminology? The trilogy uses fifteen passage-level evidence units from three purposively selected negative cases: Robodebt, the Dutch childcare-allowance scandal, and Michigan unemployment-insurance claimant services (Royal Commission into the Robodebt Scheme, 2023; Childcare Allowance Parliamentary Inquiry Committee, 2020; Michigan Office of the Auditor General, 2016). One author performed theory-directed coding; no inter-coder reliability is claimed. The three official investigations concern automated and algorithmic decision systems deployed before contemporary generative AI and large language models. They are not direct evidence about LLM-based workflows, and the papers neither equate those earlier systems with AI in general nor treat them as a separate category to which the analysis does not apply.

## Evidence ladder and no-claim rules

- A passage mapped to a mechanism is not evidence that the mechanism caused the case.
- Co-occurring codes are not a causal sequence.
- An official finding is not a construct-validation study.
- A negative case cannot establish sensitivity, specificity, prevalence, or lead time.
- Observing high procedural completion while one governance trace declines does not establish the GCL-PC profile.
- If established theories explain the observations and intervention choices without the GCL-PC conjunction, parsimony favors those theories.

## Shared-corpus reuse and theory-first risk

The fifteen-unit corpus is also used in Parts I and III (Sato, 2026a, 2026c). Reuse keeps source locators stable and makes it possible to ask whether different governance objects can be traced in the same official records, but the resulting analyses do not constitute three independent tests. Because all three papers were developed with knowledge of the same purposively selected negative cases, the design is vulnerable to coding and interpretation shaped by the theory. A passage that is useful for a gate, a mechanism, and an exit obligation does not thereby validate any of them or create triangulation. Future evaluation must use cases and comparison units selected independently of this vocabulary, including successful, recovered, and boundary cases.

# Theoretical Location and Novelty Boundary

## Institutional decoupling, means–ends decoupling, and audit ritual

Institutional theory already explains why formal structures can confer legitimacy while operational practice remains partly decoupled from them (Meyer & Rowan, 1977). Audit regimes can intensify this gap when inspectable artifacts become proxies for an underlying public purpose (Power, 1997). Means–ends decoupling describes the more consequential case in which implemented practices are carried out but remain only weakly linked to the goals they are meant to serve (Bromley & Powell, 2012). The coexistence of stable procedural fidelity and impaired protected functions is therefore already recognized.

GCL-PC is a narrower descriptive profile of an AI-assisted decision workflow in which two additional trajectories must also be established: loss of case-level epistemic contribution and loss of institution-level actionability. The proposed value of the distinction is diagnostic and intervention-oriented. Reviewers who contribute little despite having effective corrective authority present a different problem from reviewers whose independent reasoning cannot change institutional action. A third profile combines both failures. Whether this decomposition improves the selection of corrective measures relative to a means–ends decoupling account and existing oversight frameworks is an empirical question, not a consequence of the definition.

## Discretion, algorithmic control, and system-level bureaucracy

Street-level bureaucracy locates implementation in frontline discretion under resource constraint (Lipsky, 1980), while later work shows that administrative reforms redistribute rather than simply remove discretion (Brodkin, 2011). Digital systems can move discretion into categories, thresholds, queue priorities, and interface defaults; Bovens and Zouridis (2002) describe the shift from street-level to system-level bureaucracy. Ethnographic research shows that users negotiate and resist algorithmic systems rather than passively receive them (Christin, 2017), and algorithmic control can create contested terrain around direction, evaluation, and discipline (Kellogg et al., 2020). GCL-PC concerns the residual human stage that remains visible after much discretion has migrated elsewhere: does that stage still contribute independent case information, can it alter the action, and does the institution respond when it does?

## Automation bias, effective oversight, and quasi-automation

Human-factors research documents automation-related complacency and bias and the loss of active processing under automation (Parasuraman & Manzey, 2010; Endsley & Kiris, 1995). Policy analysis has shown that mandated human oversight of government algorithms can provide a false sense of security and legitimize flawed systems unless institutions evaluate whether oversight can actually work (Green, 2022). Wagner (2019) defines quasi-automation as the inclusion of humans as a rubber-stamping mechanism in an otherwise automated system and analyzes the resulting gap between liability and control. Elish (2019) shows how responsibility can be misattributed to the operator with least control, the moral crumple zone. Sterz et al. (2024) specify effectiveness conditions for an overseeing person, including epistemic access and causal power. Recent 2026 work narrows the boundary further: Lin et al. (2026) define a cognitive-integrity threshold below which oversight becomes hollow; Gaube et al. (2026) provide an architecture for effective human oversight; and van de Sande et al. (2026) identify epistemic capacity, cognitive space, decisional authority, and intervention effectiveness as conditions for meaningful medical-AI oversight. GCL-PC cannot claim novelty for the diagnosis that nominal human presence is insufficient, nor for distinguishing epistemic access from the power to intervene.

Bainbridge (1983) identified the underlying irony: automating routine work removes the practice that operators need to take over when the automation fails, while leaving them responsible for the hardest cases. Cognitive externalization (Section 5.1) is the institutional counterpart of that irony. GCL-PC differs in its object: it concerns whether the institution can still form independent judgment and act on it, not whether an individual operator retains the skill to intervene.

## Organizational silence and corrective voice

Organizational silence research explains why employees withhold concerns when speaking appears unsafe or futile and why managerial openness and perceived efficacy shape voice (Morrison & Milliken, 2000; Detert & Burris, 2007; Morrison, 2014, 2023). This paper uses that literature rather than renaming it. The candidate contribution is to treat the supply and efficacy of corrective voice as one component of a broader workflow-level profile that also includes procedural continuity, judgment contribution, practical authority, and protected-function performance.

Hirschman (1970) distinguished exit and voice as responses to organizational decline and argued that the availability of exit shapes the use of voice. Voice attenuation (Section 5.4) concerns members who remain inside a workflow and stop raising challenges because challenges no longer produce remedy; Part III addresses a different kind of exit, the authorized retirement of the workflow itself (Sato, 2026c).

## Safety drift, update opacity, and recent governance-hollowing accounts

Safety science explains movement toward failure through locally rational adaptations under competing pressures (Rasmussen, 1997; Vaughan, 1996). Ferrario and Hatherley (2026) show how system updates can make previously acquired calibration inaccessible under real role and time constraints. Tallam (2026) distinguishes surviving records from the institutional practice required to interpret distributed cognitive episodes. Frimpong (2026) argues that expanding formal governance can weaken operational control through authority fragmentation and symbolic governance. Niu (2026) describes a migration of effective governing capacity toward intermediary layers that control information routing and evaluative signals. Havyarimana (2026) distinguishes formal human authority from practical governing capacity and describes the hollowing of office when human assent remains formally decisive but substantively compelled. Simons and Broniatowski (2026) use LLM-simulated role-conditioned stress tests to examine why the NIST AI RMF may be difficult to adopt; because their evidence is simulated rather than field-observed, it is adjacent evidence about role-dependent implementation frictions, not validation of this model. Engin's Human-AI Governance framework represents decision authority, process autonomy, and accountability configuration as continuous governance dimensions with threshold changes (Engin, 2026).

These accounts set a demanding standard for a distinct contribution. GCL-PC earns separate descriptive use only if its prespecified conjunction at the workflow-outcome level improves explanation, discrimination, temporal inference, or intervention choice beyond these components. Any incremental empirical value must be demonstrated, not inferred from terminology.

Erpenbach (2026), in a practitioner-oriented blog post dated 28 July 2026, argues that procedural continuity and operational continuity can come apart: a system may keep its approval, documentation and risk-register entry while its practical role changes, so that process controls should be paired with periodic functional continuity review. The concern overlaps with the first condition of GCL-PC, but the two accounts differ in object and form. Erpenbach examines whether a system still performs the role for which it was approved, from the standpoint of board oversight; GCL-PC describes whether the institution retains independent judgment, actionability and protected-function performance, and codes four conditions with their evidential status. A functional continuity review could supply evidence on whether visible procedure still tracks the governed activity. No priority is claimed in either direction; the relationship is conceptual.

| Comparator | Already explains or requires | Proposed additional question | What defeats the added profile |
|---|---|---|---|
| Means–ends decoupling (Bromley & Powell, 2012) | Implemented practices weakly linked to core goals | Do distinct J/G trajectories within the P/N pattern improve the choice between epistemic and authority or capacity interventions? | A P/N decoupling baseline predicts intervention outcomes equally well, or J and G cannot be measured separately |
| Institutional oversight (Green, 2022) | Limits of human-oversight mandates; institutional responsibility for appropriate use | Can a declared longitudinal profile distinguish deterioration from an initially inadequate arrangement? | Existing oversight assessment captures the same distinction and decision utility |
| Quasi-automation and moral crumple zones (Wagner, 2019; Elish, 2019) | Nominal participation; misalignment of responsibility and control | Do changes in contribution and actionable authority predict the consequences of changing liability, escalation, or resource arrangements? | No independent predictive or decision-relevant increment |
| Effective oversight (Sterz et al., 2024) | Epistemic access, causal power, self-control, fitting intentions | Can realized contribution and institutional actionability be tracked over time and related to a protected function? Access is not contribution | Existing oversight constructs yield equivalent or better measurement and intervention selection |
| Safety drift (Rasmussen, 1997) | Locally rational adaptation moves systems toward failure | Stable procedure as a co-condition with normative outcome loss | No added discrimination or intervention relevance |
| Out-of-the-loop performance (Endsley & Kiris, 1995) | Automation degrades situation awareness and takeover | Institution-level voice, authority, remedy, and protected function | Individual human-factors measures fully explain impairment |
| System-level bureaucracy (Bovens & Zouridis, 2002) | Discretion migrates into systems and designers | Whether the retained human stage still contributes and can correct | Relevant discretion has moved entirely upstream |
| Organizational silence (Morrison, 2014) | Low safety or efficacy suppresses voice | Voice as one component of a coupled profile | Voice theory alone predicts the impairment and remedy |
| Cognitive integrity and hollowing (Lin et al., 2026; Havyarimana, 2026) | Formal authority persists while understanding or capacity erodes | Explicit protected-function condition and retirement test | The conjunction adds no out-of-sample value |

Table: Incremental boundary relative to established and recent adjacent accounts. The comparisons do not establish priority or a unique mechanism.

# Descriptive Profile, Causal Question, and State Space

## Four conditions

For a declared workflow, protected function, target population, and interval I, define four distinct objects. P denotes visible procedural fidelity: completion of required steps, documentation, approvals, and other observable process artifacts. J denotes case-level epistemic contribution: new evidence, reasoning, uncertainty qualification, or correction beyond the AI output and procedural template. G denotes institution-level actionability: the practical ability to make a valid contribution consequential by modifying action, escalating, mobilizing resources, providing remedy, or stopping the workflow. N denotes performance of the predeclared protected function, for example lawful proportional treatment, safety, due process, or another normatively specified outcome. N need not be a measure of model accuracy.

Before classification, declare a defensible baseline, materiality thresholds, persistence windows, and measurement models. Let $F_P$ denote stable or improving procedural fidelity relative to the baseline; $D_J$ and $D_G$ material and persistent declines in J and G; and $I_N$ material impairment of N. Each condition c is coded

$$v(c) \in \{\text{established},\ \text{not met},\ \text{indeterminate}\},$$

where indeterminate means that the available evidence cannot settle the condition. The descriptive classification is

$$\mathrm{GCL\text{-}PC}(I) = \begin{cases} \text{criteria met} & \text{if all four conditions are established},\\ \text{criteria not met} & \text{if at least one condition is not met},\\ \text{indeterminate} & \text{otherwise.}\end{cases}$$

The rule is a non-compensatory profile, not a weighted composite score: strength in one condition cannot compensate for failure in another. An established unmet condition rules out the conjunction; it does not establish institutional health. Retain the full profile, the continuous measurements, their uncertainty, and the reasons for missingness; the binary label is a derived representation, not a replacement for those observations. The same trace must not be reused mechanically across conditions without an explicit measurement model and a sensitivity analysis for shared error (Section 8.1).

## State space

Among the sixteen complete binary profiles, exactly one meets the GCL-PC definition. Seven other profiles have established protected-function impairment; they are not GCL-PC but may warrant investigation in their own right, for example an impairment accompanied by visible procedural collapse. Profiles with established J and G decline and without established N impairment indicate incipient capacity-loss risk; the report must distinguish evidence of no material impairment from insufficient outcome evidence. Of the eighty-one three-valued profiles, one meets the criteria, sixty-five are ruled out by at least one unmet condition, and fifteen are indeterminate (Appendix B). No profile implies a severity ranking, and none authorizes an institutional act.

| Profile family (complete profiles) | Count | Interpretation | Not to be inferred |
|---|---:|---|---|
| All four established | 1 | GCL-PC criteria met | Cause, concealment, severity, authority to act |
| $I_N$ established, at least one other condition not met | 7 | Protected-function impairment outside GCL-PC; separate investigation may be warranted | Normality of the workflow |
| $D_J$ and $D_G$ established, $I_N$ not met | 2 | Incipient capacity-loss risk with evidence against current impairment | Absence of future harm |
| Remaining profiles | 6 | Neither GCL-PC nor incipient risk on the declared evidence | Health or compliance |

Table: The sixteen complete binary profiles. Profiles with indeterminate conditions are reported as indeterminate rather than assigned to these families.

## Incipient risk and initial deficiency

If credible evidence shows declining J and G while protected-function impairment is not established, the correct report is incipient capacity-loss risk, together with the evidential status of N. The incipient-risk family does not require procedural continuity; a workflow whose visible procedure is also deteriorating is not thereby healthier. An arrangement that lacked the necessary capacity from inception is an initial deficiency rather than demonstrated loss. It remains a legitimate governance concern, but GCL-PC as defined concerns loss over an interval, and the public-record illustrations below are not classifications of any profile.

## Ordinary-exposure causal specification

The question formerly expressed as Pre-Abuse Collapse is whether a specified ordinary organizational exposure $A_O$ has a materially adverse effect on a declared protected outcome $Y_N$, coded so that larger values mean better protection, under a substantively coherent intervention that disables a specified adversarial pathway $A_M$. The intervention does not operate on an unobservable moral intention. It must specify a feasible change to a pathway, rule, or process, for example removal of a particular unlawful decision rule. If such an intervention is well defined, denote it $m = 0$ and define, in the declared target population,

$$\Delta_O(0) = E\left[Y_N(1, 0) - Y_N(0, 0)\right].$$

Where a meaningful alternative $m = 1$ is also well defined and separately identifiable, report $\Delta_O(1)$ and the interaction contrast $\Delta_O(1)$ − $\Delta_O(0)$; otherwise state why it is not defined or identified. Reporting the interaction is required because an ordinary exposure that is harmful only when the adversarial pathway is active would otherwise be mistaken for harm "without abuse". The reference level for the principal contrast is fixed at $m = 0$ before analysis.

A well-defined intervention does not by itself identify the causal contrast. Identification requires design-specific assumptions such as consistency, exchangeability, positivity or support, no or modeled interference, measurement validity, and correct timing. A directed acyclic graph makes assumptions explicit; it does not establish that they hold. If $A_M$ is downstream of $A_O$ or lies on a post-exposure pathway, restricting or adjusting to observed $A_M$ = 0 is not an identification strategy: it can create post-treatment selection and mediator–outcome confounding bias. An appropriate interventional or longitudinal estimand and a justified g-method, weighting, or standardization estimator are required (Hernán & Robins, 2020).

Identification status (point identified, partially identified, or unidentified under stated assumptions) is reported separately from effect assessment. For a predeclared materiality threshold $\delta_N > 0$, the population identification set and sampling uncertainty are reported separately. Under partial identification, the analysis must report either a valid one-sided confidence bound for the upper endpoint of the identification set or a confidence region covering the whole set. Four effect assessments are distinguished:

| Effect assessment | Condition on the valid confidence region [L, U] |
|---|---|
| Materially adverse | $U \le -\delta_N$ |
| Beneficial | $L > 0$ |
| Not materially adverse; benefit not established | $-\delta_N < L \le 0$ |
| Unresolved | Region spans $-\delta_N$, or effect unidentified |

Table: Effect assessment, kept separate from identification status. An estimated identification interval without sampling uncertainty is not sufficient for any assessment.

The contrast concerns a population-level protected outcome. It does not identify the cause of declines in J or G, the cause of an individual event, individual sufficient causation, or the absence of wrongdoing, and it attaches no causal subtype to any single unit. The historical name Pre-Abuse Collapse must not be used to create a new unvalidated etiological state.

## Synthetic identification example

Suppose a benefits-review organization staggers a queue-cap policy that cuts protected review minutes, $A_O$, across otherwise comparable teams for operational reasons unrelated to the study. Before rollout, investigators register P as completion of required review steps, J as blinded independent-coder evidence contribution, G as conditional actionability measured by standardized valid challenges (Section 8.1), and $Y_N$ as independently reconstructed lawful-outcome quality. They set $\delta_N = 0.05$ and register a causal graph that places the adversarial pathway explicitly in time, for example a discretionary override rule that can be disabled by configuration. If that pathway is fixed upstream of $A_O$, the controlled contrast at $m = 0$ may be estimable under the stated assumptions. If it is affected by $A_O$, investigators define an interventional or longitudinal estimand and use a justified g-formula, inverse-probability weighting, or standardization estimator; they do not restrict the observed sample to cases without the override. A staggered event-study design may identify the $A_O$ variation only if timing, parallel-trend or exchangeability conditions, support, and negative-control diagnostics are defensible. A materially adverse assessment requires the upper confidence bound to lie at or below −0.05. If timing is endogenous, overlap fails, the pathway is poorly observed, or the region spans the threshold, the result is unresolved. This is a study template, not evidence that any real case meets any profile or effect assessment.

## Protected functions must be predeclared and plural

A workflow can improve one outcome while damaging another. Faster throughput can coexist with worse proportionality; lower model error can coexist with inaccessible remedy. A study must therefore predeclare the protected function and its measurement. Treating every desirable outcome as one composite "governance quality" variable would make the model unfalsifiable.

# Four Candidate Mechanisms

These four mechanisms are a provisional, theory-directed set, not a sufficient or exhaustive taxonomy. Deskilling, vendor lock-in, update opacity, automation-induced dependency, resource withdrawal, or other mechanisms may produce the same profile and should be added, substituted, or preferred when they improve identification. Neither the profile nor the causal specification restricts inquiry to these pathways.

## Cognitive externalization

Pressure: throughput demand, task complexity, repeated exposure, and interface design that presents the model output as the primary case representation. Mechanism: reviewers increasingly treat the model output as both the starting and ending representation of the case, reallocating attention away from independent evidence search. Expected traces include a declining complexity-responsive review-time slope, rationales that add less held-out information beyond the model and declared controls, and intervention concentrated on obvious flags. Countervailing conditions include independent evidence views, diagnostic sampling, protected time, rotation, and feedback on missed errors. Externalization is not inherently harmful; offloading can improve performance. The failure condition is loss of complementary scrutiny while the institution continues to count the human stage as independent oversight.

## Legibility capture

Pressure: audit and performance systems reward what can be counted quickly. Mechanism: actors optimize completion, agreement, documentation length, queue clearance, or other legible artifacts because those artifacts are easier to manage than the protected function. Expected traces include rising procedural completion while rationale contribution, remedy timeliness, case reconstruction, or risk-adjusted protected outcomes worsen; templates may become longer while less discriminative. Countervailing conditions include outcome-linked audit, randomly sampled case reconstruction, plural metrics, and explicit anti-gaming review. Legibility capture does not require fraud; locally rational compliance with the measured target can be sufficient.

The term draws on Scott’s (1998) account of how state simplification makes complex practice legible to central authority at the cost of local knowledge, and the mechanism is closely related to Campbell’s (1979) observation that quantitative indicators used for social decisions become subject to corruption pressures, and to Goodhart’s (1975/1984) observation that a statistical regularity tends to collapse once it is used for control. The contribution here is narrower: P2 (Section 7.2) states a rejectable contrast with a preregistered burden measure rather than a general law.

## Responsibility inversion

Pressure: the reviewer is held responsible for delay or deviation but lacks authority over model design, staffing, policy, vendor constraints, or fallback. Mechanism: formal accountability concentrates on the actor least able to change the system. Anticipated personal costs favor acceptance, while upstream owners may treat the human signature as a transfer of risk. Expected traces include high approval with extensive attestations, overrides that require exceptional justification, and incidents framed as operator error despite structural causes. Countervailing conditions include authority–responsibility parity, explicit upstream ownership, protected override, and escalation to a competent independent decision maker. The mechanism builds on quasi-automation (Wagner, 2019) and on the moral crumple zone as a post-failure attribution concept (Elish, 2019); its candidate addition is the claim that anticipated liability shapes behavior before an incident.

## Voice attenuation

Pressure: concerns are ignored, punished, routed back to the same owner whose system is challenged, or repeatedly fail to produce remedy. Mechanism: perceived efficacy of speaking up declines; subsequent dissent becomes less frequent, depriving the institution of corrective information. Expected traces include prior unremedied dissent predicting later decline in risk-adjusted dissent, genericized reports, and recurrence without systemic response. Countervailing conditions include protected reporting, visible remedy, independent recipients, and feedback to reporters. A common deterioration of the reporting channel can produce the same temporal association without any feedback (Section 7).

![Voice attenuation as a feedback hypothesis with a rival common-cause path. Raw dissent counts alone are not evidence of governance quality.](figures/part2_fig1_voice.pdf){width=80%}

# Public-Record Traceability Illustrations

The shared corpus does not classify Robodebt, the Dutch childcare-allowance scandal, or Michigan claimant services under any profile. A classification would require predeclared longitudinal measures of P, J, G, and N; a causal assessment would additionally require the prespecified graph, estimand, assumptions, and design described above. The official records do not provide that research design. The analysis instead asks whether objects associated with the proposed mechanisms are independently auditable.

| Candidate mechanism | Robodebt | Dutch inquiry | Michigan audit | Inference permitted |
|---|---|---|---|---|
| Cognitive externalization | Recommendations emphasize legal foundations, review, explanation, scrutiny; cognition not directly measured | Mass processing and limited individual consideration | Sampled determinations show fact-gathering and reason deficiencies | Evidence handling and reasons are observable; cognitive offloading is not established |
| Legibility capture | Decision-record and legal-basis recommendations show missing governance objects; target conversion not observed | Group-based, risk-selected, all-or-nothing administration makes categorical simplification salient | Process-quality findings, not an explicit target effect | Categorical simplification is traceable; target conversion remains untested |
| Responsibility inversion | Responsibility and legal-accountability reforms show the importance of locating authority | Responsibility assigned across administration, legislature, judiciary; workflow authority not reconstructed | Agency process and responses, not a reviewer-level authority map | The corpus is insufficient to establish authority–responsibility inversion |
| Voice attenuation | Frontline consultation and management response appear as remedial objects | Persistent warning signals and delayed recognition and remedy | Feedback was not systematically compiled and practical communication was weak | Signal routing and response are observable; the feedback mechanism remains untested |

Table: Public-record traceability of mechanism-adjacent objects and the inferences not supported.

The probe changes the theory in three ways. It confirms that evidence, reasons, practical review, feedback routing, managerial response, and remedy can be source-located outside the conceptual model. It forces nominal review access to be separated from practical review capacity. And it exposes a weak point: role-level effective authority and responsibility inversion are poorly recoverable from the fifteen coded units. The persistent warnings recorded in the Dutch inquiry also show why concealment cannot be a defining condition: protected-function impairment and procedural continuity can coexist with warnings that were visible but not acted upon. A future test needs an authority map and longitudinal workflow data, not merely policy documents or post-incident recommendations.

# Derived Propositions

| Proposition | Unit / contrast | Target estimand | Evidence against |
|---|---|---|---|
| P1 Capacity strain | Units before and after exogenous throughput increase with staffing fixed, versus protected-time relief | Difference in standardized effects on J and P on a preregistered scale | J stable or rising; sign changes under defensible preregistered scales; decline explained by case mix, model improvement, or learning |
| P2 Target conversion | Staggered target introduction versus unaffected units | Effects on target metric, protected outcome N, and preregistered burden measures | Target improves both artifact and N with no increase in preregistered burden measures |
| P3 Voice-efficacy feedback | Team-window panels with exogenous variation in remedy efficacy | Effect of remedy efficacy on later risk-adjusted dissent | No effect under exogenous variation; association equally present in lead placebos; explained by opportunity or channel quality |
| P4 Joint-trace discrimination | Held-out windows with independently reconstructed impairment | Increment of a coupled multitrace model over the additive multitrace baseline | No increment over the additive model; instability across sites; proxy meaning changes under intervention |
| P5 Comparative decision validity | Nested held-out sites or time blocks; prospective outcome not used in the profile | Incremental decision utility over the strongest prespecified comparator | Upper confidence bound below the minimum meaningful increment; gain vanishes under leakage controls |

Table: Derived propositions, contrasts, estimands, and rejection conditions.

## P1: Capacity strain

Within comparable units, an exogenous increase in throughput pressure without proportional capacity should reduce independent judgment contribution more than procedural completion. Because J and P are measured on different scales, a comparison of raw declines is not meaningful: the same data can support the proposition on a raw or relative scale and reject it on a logit scale. Before analysis, specify commensurate scales or predeclared standardized effects, the target intervention and estimand, comparison units, adjustment set, measurement invariance, and a minimum meaningful contrast. Staffing increases, protected review time, or randomized queue relief should moderate the effect. The proposition is weakened if its sign changes under defensible preregistered scale choices and defeated if the apparent decoupling disappears after the preregistered controls for case difficulty, model quality, reviewer learning, policy, and interface change.

## P2: Target conversion

Introducing a salient completion or agreement target should improve the targeted artifact while failing to improve, or worsening, the protected outcome, or while displacing burden to unmeasured work, if legibility capture is operating. The primary estimands are effects on the target metric, on N, and on preregistered burden measures, relative to unaffected units under an identification design such as staggered introduction with negative-control metrics. Changes in the metric–outcome relationship are secondary diagnostics. A ceiling effect can lower the raw correlation between a completion metric and the protected outcome without any gaming, while a regression coefficient conditional on case evidence remains stable; correlation-based evidence of "decoupling" must therefore be checked for restricted variance and differential measurement precision. Failure to detect hidden burden is not evidence that none exists, so burden outcomes, missingness, and uncertainty are specified in advance. The proposition is defeated if the target improves both the artifact and the protected function with no increase in the preregistered burden measures.

## P3: Voice-efficacy feedback

Lower remedy efficacy for substantiated dissent should reduce later risk-adjusted dissent, controlling for opportunities to dissent. Temporal precedence is not sufficient: a common deterioration in the quality of the reporting channel can lower both remedy efficacy and recorded dissent, producing a strong forward association and an equally strong reverse association with no feedback at all, and such associations can survive unit fixed effects and cluster-aware inference. The design must predeclare opportunity measures, unit and period effects, lag structure, cluster-aware inference, lead-placebo checks, and a source of exogenous variation in remedy efficacy. Where causal identification is unavailable, report a prospective association rather than a mechanism estimate. Mediation through perceived efficacy can be examined with confidential repeated measures, but behavioral traces should remain primary where survey response may itself be chilled.

## P4: Joint-trace discrimination

A coupled signal combining rationale-information loss, time–complexity decoupling, and depletion of corrective voice is hypothesized to distinguish independently reconstructed governance impairment from benign efficiency. Any combination of independently informative traces will usually outperform each single trace, so that comparison cannot support a coupling claim. The test compares a predeclared multitrace model with single-trace models and with an additive multitrace baseline on an independently reconstructed future impairment or other declared target. Claims about coupling beyond the combination of information require an increment over the additive model, with uncertainty and external validation. The proposition is defeated if no such increment appears, if the signal is unstable across sites, or if a proxy's meaning changes under intervention. Part III's candidate Governance Drift Indicators operationalize this proposition but do not validate it (Sato, 2026c).

## P5: Comparative decision validity

The binary GCL-PC label is a deterministic function of the same four measured inputs. It cannot add information to an ideal predictor that uses those inputs. Its proposed value is therefore a testable finite-sample stability, transfer, or decision advantage for a declared intervention choice, not unrestricted superiority in discrimination. In held-out sites or time blocks, the label is compared with preregistered continuous additive and flexible models of the same components; non-conjunctive profiles; a model using protected-function history alone; and domain-appropriate established-theory baselines for decoupling, safety drift, organizational silence, or cognitive integrity. Every comparator must have equal access to the information available at decision time. The primary outcome must be independent of the profile definition and future-facing, for example recovery or recurrence after a standardized corrective action. Contemporaneous N impairment cannot be reused as the target. Hyperparameters, thresholds, feature selection, missing-data handling, and calibration belong inside nested validation with site- or time-grouped outer folds. Calibration, uncertainty, subgroup performance, and decision-curve or explicit utility analysis are reported. Retention and retirement follow Section 8.4.

# Identification and Falsification Strategy

## Measurement model before causal model

Every construct requires a content-valid operational definition before causal analysis. Procedural fidelity is not document length. Independent judgment is not disagreement alone. Governing capacity is not a formal organization chart. Protected-function performance is not model accuracy unless the protected function is explicitly accuracy. J and G require separate measures or an explicit joint model: an analytically strong reviewer can have no practical power (high J, low G), while a powerful stage can rubber-stamp derivative reasoning (low J, high G). Researchers document construct–measure links, cross-loadings, shared-method error, known blind spots, latency, subgroup validity, and expected behavior under benign alternatives (Jacobs & Wallach, 2021).

J is estimated from independently coded contribution beyond the model and template, not from dissent frequency alone. G is estimated as the ability to make a specified valid contribution consequential, conditional on a genuine correction opportunity. A count of successful corrections is not a valid measure of G: corrections can only follow contributions, so a decline in J mechanically lowers such a count even when institutional actionability is unchanged. The protocol therefore measures current effective authority, resources, escalation access, response latency, and whether a standardized valid challenge can change the action or mobilize remedy, using a predeclared set of representative challenge types and weights. Live intervention that could harm affected persons is replaced by lawful and ethical offline or sandbox tests. A fall in the supply of challenges is not by itself evidence of a fall in conditional actionability. Actual recorded attempts are informative but may be selected by J, resources, or fear of retaliation; selection, sparse observations, missingness, and uncertainty are documented rather than interpreting no attempts as no capacity.

Joint measurement models and sensitivity analyses must account for shared errors and avoid recycling one trace across J, G, and N. N must be independently defined and assessed, and its constitutive observations may not also serve as an independent validation target. Part III's rationale-information proxy must be checked for overlapping adjudication, data lineage, and leakage before use.

Minimum J/G protocol. At least two trained coders, blinded to protected outcomes and to the profile label, independently code a stratified case sample using a published codebook. J is reconstructed from source evidence and rationale contribution beyond the model and template; G is reconstructed separately from a versioned authority map and the standardized challenge procedure. Report raw agreement, an appropriate chance-corrected or reliability coefficient with uncertainty, adjudication rules, missingness, and sensitivity to alternate thresholds. A held-out auditor then attempts outcome and decision reconstruction from the record. Formal titles, override counts, and text length cannot substitute for this protocol.

## Temporal and counterfactual identification

A credible GCL-PC study needs temporal variation that is plausibly upstream of the descriptive sequence, for example staffing shocks, target changes, interface changes, provider updates, or changes in escalation structure, plus independently measured protected outcomes. A study of the ordinary-exposure question must go further by identifying $\Delta_O(0)$ while measuring or bounding the adversarial pathway. Interrupted time series, difference-in-differences, event-study, stepped implementation, randomized queue relief, or carefully reconstructed matched comparisons may be appropriate depending on domain. A retrospective association between a declining proxy and an adverse outcome is insufficient.

## Alternative explanations

- Benign efficiency: expertise or interface improvement reduces review time while judgment quality remains intact.
- Model improvement: lower dissent or override is appropriate because the model became more accurate.
- Case-mix shift: simpler cases alter time, rationale, and dissent without governance degradation.
- Policy or legal change: the target function or permissible actions legitimately changed.
- Measurement displacement: workers move substantive reasoning to an unobserved channel rather than ceasing to reason.
- Outcome selection and delay: appeals, verified errors, and harm labels arrive selectively or too late for the proposed sequence.
- Channel deterioration: a common decline in reporting or routing infrastructure lowers several traces at once.
- Adversarial or discriminatory conduct: malicious or unlawful behavior is a material cause and must be modeled rather than excluded rhetorically.

## Preregistered retention and retirement

Before outcome inspection, declare the decision, protected population, comparator set, prospective outcome, costs of erroneous actions and omissions, utility function, decision threshold, minimum decision-relevant utility increment ΔU, evaluation horizon, missingness procedure, multiplicity rule, and uncertainty criterion. Power and precision calculations must incorporate expected profile frequency, site count, within-site dependence, plausible effects, and measurement error; the number of sites is design dependent and not a universal constant. The primary criterion is incremental decision utility relative to the strongest suitable prespecified comparator. Discrimination and calibration are reported. Secondary operational criteria, namely decision time, inter-rater consistency, and misapplication rate, require prespecified protocols and cannot rescue a failed primary criterion.

Retention for the tested use requires a lower uncertainty bound exceeding ΔU together with satisfaction of measurement, safety, and fairness requirements. An adequately precise result whose upper bound lies below ΔU supports rejection for that use. An uncertainty interval spanning ΔU, inadequate precision, or failed identification leaves the result unresolved; none supports retention. Before results are inspected, fix the maximum number K of independent studies, the evaluation deadline, the pooling method, and interim stopping rules. At the terminal evaluation, a valid pooled upper bound below ΔU, or failure of the prespecified reproducibility criterion for the discriminant measurement of J and G, requires retirement of the separate classification for that use. If evidence remains insufficient at the stopping boundary, operational adoption and recommendation are suspended; this is not proof of ineffectiveness. Neither K nor the deadline is extended in response to unfavorable results, and a genuinely new research program requires new justification and a separate preregistration. Lack of an independent protected-function measure precludes validation. Any apparent gain that reuses N or another constitutive measure as the target, leaks site or time information, or vanishes under nested validation is disqualifying. A memorable name is not a reason to retain a model.

# Governance Implications

The model shifts audit questions from "Was a human present?" to four linked questions. Did the human contribute information not already contained in the model or template? Could that contribution change the action? Did the institution respond when corrective voice was supplied? Did the predeclared protected function remain intact? Completion and agreement remain useful process measures, but their relationship to evidence and outcomes must be tested rather than assumed.

It also changes accountability. If throughput, target design, vendor dependency, and authority allocation erode judgment and actionability, retraining individual reviewers is unlikely to be sufficient. Corrective action may require queue relief, interface redesign, independent escalation, changed incentives, stronger fallback, or suspension. Leadership owns those conditions. The descriptive separation of J and G is intended to inform which of these responses is appropriate; whether it does so better than simpler accounts is the subject of P5.

Institutional records should likewise preserve these distinctions rather than merely accumulate text. A governance record should distinguish model output, source evidence, human contribution, unresolved uncertainty, institutional action, authority, later challenge, and correction. More documentation is not necessarily more governing capacity (Winecoff & Bogen, 2025).

# Relationship to Parts I and III

Part I provides the case-level front door: a typed two-stage contract separates diagnostic states and routes from authenticated dispositions and from actual execution (Sato, 2026a). Part II asks whether that visible architecture can remain procedurally intact while independent contribution, actionability, and protected-function performance deteriorate. Part III separates measurement signals, research classifications, authorized institutional determinations, containment, retirement, and closure (Sato, 2026c).

| Concept | Part II role | Boundary to Part III |
|---|---|---|
| Incipient capacity-loss risk | Research report of established J/G decline with N impairment not established, and the evidential status of N | May inform a decision to investigate; is not itself an institutional determination or containment |
| GCL-PC | Research classification of the four-condition profile | May be part of the evidence for a separately authorized incident finding; does not itself require or authorize retirement |
| Other N-impairment profiles | Research report outside GCL-PC | May warrant investigation; no automatic incident or normality |
| Ordinary-exposure causal specification | Population estimand with separate identification and effect assessment | Informs remedy design; is not a case label or an authority |
| Resolution Collapse, Proper Ending, Authority Return | Outside Part II | Authorized findings and processes defined in Part III |

Table: Part II research concepts and their boundary to Part III institutional acts.

This separation is central to the trilogy's governance logic: diagnosis must not acquire decision authority by definition. A GCL-PC classification can change the evidentiary state of the institution, but only a competent authority under the applicable process may contain, retire, resume, or redeploy the workflow.

# Limitations and Research Ethics

GCL-PC is a proposed descriptive profile, not a new general theory of organizational drift or a validated latent scale. It deliberately overlaps with institutional and means–ends decoupling, safety drift, out-of-the-loop performance, system-level bureaucracy, audit ritual, automation bias, effective-oversight frameworks, organizational silence, cognitive integrity, update opacity, and recent governing-capacity accounts. Its value depends on incremental explanatory, discriminant, temporal, causal, and intervention validity under leakage-free held-out tests, and the independent increment of separating J and G has not been tested.

"Designed for empirical rejection" describes the architecture of the claims, not a completed empirical achievement. Every condition contains domain judgments about materiality, persistence, measurement, and baseline choice. Classification of the same data can change with defensible threshold, persistence, and baseline choices, which is why they must be preregistered. Measurement errors can compound in a four-way conjunction: if each condition were measured with sensitivity 0.85 and specificity 0.90, and errors were conditionally independent given a true profile, the conjunction would detect roughly half of true profiles. The causal specification additionally requires a defensible identification strategy. Until independent teams demonstrate reproducible operationalization, the paper supplies a rejection-oriented research program rather than a validated instrument or causal theory.

The public-record probe is narrow, purposive, author-coded, and selected for documented failure and mechanism coverage. It includes no matched successful workflow and does not independently reconstruct the investigations. It cannot establish the latent mechanisms, their sequence, the GCL-PC profile, or any causal effect. The same fifteen units are reused across the trilogy; that controlled reuse aids source consistency but cannot produce independent replication and may amplify narrative-fit bias.

The label can be misused to stigmatize an institution without adequate evidence. Protected functions are plural and politically contested; one workflow can improve one function while worsening another. Predeclared outcomes, rival explanations, explicit falsifiers, and the retirement rule are intended to constrain opportunistic use.

Measurement itself can harm governance. Review-time telemetry, rationale analysis, dissent monitoring, and standardized challenges can become worker surveillance, speed pressure, or a new target to game. Data access should be proportionate, aggregated where possible, protected from punitive secondary use, ethically reviewed, and co-designed with affected workers and communities.

# Conclusion

An AI-assisted institution can comply with procedures while losing the judgment, corrective voice, and effective authority that made the procedure protective. The model distinguishes incipient risk, the GCL-PC profile, other protected-function impairments, and indeterminate evidence; insufficient evidence is not evidence of health. Causal analysis is specified separately at the population level, with a fixed adversarial-pathway reference level, an interaction contrast where defined and identifiable, and separate assessments of identification and effect.

The public-record analysis does not establish that any case meets the profile. It shows only that evidence sufficiency, reasons, practical review, categorical simplification, feedback routing, warning persistence, and remedy are auditable objects outside the conceptual model, while role-level effective authority remains inadequately captured. A test of the profile requires longitudinal workflow data, independent outcome reconstruction, standardized measurement of conditional actionability, and an authority map. The binary label earns separate use only if it improves a declared decision beyond continuous components and established theories under preregistered, finite evaluation rules. Until then, GCL-PC is a provisional profile specification, not a forecast or a validated diagnosis.

# Appendix A. Trilogy Terminology Map {.unnumbered}

The terms below belong to different levels of analysis. None may acquire decision authority merely because it appears earlier in the chain.

| Term | Primary level | Meaning and authority boundary |
|---|---|---|
| Gate state | Case (Part I) | PASS, REVIEW, BLOCK or UNKNOWN; a diagnostic output, never an institutional act |
| Hard admissibility | Case (Part I) | Typed assessment (CLEAR, PROHIBITED, UNVERIFIED or CORRECTABLE) of the current proposed action; not created by a signature |
| Route and signed disposition | Case (Part I) | Separate typed outputs of Stage 1 and Stage 2; a signed disposition is not an execution |
| Execution event | Case (Part I) | Separately authorized act requiring current admissibility, Gate 1 and Gate 3 PASS, a bound snapshot, authority and a durable record |
| Incipient capacity-loss risk | Institution (Part II) | Research report of established J and G decline with N impairment not established; not an institutional determination |
| GCL-PC | Institution (Part II) | Research classification: procedural continuity, persistent J and G decline, protected-function impairment |
| Ordinary-exposure causal specification | Population (Part II) | Research estimand with separate identification and effect assessment; replaces the former PAC subtype |
| GDI and validity hold | Monitoring (Part III) | Candidate measure and investigation boundary; cannot authorize action |
| Governance incident | Institution (Part III) | Determination by a competent authority; may use but is not defined by a Part II profile |
| Resolution Collapse | Transition (Part III) | Authorized finding that remediation cannot restore operation within the approved horizon; one sufficient basis for retirement, not the only one |
| Circuit Breaker | Transition (Part III) | Authorized, scoped, reversible containment; not retirement or closure |
| Proper Ending and Authority Return | Institution (Part III) | Authorized retirement process and accountable disposition of decision capacity and residual duties |
| Closure and redeployment | Institution (Part III) | Completion of the exit episode, which does not extinguish residual duties; redeployment is a separate new deployment decision |

Table: Trilogy terminology map and authority boundaries. The same map appears in all three papers.

# Appendix B. Profile State Space and Verification {.unnumbered}

The classification rule of Section 4.1 was enumerated over all $3^4 = 81$ three-valued profiles by `part2_v63_classification.py`: 1 profile meets the criteria, 65 are ruled out by at least one unmet condition, and 15 are indeterminate. Among the 16 complete profiles, 7 have established protected-function impairment outside GCL-PC and 2 constitute incipient risk with evidence against impairment. The effect-assessment rule of Table 3 was tested on nine boundary cases, including the threshold itself, an interval touching zero, and an unidentified effect. The script also confirms that no profile generates an automatic incident or action. These are logical tests of the specification, not empirical classifications. The full profile table is distributed as `part2_profiles.csv`.

The synthetic counterexamples that motivated the v6.3 revisions are retained in the reproducibility package (scripts C2–C6). They show, under stated data-generating processes, that a count-based measure of G inherits declines in J; that ceiling effects reduce raw metric–outcome correlation while a conditional coefficient remains stable; that a common channel shock produces forward and reverse associations of similar size after fixed effects; that the verdict of P1 can change with the measurement scale; and that combinations of independent traces beat single traces without any coupling. They illustrate failure modes of tests, not properties of real institutions.

# Data, Materials, and Reproducibility {.unnumbered}

The empirical material is limited to the shared trilogy public-record corpus: fifteen author-coded evidence units from three official investigations. The matrix is a traceability artifact, not validation data. The v6.3 reproducibility package contains the classification script, the synthetic counterexample scripts, their recorded outputs, and SHA-256 checksums. A future validation package should preserve preregistered construct definitions, coder codebooks and reliability outputs, the standardized challenge protocol, field availability and latency, protected-function measures, versioned authority maps, causal graph and estimand, analysis code, and independently sampled successful, recovered, failure, and boundary comparisons. No participant, employer, client, or confidential data are analyzed.

# Generative AI Use Disclosure {.unnumbered}

Generative AI systems were used throughout the preparation of this trilogy. OpenAI ChatGPT/Codex assisted during versions 5.0–6.2 with literature discovery, structural and language revision, code review, document generation and quality assurance; for version 6.3 it drafted revision specifications and candidate texts and code, and audited the release candidate by re-executing its verification code. Anthropic Claude reviewed Part II version 6.2, audited the revision candidates and constructed the counterexamples that led to corrections, conducted the follow-up reachability audit of the Part III guard model, wrote the Part I integrated model, re-executed the verification code, updated bibliographic records, and drafted the version 6.3 manuscripts under the author's direction.

Some AI review sessions were instructed to assess the supplied material without other systems’ conclusions. Actual isolation cannot be independently guaranteed. Information-isolated AI review is a procedural control on one source of bias; it is not independent human scholarly peer review. Several systems involved in review also helped write or revise the work; agreement among AI systems does not independently establish correctness. The trilogy has not undergone independent human peer review. The author directed the work, made every final decision, and remains responsible for every claim, citation, analysis and conclusion.

# Conflicts of Interest and Funding {.unnumbered}

The author declares no conflict of interest and received no external funding for this work.

# References {.unnumbered}

::: {.references}
Bainbridge, L. (1983). Ironies of automation. *Automatica, 19*(6), 775–779. <https://doi.org/10.1016/0005-1098(83)90046-8>

Bovens, M., & Zouridis, S. (2002). From street-level to system-level bureaucracies: How information and communication technology is transforming administrative discretion and constitutional control. *Public Administration Review, 62*(2), 174–184. <https://doi.org/10.1111/0033-3352.00168>

Brodkin, E. Z. (2011). Policy work: Street-level organizations under new managerialism. *Journal of Public Administration Research and Theory, 21*(Suppl. 2), i253–i277. <https://doi.org/10.1093/jopart/muq093>

Bromley, P., & Powell, W. W. (2012). From smoke and mirrors to walking the talk: Decoupling in the contemporary world. *Academy of Management Annals, 6*(1), 483–530. <https://doi.org/10.5465/19416520.2012.684462>

Campbell, D. T. (1979). Assessing the impact of planned social change. *Evaluation and Program Planning, 2*(1), 67–90. <https://doi.org/10.1016/0149-7189(79)90048-X>

Childcare Allowance Parliamentary Inquiry Committee. (2020). *Ongekend onrecht: Verslag Parlementaire ondervragingscommissie Kinderopvangtoeslag*. House of Representatives of the States General of the Netherlands. Official report.

Christin, A. (2017). Algorithms in practice: Comparing web journalism and criminal justice. *Big Data & Society, 4*(2). <https://doi.org/10.1177/2053951717718855>

Detert, J. R., & Burris, E. R. (2007). Leadership behavior and employee voice: Is the door really open? *Academy of Management Journal, 50*(4), 869–884. <https://doi.org/10.5465/amj.2007.26279183>

Elish, M. C. (2019). Moral crumple zones: Cautionary tales in human-robot interaction. *Engaging Science, Technology, and Society, 5*, 40–60. <https://doi.org/10.17351/ests2019.260>

Endsley, M. R., & Kiris, E. O. (1995). The out-of-the-loop performance problem and level of control in automation. *Human Factors, 37*(2), 381–394. <https://doi.org/10.1518/001872095779064555>

Engin, Z. (2026). Human-AI governance (HAIG): A trust-utility approach. *Journal of Responsible Technology, 26*, 100167. <https://doi.org/10.1016/j.jrt.2026.100167>

Erpenbach, E. M. (2026, July 28). Board oversight of AI: Why process controls may not be enough. *Oxford Business Law Blog*. <https://blogs.law.ox.ac.uk/oblb/blog-post/2026/07/board-oversight-ai-why-process-controls-may-not-be-enough>

Ferrario, A., & Hatherley, J. (2026). *Update opacity: Epistemic accessibility and governance under AI system change*. arXiv preprint arXiv:2606.00037. <https://doi.org/10.48550/arXiv.2606.00037>

Frimpong, V. (2026). *The governance inversion hypothesis: Why more AI regulation may produce less organisational control*. arXiv preprint arXiv:2606.26117. <https://doi.org/10.48550/arXiv.2606.26117>

Gaube, S., Langer, M., Miller, T., Baum, K., Dachselt, R., Feit, A. M., Gadiraju, U., Kaur, H., Keane, M. T., Landers, R., Laux, J., Liao, Q. V., Lim, B., Onnasch, L., Schrills, T., Sonenberg, L., Tan, C., Tintarev, N., Xiao, Z., & Zhang, H. (2026). *Keeping an eye on AI: A framework for effective human oversight of AI systems*. arXiv preprint arXiv:2605.16278. <https://doi.org/10.48550/arXiv.2605.16278>

Goodhart, C. A. E. (1984). Problems of monetary management: The UK experience. In *Monetary theory and practice: The UK experience*. Macmillan. (Original work presented 1975). <https://doi.org/10.1007/978-1-349-17295-5_4>

Green, B. (2022). The flaws of policies requiring human oversight of government algorithms. *Computer Law & Security Review, 45*, 105681. <https://doi.org/10.1016/j.clsr.2022.105681>

Havyarimana, J. C. (2026). *The hollowing of office: Human sovereignty, compelled assent, and the loss of discernment when AI governs in practice*. SSRN Working Paper 7218298. <https://doi.org/10.2139/ssrn.7218298>

Hernán, M. A., & Robins, J. M. (2020). *Causal Inference: What If*. Boca Raton: Chapman & Hall/CRC.

Hirschman, A. O. (1970). *Exit, voice, and loyalty: Responses to decline in firms, organizations, and states*. Harvard University Press.

Jaakkola, E. (2020). Designing conceptual articles: Four approaches. *AMS Review, 10*, 18–26. <https://doi.org/10.1007/s13162-020-00161-0>

Jacobs, A. Z., & Wallach, H. (2021). Measurement and fairness. *Proceedings of the 2021 ACM Conference on Fairness, Accountability, and Transparency*, 375–385. <https://doi.org/10.1145/3442188.3445901>

Kellogg, K. C., Valentine, M. A., & Christin, A. (2020). Algorithms at work: The new contested terrain of control. *Academy of Management Annals, 14*(1), 366–410. <https://doi.org/10.5465/annals.2018.0174>

Lin, F., Ge, Q., Xu, L., Li, P., Gao, X., Xing, S., Yamada, K., Zhang, Z., Zhang, H., & Tu, Z. (2026). *Position: Human-centric AI requires a minimum viable level of human understanding*. arXiv preprint arXiv:2602.00854. <https://doi.org/10.48550/arXiv.2602.00854>

Lipsky, M. (1980). *Street-Level Bureaucracy: Dilemmas of the Individual in Public Services*. Russell Sage Foundation.

Meyer, J. W., & Rowan, B. (1977). Institutionalized organizations: Formal structure as myth and ceremony. *American Journal of Sociology, 83*(2), 340–363. <https://doi.org/10.1086/226550>

Michigan Office of the Auditor General. (2016). *Claimant Services: Unemployment Insurance Agency* (Performance Audit Report 641-0318-14). Official report.

Morrison, E. W., & Milliken, F. J. (2000). Organizational silence: A barrier to change and development in a pluralistic world. *Academy of Management Review, 25*(4), 706–725. <https://doi.org/10.5465/amr.2000.3707697>

Morrison, E. W. (2014). Employee voice and silence. *Annual Review of Organizational Psychology and Organizational Behavior, 1*, 173–197. <https://doi.org/10.1146/annurev-orgpsych-031413-091328>

Morrison, E. W. (2023). Employee voice and silence: Taking stock a decade later. *Annual Review of Organizational Psychology and Organizational Behavior, 10*, 79–107. <https://doi.org/10.1146/annurev-orgpsych-120920-054654>

Niu, X. (2026). *The chancellor trap: Administrative mediation and the hollowing of sovereignty in the algorithmic age*. arXiv preprint arXiv:2602.18474. <https://doi.org/10.48550/arXiv.2602.18474>

Parasuraman, R., & Manzey, D. H. (2010). Complacency and bias in human use of automation: An attentional integration. *Human Factors, 52*(3), 381–410. <https://doi.org/10.1177/0018720810376055>

Power, M. (1997). *The Audit Society: Rituals of Verification*. Oxford University Press.

Rasmussen, J. (1997). Risk management in a dynamic society: A modelling problem. *Safety Science, 27*(2–3), 183–213. <https://doi.org/10.1016/S0925-7535(97)00052-0>

Royal Commission into the Robodebt Scheme. (2023). *Report of the Royal Commission into the Robodebt Scheme*. Australian Government. Official report and recommendations.

Sato, T. (2026a). *Workflow-Centric AI Governance: A Typed Gate Contract for Accountable Human–AI Decisions (working paper v6.3)*. SSRN. <https://doi.org/10.2139/ssrn.5911063>

Sato, T. (2026c). *From Governance Drift to Accountable Exit: Proper Ending and Authority Return in AI-Assisted Institutions (working paper v6.3)*. SSRN. <https://doi.org/10.2139/ssrn.6066430>

Scott, J. C. (1998). *Seeing like a state: How certain schemes to improve the human condition have failed*. Yale University Press.

Simons, J. R., & Broniatowski, D. A. (2026). *Why AI governance frameworks are hard to adopt: A role-based stress test of the NIST AI RMF*. arXiv preprint arXiv:2608.12352. <https://doi.org/10.48550/arXiv.2608.12352>

Sterz, S., Baum, K., Biewer, S., Hermanns, H., Lauber-Rönsberg, A., Meinel, P., & Langer, M. (2024). On the quest for effectiveness in human oversight: Interdisciplinary perspectives. *Proceedings of the 2024 ACM Conference on Fairness, Accountability, and Transparency*, 2495–2507. <https://doi.org/10.1145/3630106.3659051>

Tallam, K. (2026). *The khipu problem: Institutional legibility under distributed cognition*. arXiv preprint arXiv:2606.12414. <https://doi.org/10.48550/arXiv.2606.12414>

van de Sande, D., Economou-Zavlanos, N., & van Genderen, M. E. (2026). Meaningful oversight of medical AI beyond human in the loop. *npj Digital Medicine, 9*, 569. <https://doi.org/10.1038/s41746-026-02971-1>

Vaughan, D. (1996). *The Challenger Launch Decision: Risky Technology, Culture, and Deviance at NASA*. University of Chicago Press.

Wagner, B. (2019). Liable, but not in control? Ensuring meaningful human agency in automated decision-making systems. *Policy & Internet, 11*(1), 104–122. <https://doi.org/10.1002/poi3.198>

Whetten, D. A. (1989). What constitutes a theoretical contribution? *Academy of Management Review, 14*(4), 490–495. <https://doi.org/10.5465/amr.1989.4308371>

Winecoff, A. A., & Bogen, M. (2025). Improving governance outcomes through AI documentation: Bridging theory and practice. *Proceedings of the 2025 CHI Conference on Human Factors in Computing Systems*, Article 1194, 1–18. <https://doi.org/10.1145/3706598.3713814>

:::
