#!/usr/bin/env python3
"""Text-code consistency check: every headline number stated in the manuscripts must equal the
value in the recorded verification results, and must appear in the manuscript text.

Usage: python3 -I code/text_code_consistency.py <manuscripts_dir> <recorded_results_dir>
Exits non-zero on any mismatch.
"""
import json, re, sys, pathlib, csv

MS, RES = map(pathlib.Path, sys.argv[1:3])
text = {p: (MS / f'{p}.md').read_text(encoding='utf8') for p in ('part1', 'part2', 'part3')}


def flat(obj, prefix=''):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from flat(v, f'{prefix}.{k}' if prefix else k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from flat(v, f'{prefix}[{i}]')
    else:
        yield prefix, obj


def values(path):
    data = json.loads((RES / path).read_text(encoding='utf8'))
    return {v for _, v in flat(data) if isinstance(v, (int, float)) and not isinstance(v, bool)}


# (claim, part, value as printed, result file whose numeric values must contain it)
CLAIMS = [
    ('M0 historical replica: states', 'part3', 8564, 'part3_baseline_check.json'),
    ('M0 historical replica: transitions', 'part3', 36096, 'part3_baseline_check.json'),
    ('M0: states with no closure path', 'part3', 1152, 'part3_baseline_check.json'),
    ('M0: retirement-authorized states stranded', 'part3', 288, 'part3_baseline_check.json'),
    ('PE-R1: reachable states', 'part3', 98948, 'part3_baseline_check.json'),
    ('Part I integrated model: states', 'part1', 134672, 'part1_integrated_model.json'),
    ('Part I integrated model: transitions', 'part1', 1787292, 'part1_integrated_model.json'),
    ('PE-R1 mutation suite: variants', 'part3', 134, 'part3_mutation/mutation_B3_S1_rerun_summary.json'),
]


def printed(n):
    return f'{n:,}' if n >= 1000 else str(n)


fail = 0
rows = []
for claim, part, n, f in CLAIMS:
    in_text = re.search(r'(?<![\d,.])' + re.escape(printed(n)) + r'(?![\d,])', text[part]) is not None
    try:
        in_code = n in values(f)
    except FileNotFoundError:
        in_code = None
    ok = in_text and in_code is True
    fail += not ok
    rows.append((claim, part, printed(n), in_text, in_code, ok))
    print(f"{'OK  ' if ok else 'FAIL'} {claim:45s} {part} {printed(n):>10s} text={in_text} results={in_code}")

# Part III mutation suite: derived counts stated in words/numbers in the text
summ = json.loads((RES / 'part3_mutation/mutation_B3_S1_rerun_summary.json').read_text())['summary_total']
g = lambda k: summ.get(k, 0)
derived = {
    'killed by historical invariants (52)': (g('KILLED_by_baseline_invariant') + g('KILLED_by_baseline_invariant(run truncated after witness)'), r'52 by the historical invariants'),
    'killed only by added invariants (31)': (g('KILLED_by_added_invariant_only') + g('KILLED_by_added_invariant_only(run truncated after witness)'), r'31 only by invariants added in PE-R1'),
    'truncated after witness (nine)': (g('KILLED_by_baseline_invariant(run truncated after witness)') + g('KILLED_by_added_invariant_only(run truncated after witness)'), r'nine of these reached the cap'),
    'equivalent (42)': (g('EQUIVALENT(labeled graph identical)'), r'Forty-two variants are equivalent'),
    'surviving (nine)': (g('SURVIVOR(behaviour changed, nothing detected)'), r'Nine mutation variants survive'),
}
expect = {'killed by historical invariants (52)': 52, 'killed only by added invariants (31)': 31,
          'truncated after witness (nine)': 9, 'equivalent (42)': 42, 'surviving (nine)': 9}
for k, (val, phrase) in derived.items():
    ok = val == expect[k] and re.search(phrase, text['part3']) is not None
    fail += not ok
    print(f"{'OK  ' if ok else 'FAIL'} PE-R1 mutation: {k:38s} results={val} text_phrase={bool(re.search(phrase, text['part3']))}")

# Part II: 81 profiles in the CSV and in the text
with open(RES / 'part2_profiles.csv', encoding='utf8') as fh:
    nprof = sum(1 for _ in csv.DictReader(fh))
ok = nprof == 81 and re.search(r'\b81\b', text['part2']) is not None
fail += not ok
print(f"{'OK  ' if ok else 'FAIL'} Part II: GCL-PC profiles                    part2 {nprof:>10d} text={'81' in text['part2']}")
sys.exit(1 if fail else 0)
