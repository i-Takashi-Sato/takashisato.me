"""Part I v6.3 design candidate: typed routing/disposition and execution guards.
Not the historical checker or a full domain implementation. Standard library only.
All booleans are truthful externally supplied predicates, not authentication itself.
"""
from dataclasses import dataclass, replace
from enum import Enum
from itertools import product
from collections import Counter, deque
import json

class Gate(Enum):
    PASS='PASS'; REVIEW='REVIEW'; BLOCK='BLOCK'; UNKNOWN='UNKNOWN'
class Route(Enum):
    ELIGIBLE='S1_EXECUTION_ELIGIBLE'; HOLD='S1_EVIDENCE_HOLD'
    REVIEW='S1_AUTHORIZED_REVIEW'; FALLBACK='S1_FALLBACK'; UNRESOLVED='S1_UNRESOLVED'
class Command(Enum):
    RELEASE='RELEASE'; MODIFY='MODIFY'; REJECT='REJECT'; DEFER='DEFER'; FALLBACK='INVOKE_FALLBACK'
class Disposition(Enum):
    PENDING='S2_PENDING_REVIEW'; RELEASE='S2_RELEASE_PENDING_EXECUTION'
    MODIFY='S2_MODIFY_PENDING_RECHECK'; REJECT='S2_FINAL_STOP'; DEFER='S2_AUTHORIZED_DEFER'
    FALLBACK='S2_FALLBACK_PENDING_EXECUTION'; UNRESOLVED='S2_UNRESOLVED'
@dataclass(frozen=True)
class Instruction:
    command: Command
    valid: bool
    def __post_init__(self):
        if not isinstance(self.command, Command) or type(self.valid) is not bool:
            raise TypeError('instruction requires a command and validity flag')

ALLPASS=(Gate.PASS,)*3
BITS=(False,True)

def triage(g,r,c,b,f):
    if g==ALLPASS: return Route.ELIGIBLE
    if r and c:
        return Route.HOLD if Gate.UNKNOWN in g else Route.REVIEW
    if b and f: return Route.FALLBACK
    return Route.UNRESOLVED

def route_partition(g,r,c,b,f):
    """Explicit mutually exclusive iff clauses (separate declarative oracle)."""
    non=g!=ALLPASS; u=Gate.UNKNOWN in g; rc=r and c; bf=b and f
    return {Route.ELIGIBLE:not non, Route.HOLD:non and u and rc,
            Route.REVIEW:non and not u and rc,
            Route.FALLBACK:non and not rc and bf,
            Route.UNRESOLVED:non and not rc and not bf}

def disposition(entry,instruction,b,f):
    if entry is not Route.REVIEW: raise ValueError('Stage 2 requires an authorized review entry')
    if instruction is None or not instruction.valid: return Disposition.PENDING
    q=instruction.command
    if q is Command.FALLBACK:
        return Disposition.FALLBACK if b and f else Disposition.UNRESOLVED
    return {Command.RELEASE:Disposition.RELEASE,Command.MODIFY:Disposition.MODIFY,
            Command.REJECT:Disposition.REJECT,Command.DEFER:Disposition.DEFER}[q]

def disposition_partition(ins,b,f):
    valid=ins is not None and ins.valid
    q=ins.command if ins else None
    return {Disposition.PENDING:not valid,
            Disposition.RELEASE:valid and q is Command.RELEASE,
            Disposition.MODIFY:valid and q is Command.MODIFY,
            Disposition.REJECT:valid and q is Command.REJECT,
            Disposition.DEFER:valid and q is Command.DEFER,
            Disposition.FALLBACK:valid and q is Command.FALLBACK and b and f,
            Disposition.UNRESOLVED:valid and q is Command.FALLBACK and not(b and f)}

class HardStatus(Enum):
    CLEAR="clear"; PROHIBITED="prohibited"; UNVERIFIED="unverified"; CORRECTABLE="correctable"

class Mode(Enum):
    DIRECT='DIRECT'; RELEASE='RELEASE'; MODIFIED='MODIFIED'; FALLBACK_1='FALLBACK_1'; FALLBACK_2='FALLBACK_2'
@dataclass(frozen=True)
class Facts:
    gates: tuple  # current diagnostics for the action actually proposed, not original case if modified/fallback
    hard_status: HardStatus # typed external assessment of the current action; CLEAR requires affirmative admissibility
    fresh: bool # evidence, policy, version, proposal and record snapshot current and bound
    domain_authorized: bool # actual executor authorized, standing readiness and separation-of-duties satisfied
    record_ready: bool # durable required record can be atomically committed with action
    resolved: bool # all remaining reviewable objections resolved by applicable authorized process
    instruction_current: bool # authenticated, in-scope, current at action time
    instruction_matches: bool # exact action and case bound to correct command
    fallback_authorized: bool
    fallback_ready: bool
    alternative_adequate: bool # separate evidence and domain constraints for alternative service

# For this conservative candidate, a modified proposal must pass a fresh triage,
# or return to review for a new disposition. No special override of hard rules.
def can_execute(mode,x):
    if x.hard_status is not HardStatus.CLEAR or x.gates[0] is not Gate.PASS: return False
    if not (x.fresh and x.domain_authorized and x.record_ready): return False
    if Gate.UNKNOWN in x.gates: return False
    if mode is Mode.DIRECT: return x.gates==ALLPASS
    if mode is Mode.RELEASE:
        return x.resolved and x.instruction_current and x.instruction_matches
    if mode is Mode.MODIFIED:
        return x.gates==ALLPASS and x.instruction_current and x.instruction_matches
    if mode in (Mode.FALLBACK_1,Mode.FALLBACK_2):
        return (x.gates==ALLPASS and x.fallback_authorized and x.fallback_ready and x.alternative_adequate
                and (mode is Mode.FALLBACK_1 or (x.instruction_current and x.instruction_matches)))
    raise ValueError(mode)

def safety_violations(mode,x,allowed):
    if not allowed: return []
    violations=[]
    if x.hard_status is not HardStatus.CLEAR or x.gates[0] is not Gate.PASS: violations.append('hard_admissibility_not_established')
    for k in ('fresh','domain_authorized','record_ready'):
        if not getattr(x,k): violations.append(k)
    if Gate.UNKNOWN in x.gates: violations.append('unknown_candidate_evidence')
    if mode in (Mode.DIRECT,Mode.MODIFIED,Mode.FALLBACK_1,Mode.FALLBACK_2) and x.gates!=ALLPASS:
        violations.append('fresh_candidate_not_allpass')
    if mode in (Mode.RELEASE,Mode.MODIFIED,Mode.FALLBACK_2) and not (x.instruction_current and x.instruction_matches):
        violations.append('unbound_or_invalid_instruction')
    if mode is Mode.RELEASE and not x.resolved: violations.append('unresolved_review')
    if mode in (Mode.FALLBACK_1,Mode.FALLBACK_2) and not (x.fallback_authorized and x.fallback_ready and x.alternative_adequate):
        violations.append('unsafe_fallback')
    return violations

# Small temporal projection: demonstrates invalidation, reroute, defer, fallback completion,
# and escalation. It deliberately does not claim liveness under a hostile environment.
class Phase(Enum):
    REVIEW='review'; ELIGIBLE='eligible'; HOLD='hold'; DEFER='defer'; UNRESOLVED='unresolved'
    FALLBACK='fallback'; FALLBACK_ACTIVE='fallback_active'; ESCALATED='escalated'
    EXECUTED='executed'; REJECTED='rejected'; FALLBACK_DONE='fallback_done'
TERMINAL={Phase.EXECUTED,Phase.REJECTED,Phase.FALLBACK_DONE}
@dataclass(frozen=True)
class State:
    phase: Phase=Phase.HOLD
    fresh: bool=False
    hard: HardStatus=HardStatus.CLEAR
    authority: bool=True
    record: bool=True
    due: bool=False
    bound: bool=False
    mode: Mode=Mode.DIRECT
    resume_ready: bool=False

def transitions(s):
    if s.phase in TERMINAL: return
    # An environment update invalidates the binding, rather than retrospectively changing an action.
    for k in ('fresh','authority','record'):
        yield 'change_'+k,replace(s,**{k:not getattr(s,k),'bound':False})
    for h in HardStatus:
        if h is not s.hard: yield 'change_hard',replace(s,hard=h,bound=False)
    if s.phase is Phase.DEFER:
        yield 'change_resume_condition',replace(s,resume_ready=not s.resume_ready)
        if s.resume_ready and s.authority and s.record and not s.due:
            yield 'authorized_resume',replace(s,phase=Phase.HOLD,bound=False,resume_ready=False)
    if not s.due: yield 'deadline_elapsed',replace(s,due=True)
    if s.due and s.phase not in (Phase.ESCALATED,Phase.FALLBACK_ACTIVE):
        yield 'escalate',replace(s,phase=Phase.ESCALATED,bound=False)
    if s.phase is Phase.ESCALATED and s.authority and s.record:
        yield 'authorized_reassignment',replace(s,phase=Phase.HOLD,due=False,bound=False,resume_ready=False)
    if s.phase is Phase.REVIEW and s.authority and s.fresh and s.record and not s.due:
        yield 'signed_defer',replace(s,phase=Phase.DEFER,bound=False,resume_ready=False)
        if s.record: yield 'signed_reject',replace(s,phase=Phase.REJECTED)
        yield 'signed_release',replace(s,phase=Phase.ELIGIBLE,mode=Mode.RELEASE,bound=True)
        yield 'signed_modify_reroute',replace(s,phase=Phase.HOLD,mode=Mode.MODIFIED,bound=True)
        yield 'signed_fallback',replace(s,phase=Phase.FALLBACK,mode=Mode.FALLBACK_2,bound=True)
    # A fresh domain check establishes the appropriate route. This abstracts actual gate updates.
    if s.fresh and not s.due and s.phase not in (Phase.FALLBACK_ACTIVE,Phase.DEFER,Phase.ESCALATED):
        yield 'reroute_review',replace(s,phase=Phase.REVIEW,bound=False,mode=Mode.RELEASE)
        yield 'reroute_allpass',replace(s,phase=Phase.ELIGIBLE,bound=True,mode=Mode.DIRECT)
        yield 'reroute_fallback',replace(s,phase=Phase.FALLBACK,bound=True,mode=Mode.FALLBACK_1)
    if s.phase in (Phase.ELIGIBLE,Phase.FALLBACK) and s.bound and s.fresh and s.hard is HardStatus.CLEAR and s.authority and s.record and not s.due:
        if s.phase is Phase.ELIGIBLE:
            yield 'execute',replace(s,phase=Phase.EXECUTED)
        else:
            yield 'start_fallback',replace(s,phase=Phase.FALLBACK_ACTIVE)
    # Completion is a record of service outcome, not a second execution permission.
    if s.phase is Phase.FALLBACK_ACTIVE and s.record:
        yield 'record_fallback_completion',replace(s,phase=Phase.FALLBACK_DONE)
    if s.phase is Phase.FALLBACK_ACTIVE and s.due:
        yield 'record_failed_fallback_and_escalate',replace(s,phase=Phase.ESCALATED,bound=False)

def check_temporal():
    initial=State(); todo=deque([initial]); seen={initial}; edges=0; commits=0
    while todo:
        s=todo.popleft()
        for event,t in transitions(s):
            if t==s: continue
            edges+=1
            if event in ('execute','start_fallback'):
                commits+=1
                assert s.bound and s.fresh and s.hard is HardStatus.CLEAR and s.authority and s.record and not s.due
            if t.phase is Phase.EXECUTED: assert event=='execute'
            if t.phase is Phase.REJECTED: assert event=='signed_reject' and s.authority and s.record and s.fresh
            if t.phase is Phase.FALLBACK_DONE: assert s.phase is Phase.FALLBACK_ACTIVE and event=='record_fallback_completion'
            if t not in seen: seen.add(t); todo.append(t)
    assert {s.phase for s in seen} >= {Phase.DEFER,Phase.EXECUTED,Phase.FALLBACK_DONE,Phase.ESCALATED}
    # Explicit stale binding, revocation, and deadline witnesses.
    initial_valid=State(Phase.ELIGIBLE,True,HardStatus.CLEAR,True,True,False,True,Mode.DIRECT)
    for event,s in transitions(initial_valid):
        if event in ('change_fresh','change_hard','change_authority','change_record','deadline_elapsed'):
            assert 'execute' not in dict(transitions(s))
    return {'states':len(seen),'transitions':edges,'checked_action_edges':commits,'scope':'small temporal projection; no real clocks, identity, payloads, or unconditional liveness'}

def main():
    d1=Counter(); d2=Counter(); n1=n2=0
    patterns=list(product(Gate,repeat=3))
    for g,(r,c,b,f) in product(patterns,product(BITS,repeat=4)):
        out=triage(g,r,c,b,f); clauses=route_partition(g,r,c,b,f)
        assert sum(clauses.values())==1 and clauses[out]
        n1+=1; d1[out.value]+=1
    ins=[None]+[Instruction(q,v) for q,v in product(Command,BITS)]
    for g,i,(b,f) in product([g for g in patterns if g!=ALLPASS and Gate.UNKNOWN not in g],ins,product(BITS,repeat=2)):
        out=disposition(Route.REVIEW,i,b,f); clauses=disposition_partition(i,b,f)
        assert sum(clauses.values())==1 and clauses[out]
        n2+=1; d2[out.value]+=1
    assert set(Route).isdisjoint(Disposition)
    for invalid in Route:
        if invalid is Route.REVIEW: continue
        try: disposition(invalid,None,True,True)
        except ValueError: pass
        else: raise AssertionError('invalid Stage 2 entry')
    total=allowed=0; per=Counter(); caught=Counter()
    for mode,g,h,bits in product(Mode,patterns,HardStatus,product(BITS,repeat=9)):
        x=Facts(g,h,*bits); yes=can_execute(mode,x); total+=1
        assert not safety_violations(mode,x,yes)
        if yes:
            allowed+=1; per[mode.value]+=1
    # Targeted omission mutations: demonstrate each predicate is necessary for at least one relevant mode.
    valid=Facts(ALLPASS,HardStatus.CLEAR,*([True]*9))
    for mode in Mode:
        assert can_execute(mode,valid)
        for field in ('fresh','domain_authorized','record_ready','resolved','instruction_current','instruction_matches','fallback_authorized','fallback_ready','alternative_adequate'):
            x=replace(valid,**{field:False})
            if not can_execute(mode,x):
                assert safety_violations(mode,x,True)
                caught[field]+=1
        assert not can_execute(mode,replace(valid,gates=(Gate.PASS,Gate.PASS,Gate.UNKNOWN)))
    return {'stage1':{'inputs':n1,'distribution':d1,'two_encoding_agreement':n1},'stage2':{'inputs':n2,'distribution':d2,'two_encoding_agreement':n2},'execution_guard':{'configurations':total,'permitted':allowed,'per_mode':per,'encoded_guard_agreement_only':True,'omission_witness_modes':caught},'temporal_projection':check_temporal()}
if __name__=='__main__': print(json.dumps(main(),indent=2))
