# Part II v6.2 独立査読：検証コード

入力: takashisato.me 公開リポジトリの pdf/v6.2/part2.pdf（SHA-256 6cb7a219...5d88）を `pdftotext -layout` で変換した part2.txt。
すべて合成データ。乱数シードは固定。Python 3.13, numpy, scipy, scikit-learn 1.9, statsmodels。

| ファイル | 内容 | 出力 |
|---|---|---|
| c1_refcheck.py | 本文引用と文献リストの照合 | out/c1.txt |
| c2_state_logic.py | 16状態の列挙、S_NA状態、AND誤差伝播、閾値の自由度 | out/c2.txt |
| c3_pac_causal.py | 参照水準m、g公式（著者に有利）、分析単位、部分識別 | out/c3.txt |
| c4_measurement_props.py | J→G汚染、P2天井効果、P3共通ショック、P1尺度依存、P4加法結合 | out/c4.txt |
| c5_p5_binary_vs_continuous.py | P5：サイト単位入れ子CVで二値vs連続（6条件、25反復） | out/c5_v2_results.txt（初回の稀少状態版は out/c5_v1_rare_state_results.txt） |
| c6_followup_checks.py | 外部査読の留保への追加確認：P2の条件付き回帰、P3のクラスター頑健SEと固定効果 | out/c6.txt |

実行: `python3 -I code/c2_state_logic.py` など。c5 は `python3 -I -W ignore code/c5_p5_binary_vs_continuous.py 25`（約15分）。
