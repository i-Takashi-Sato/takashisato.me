"""C2: Exhaustive state-space audit of the Part II classification rule and
error propagation through the four-way conjunction.

Rule as printed (Sec. 4):
  PMGCL = F_P & D_J & D_G & I_N
  PAC   = PMGCL & S_NA == IDENTIFIED
  Incipient risk (Sec. 4.1): D_J & D_G & N impairment 'not demonstrated or not observable'
"""
import itertools, numpy as np

names = ["F_P", "D_J", "D_G", "I_N"]
print("== C2a: 16 descriptive configurations and the label Part II assigns ==")
unnamed = []
for bits in itertools.product([0, 1], repeat=4):
    fp, dj, dg, inn = bits
    if all(bits):
        lab = "realized PMGCL (PAC if S_NA=IDENTIFIED)"
    elif dj and dg and not inn:
        lab = "incipient risk" + ("" if fp else "  [F_P not required: unmasked decline also 'incipient']")
    else:
        lab = "-- no Part II label --"
        if inn:
            unnamed.append(bits)
    print(dict(zip(names, bits)), "->", lab)
print("Configurations with protected-function impairment but no Part II state:", len(unnamed))
for u in unnamed:
    print("   ", dict(zip(names, u)))

print("\n== C2b: S_NA reporting states vs. logical possibilities ==")
cases = {
    "point-identified, CI wholly below -delta": "IDENTIFIED -> PAC eligible",
    "point-identified, CI includes 0 / immaterial": "rule says 'bounded or unidentified' -> mislabels an identified null",
    "point-identified, effect beneficial": "no state defined",
    "partially identified, sharp bounds wholly below -delta": "BOUNDED -> PAC barred, although adverse materiality is logically established",
    "partially identified, bounds straddle -delta": "BOUNDED -> PAC barred (correct)",
    "unidentified": "UNIDENTIFIED -> PAC barred (correct)",
}
for k, v in cases.items():
    print(f"  {k:58s} => {v}")

print("\n== C2c: error propagation through the 4-way conjunction ==")
# Independent element-level errors; sensitivity s_k and specificity c_k per element.
def conj_perf(sens, spec, prev, n_false_profile):
    """sens/spec: arrays per element. Non-cases: assume exactly n_false of 4 elements truly false
    (worst case for specificity = 1 false element)."""
    s = np.prod(sens)
    # specificity for a non-case with exactly one false element (element j):
    spec1 = np.mean([1 - (1 - spec[j]) * np.prod([sens[k] for k in range(4) if k != j]) for j in range(4)])
    ppv = s * prev / (s * prev + (1 - spec1) * (1 - prev))
    return s, spec1, ppv

for se, sp in [(0.95, 0.95), (0.85, 0.90), (0.75, 0.85)]:
    sens = np.full(4, se); spec = np.full(4, sp)
    for prev in (0.02, 0.10, 0.30):
        s, c, ppv = conj_perf(sens, spec, prev, 1)
        print(f"  element sens={se:.2f} spec={sp:.2f} prevalence={prev:.2f}: "
              f"conjunction sens={s:.3f}, spec(near-miss non-case)={c:.3f}, PPV={ppv:.3f}")

print("\n== C2d: threshold multiplicity (forking paths) on one synthetic workflow ==")
rng = np.random.default_rng(20261128)
# One workflow, 24 monthly windows. Pre-period 12, post 12. Modest, noisy declines.
T = 24
t = np.arange(T)
P = 0.90 + 0.002 * t + rng.normal(0, 0.01, T)
J = 1.00 - 0.012 * np.clip(t - 11, 0, None) + rng.normal(0, 0.05, T)
G = 1.00 - 0.010 * np.clip(t - 11, 0, None) + rng.normal(0, 0.05, T)
N = 1.00 - 0.006 * np.clip(t - 11, 0, None) + rng.normal(0, 0.04, T)
pre, post = slice(0, 12), slice(12, 24)
def classify(mat_J, mat_G, mat_N, persist_k, baseline):
    b = {"pre-mean": np.mean, "pre-median": np.median, "pre-max": np.max}[baseline]
    def decline(x, m):
        base = b(x[pre]); last = x[post][-persist_k:]
        return np.all(last < base - m)
    fp = np.mean(P[post]) >= b(P[pre]) - 0.005
    return int(fp and decline(J, mat_J) and decline(G, mat_G) and decline(N, mat_N))
grid = list(itertools.product([0.05, 0.10, 0.15], [0.05, 0.10, 0.15], [0.02, 0.05, 0.08], [2, 3, 6], ["pre-mean", "pre-median", "pre-max"]))
res = np.array([classify(*g) for g in grid])
print(f"  {len(grid)} defensible threshold/persistence/baseline specifications; PMGCL=1 in {res.sum()} ({res.mean():.1%})")
print("  -> the binary label for the same data depends on unconstrained analyst choices unless all are preregistered.")
