"""C1: In-text citation <-> reference-list integrity check for Part II v6.2.
Input: pdftotext -layout output of part2.pdf (path as argv[1]).
"""
import re, sys, collections

txt = open(sys.argv[1], encoding="utf-8").read()
body, refs = txt.split("\nReferences\n", 1)

# reference list: lines beginning with "Surname, X." pattern
ref_entries = re.findall(r"^([A-Z][A-Za-z\-' ]+?|van de Sande), [A-Z]\..*?\((\d{4}[a-z]?)\)", refs, flags=re.M)
ref_entries += re.findall(r"^(Childcare Allowance Parliamentary Inquiry Committee|Michigan Office of the Auditor General|Royal Commission into the Robodebt Scheme)\. \((\d{4})\)", refs, flags=re.M)
ref_keys = {(a.strip().split()[-1] if not a.startswith(("Childcare","Michigan","Royal")) else a.split()[0], y) for a, y in ref_entries}

# in-text citations: "Surname (YYYY)", "Surname, YYYY", "Surname and X, YYYY", "Surname et al. (YYYY)"
cites = set()
for m in re.finditer(r"([A-Z][A-Za-z\-]+)(?: et al\.)?(?:,? and [A-Z][A-Za-z\-]+)?(?:, [A-Z][A-Za-z\-]+, and [A-Z][A-Za-z\-]+)?,? \(?(\d{4}[a-z]?)(?:, (\d{4}))?\)?", body):
    name, y1, y2 = m.group(1), m.group(2), m.group(3)
    if name in {"SSRN", "VERSION", "PAPER", "August", "Version", "Part", "AUGUST"}:
        continue
    cites.add((name, y1))
    if y2:
        cites.add((name, y2))
# institutional cites
for inst in ["Childcare", "Michigan", "Royal"]:
    if re.search(inst + r"[^.]*?(20\d\d)", body):
        pass
ref_surnames = collections.defaultdict(set)
for s, y in ref_keys:
    ref_surnames[s].add(y)

print("Reference entries parsed:", len(ref_keys))
# references never cited in body
uncited = []
for s, y in sorted(ref_keys):
    pat = re.escape(s) + r"[^()]{0,80}?\(?" + y[:4]
    if not re.search(pat, body):
        uncited.append((s, y))
print("Reference entries with no matching in-text citation:", uncited)
# body cites with no reference
missing = sorted({(n, y) for n, y in cites if n in ref_surnames and y not in ref_surnames[n]})
print("In-text name/year mismatches:", missing)
# uncited technical terms with known source
for term, src in [("moral crumple zone", "Elish 2019"), ("legibility", "Scott 1998"), ("decoupl", "Meyer & Rowan 1977 (cited); means-ends: Bromley & Powell 2012 (not cited)")]:
    print(f"term '{term}': {len(re.findall(term, body, flags=re.I))} occurrences; canonical source: {src}")
