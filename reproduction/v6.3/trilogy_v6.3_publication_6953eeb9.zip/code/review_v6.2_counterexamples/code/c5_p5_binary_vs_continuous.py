"""C5: P5 comparative retirement test, run under conditions favourable and unfavourable to Part II.

Unit = site-window. Features observed with error: P, J, G, N (higher = better; declines coded as low values).
Target Y = independent future outcome (e.g., non-recovery after a standardized corrective action).
Outer CV: GroupKFold by site (5 folds). Inner tuning: GroupKFold by site (3 folds) for regularization / boosting depth.

Models
  BIN     : logistic on preregistered PMGCL indicator (fixed thresholds; no tuning)
  BIN_T   : PMGCL indicator with thresholds tuned on inner folds (quantile grid)
  LIN     : L2 logistic on P,J,G,N (continuous, additive)
  FLEX    : histogram gradient boosting on P,J,G,N
  N_ONLY  : logistic on N alone (protected-function history baseline)
  THEORY  : logistic on P and G only (stand-in for a decoupling / authority account without N)
Metrics on outer folds: AUC, Brier, net benefit at risk threshold 0.20 (decision-curve point).
"""
import numpy as np, itertools, warnings, sys
from sklearn.model_selection import GroupKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, brier_score_loss
warnings.filterwarnings("ignore")

THR = np.array([-0.5, 0.0, 0.0, 0.0])   # preregistered: F_P if P>=-0.5 ; D_J, D_G, I_N if below 0 (z-units); state share ~15%

def pmgcl(X, thr=THR):
    return ((X[:, 0] >= thr[0]) & (X[:, 1] < thr[1]) & (X[:, 2] < thr[2]) & (X[:, 3] < thr[3])).astype(float)

def gen(scn, n_sites, n_win, rng):
    S = n_sites * n_win
    site = np.repeat(np.arange(n_sites), n_win)
    off = rng.normal(0, 0.3, (n_sites, 4))[site]
    Z = rng.multivariate_normal(np.zeros(4), np.array([[1, .1, .1, .1], [.1, 1, .5, .4], [.1, .5, 1, .4], [.1, .4, .4, 1]]), S) + off
    noise = {"and_small": 0.25, "and_large": 0.25, "smooth": 0.25, "and_misthr": 0.25, "n_dominant": 0.25, "and_noisy": 0.8}[scn]
    X = Z + rng.normal(0, noise, Z.shape)               # observed with measurement error
    if scn in ("and_small", "and_large", "and_noisy"):
        eta = -2.5 + 3.5 * pmgcl(Z)
    elif scn == "and_misthr":
        eta = -2.5 + 3.5 * pmgcl(Z, np.array([-0.5, -0.8, -0.8, -0.8]))   # true thresholds differ from preregistered
    elif scn == "smooth":
        eta = -1.6 - 0.6 * Z[:, 1] - 0.6 * Z[:, 2] - 0.6 * Z[:, 3] + 0.1 * Z[:, 0]
    elif scn == "n_dominant":
        eta = -1.6 - 1.2 * Z[:, 3]
    y = rng.binomial(1, 1 / (1 + np.exp(-eta)))
    return X, y, site

def nb(y, p, pt=0.2):
    tp = np.sum((p >= pt) & (y == 1)); fp = np.sum((p >= pt) & (y == 0)); n = len(y)
    return tp / n - fp / n * pt / (1 - pt)

def fit_predict(name, Xtr, ytr, gtr, Xte):
    if name == "BIN":
        m = LogisticRegression().fit(pmgcl(Xtr)[:, None], ytr); return m.predict_proba(pmgcl(Xte)[:, None])[:, 1]
    if name == "BIN_T":
        qs = [0.25, 0.0, -0.4, -0.8]
        best, bt = -np.inf, None
        for q in qs:
            thr = np.array([-0.5, q, q, q]); sc = []
            for a, b in GroupKFold(3).split(Xtr, ytr, gtr):
                f = pmgcl(Xtr[a], thr)
                if f.sum() == 0 or len(set(ytr[b])) < 2: sc.append(0.5); continue
                m = LogisticRegression().fit(f[:, None], ytr[a])
                sc.append(roc_auc_score(ytr[b], m.predict_proba(pmgcl(Xtr[b], thr)[:, None])[:, 1]))
            if np.mean(sc) > best: best, bt = np.mean(sc), thr
        m = LogisticRegression().fit(pmgcl(Xtr, bt)[:, None], ytr); return m.predict_proba(pmgcl(Xte, bt)[:, None])[:, 1]
    if name in ("LIN", "N_ONLY", "THEORY"):
        cols = {"LIN": [0, 1, 2, 3], "N_ONLY": [3], "THEORY": [0, 2]}[name]
        best, bc = -np.inf, 1.0
        for C in (0.01, 0.1, 1.0):
            sc = []
            for a, b in GroupKFold(3).split(Xtr, ytr, gtr):
                m = LogisticRegression(C=C).fit(Xtr[a][:, cols], ytr[a])
                sc.append(roc_auc_score(ytr[b], m.predict_proba(Xtr[b][:, cols])[:, 1]) if len(set(ytr[b])) > 1 else 0.5)
            if np.mean(sc) > best: best, bc = np.mean(sc), C
        return LogisticRegression(C=bc).fit(Xtr[:, cols], ytr).predict_proba(Xte[:, cols])[:, 1]
    if name == "FLEX":
        best, bp = -np.inf, None
        for d, lr in ((2, 0.1), (3, 0.05)):
            sc = []
            for a, b in GroupKFold(3).split(Xtr, ytr, gtr):
                m = HistGradientBoostingClassifier(max_depth=d, learning_rate=lr, max_iter=100, min_samples_leaf=10).fit(Xtr[a], ytr[a])
                sc.append(roc_auc_score(ytr[b], m.predict_proba(Xtr[b])[:, 1]) if len(set(ytr[b])) > 1 else 0.5)
            if np.mean(sc) > best: best, bp = np.mean(sc), (d, lr)
        return HistGradientBoostingClassifier(max_depth=bp[0], learning_rate=bp[1], max_iter=100, min_samples_leaf=10).fit(Xtr, ytr).predict_proba(Xte)[:, 1]

MODELS = ["BIN", "BIN_T", "LIN", "FLEX", "N_ONLY", "THEORY"]
SCN = [("and_small", 10, 20, "FAVOURABLE: true conjunctive threshold DGP, correct preregistered thresholds, small n=200"),
       ("and_large", 40, 50, "FAVOURABLE->neutral: same DGP, large n=2000"),
       ("and_noisy", 10, 20, "MIXED: conjunctive DGP, heavy measurement error, n=200"),
       ("and_misthr", 10, 20, "UNFAVOURABLE: conjunctive DGP but preregistered thresholds wrong, n=200"),
       ("smooth", 10, 20, "UNFAVOURABLE: smooth additive DGP, n=200"),
       ("n_dominant", 10, 20, "UNFAVOURABLE: outcome driven by protected-function history only, n=200")]
R = int(sys.argv[1]) if len(sys.argv) > 1 else 40
rng = np.random.default_rng(2026)
for scn, ns, nw, desc in SCN:
    res = {m: {"auc": [], "brier": [], "nb": []} for m in MODELS}
    for r in range(R):
        X, y, g = gen(scn, ns, nw, rng)
        fold = {m: {"auc": [], "brier": [], "nb": []} for m in MODELS}
        for tr, te in GroupKFold(5).split(X, y, g):
            if len(set(y[te])) < 2: continue
            for m in MODELS:
                p = fit_predict(m, X[tr], y[tr], g[tr], X[te])
                fold[m]["auc"].append(roc_auc_score(y[te], p)); fold[m]["brier"].append(brier_score_loss(y[te], p)); fold[m]["nb"].append(nb(y[te], p))
        for m in MODELS:   # metrics computed within each outer fold, then averaged (avoids cross-fold pooling artefacts)
            for k in fold[m]: res[m][k].append(np.mean(fold[m][k]))
    print(f"\n== {scn}: {desc}  (R={R} replications, prevalence ~{y.mean():.2f}, PMGCL share ~{pmgcl(X).mean():.2f})")
    print(f"  {'model':7s} {'AUC':>7s} {'Brier':>7s} {'NB@0.2':>7s}   AUC diff vs BIN [2.5%,97.5%] ; P(BIN better)")
    base = np.array(res["BIN"]["auc"])
    for m in MODELS:
        a = np.array(res[m]["auc"]); d = a - base
        print(f"  {m:7s} {a.mean():7.3f} {np.mean(res[m]['brier']):7.4f} {np.mean(res[m]['nb']):7.4f}   "
              f"{d.mean():+.3f} [{np.percentile(d,2.5):+.3f},{np.percentile(d,97.5):+.3f}] ; {np.mean(d<0):.2f}")
