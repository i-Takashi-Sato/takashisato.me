"""C3: Causal counterexamples and a favourable check for the PAC condition S_NA.
Estimand in Part II: Delta_O(m) = E[Y_N(1,m) - Y_N(0,m) | P]; PAC needs Delta_O(m) <= -delta_N.
All data synthetic. Seeds fixed.
"""
import numpy as np
rng = np.random.default_rng(7)
N = 400_000
delta = 0.05

print("== C3a: free choice of reference level m lets PAC be assigned where harm REQUIRES the malicious pathway ==")
# A_M upstream of A_O (pre-exposure), A_O randomized. Ordinary exposure harms ONLY when malicious rule present.
A_M = rng.binomial(1, 0.3, N)
A_O = rng.binomial(1, 0.5, N)
eps = rng.normal(0, 0.1, N)
def Y(a_o, a_m):  # structural equation
    return 0.80 - 0.00 * a_o - 0.10 * a_m - 0.15 * a_o * a_m + eps
cde0 = np.mean(Y(1, 0) - Y(0, 0)); cde1 = np.mean(Y(1, 1) - Y(0, 1))
print(f"  Delta_O(m=0) = {cde0:+.3f}  -> PAC {'eligible' if cde0 <= -delta else 'not eligible'}")
print(f"  Delta_O(m=1) = {cde1:+.3f}  -> PAC {'eligible' if cde1 <= -delta else 'not eligible'}")
print("  Part II allows any predeclared 'intervention/reference condition m'. With m=1 the ordinary exposure is")
print("  'materially adverse' only because the malicious pathway is switched on: the label 'pre-abuse' then")
print("  certifies an effect that exists only in the presence of abuse. Fix: require m = the no-malice level, or")
print("  report Delta_O(0) and the interaction Delta_O(1)-Delta_O(0) separately.")

print("\n== C3b (favourable to Part II): post-exposure A_M; naive restriction to A_M=0 vs g-formula ==")
A_O = rng.binomial(1, 0.5, N)
L = rng.binomial(1, 0.2 + 0.5 * A_O)                 # post-exposure strain, affects A_M and Y
A_M = rng.binomial(1, 0.05 + 0.80 * L)               # malicious workaround more likely under strain
Yobs = 0.80 - 0.02 * A_O - 0.20 * A_M - 0.12 * L + rng.normal(0, 0.1, N)
true_cde0 = -0.02 - 0.12 * (0.7 - 0.2)               # A_M fixed at 0; L allowed to respond to A_O
naive = Yobs[(A_O == 1) & (A_M == 0)].mean() - Yobs[(A_O == 0) & (A_M == 0)].mean()
def gform(a):
    tot = 0.0
    for l in (0, 1):
        p_l = np.mean(L[A_O == a] == l)
        tot += p_l * Yobs[(A_O == a) & (A_M == 0) & (L == l)].mean()
    return tot
g = gform(1) - gform(0)
print(f"  true CDE(m=0) = {true_cde0:+.3f} | naive A_M=0 restriction = {naive:+.3f} | g-formula = {g:+.3f}")
print(f"  decision at delta=0.05: truth={'PAC-eligible' if true_cde0<=-delta else 'no'}, naive={'PAC-eligible' if naive<=-delta else 'no'}, g-formula={'PAC-eligible' if g<=-delta else 'no'}")
print("  -> Part II's warning (Sec. 4, 4.3) is substantively correct. If L is unmeasured the CDE is not identified")
print("     and S_NA must be UNIDENTIFIED/BOUNDED, which the rule already handles.")

print("\n== C3c: unit-level label from a population-level contrast; exposure of the unit is never required ==")
# Use C3b population. Suppose PMGCL_i is present when Y_i < 0.55 (stand-in for the 4-way state).
pm = Yobs < 0.55
pac_labelled = pm & (g <= -delta)                       # S_NA is a property of the study, not of unit i
print(f"  share of PAC-labelled units with A_O=0 (never exposed): {np.mean(A_O[pac_labelled] == 0):.1%}")
print(f"  share of PAC-labelled units with A_M=1 (malicious pathway active): {np.mean(A_M[pac_labelled] == 1):.1%}")
print("  PAC(I)=PMGCL(I) & S_NA=IDENTIFIED attaches an etiological subtype to units that were unexposed or")
print("  whose own pathway was malicious. Fix: require A_O(I)=1 and A_M(I) at the reference level, and call it")
print("  'PMGCL in a population with an identified adverse ordinary-exposure effect' rather than a unit etiology.")

print("\n== C3d: sharp bounds wholly below -delta are barred by the rule ==")
# Y in [0,1]; 4% of treated outcomes missing not at random; worst-case (Manski) bounds.
n = 200_000
A = rng.binomial(1, 0.5, n)
Yc = np.clip(0.80 - 0.20 * A + rng.normal(0, 0.1, n), 0, 1)
miss = (A == 1) & (rng.random(n) < 0.04)
m1 = Yc[(A == 1) & ~miss].mean(); p_obs = 1 - miss[A == 1].mean()
EY1_lo = m1 * p_obs + 0 * (1 - p_obs); EY1_hi = m1 * p_obs + 1 * (1 - p_obs)
EY0 = Yc[A == 0].mean()
lo, hi = EY1_lo - EY0, EY1_hi - EY0
print(f"  worst-case bounds on Delta_O: [{lo:+.3f}, {hi:+.3f}]  (delta_N = {delta})")
print(f"  bounds exclude immaterial effects: {hi <= -delta}  -> Part II status: BOUNDED -> PAC barred")
print("  Fix: let S_NA=IDENTIFIED-ADVERSE be satisfied by sharp bounds or a CI wholly below -delta_N;")
print("  separate identification status from the sign/materiality verdict.")
