"""C4: Measurement-model and proposition-level counterexamples (P1-P4).
All synthetic; seeds fixed. Each block states the Part II claim it targets.
"""
import numpy as np
from scipy.special import logit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
import statsmodels.api as sm  # noqa
rng = np.random.default_rng(11)

print("== C4a: G measured as 'authority-weighted successful correction capacity' inherits J ==")
T = 24; cases = 400
G_true = np.full(T, 0.70)                          # institutional actionability constant
J_true = np.linspace(0.30, 0.08, T)                # share of cases with a substantive independent contribution
attempts = rng.binomial(cases, J_true)              # corrections can only be attempted on contributed cases
success = rng.binomial(attempts, G_true)
G_count = success / cases                           # count-based capacity measure
G_rate = success / np.maximum(attempts, 1)          # conditional success rate
se_rate = np.sqrt(G_rate * (1 - G_rate) / np.maximum(attempts, 1))
print(f"  true G: {G_true[0]:.2f} -> {G_true[-1]:.2f} (no change)")
print(f"  count-based G: {G_count[:3].mean():.3f} -> {G_count[-3:].mean():.3f}  (decline {1-G_count[-3:].mean()/G_count[:3].mean():.0%}: spurious D_G)")
print(f"  rate-based G:  {G_rate[:3].mean():.3f} -> {G_rate[-3:].mean():.3f}; SE {se_rate[:3].mean():.3f} -> {se_rate[-3:].mean():.3f}")
print("  -> D_J mechanically produces D_G under the paper's own example operationalization; the conjuncts are not")
print("     measurement-independent. Rate-based G avoids the bias but loses precision exactly when J collapses.")

print("\n== C4b: P2 'target conversion' confirmed by a ceiling effect with no legibility capture ==")
n = 20_000
quality = rng.normal(0, 1, n)                       # latent case-handling quality
N_out = 0.5 * quality + rng.normal(0, 1, n)         # protected outcome, process unchanged
p_pre = 1 / (1 + np.exp(-(1.0 + 1.2 * quality)))    # completion depends on quality
p_post = 1 / (1 + np.exp(-(4.0 + 1.2 * quality)))   # target lifts everyone toward completion; no gaming
P_pre = rng.binomial(1, p_pre); P_post = rng.binomial(1, p_post)
r_pre = np.corrcoef(P_pre, N_out)[0, 1]; r_post = np.corrcoef(P_post, N_out)[0, 1]
print(f"  completion rate {P_pre.mean():.2f} -> {P_post.mean():.2f}; mean N unchanged by construction")
print(f"  corr(P, N): {r_pre:.3f} -> {r_post:.3f}  ('reduced conditional relationship' predicted by P2)")
print("  -> range restriction alone reproduces the P2 signature. Rejection condition in Table 4 does not cover it.")
print("     Fix: estimate the relationship on a scale robust to marginal shifts (e.g., outcome among the")
print("     non-completed vs completed with IPW for selection), plus an unaffected-unit DiD on N itself.")

print("\n== C4c: P3 'voice-efficacy feedback' produced by a common latent shock (no feedback at all) ==")
units, T = 60, 40
coef, placebo = [], []
X_all, Y_all, Xp, Yp = [], [], [], []
for u in range(units):
    C = np.zeros(T); C[0] = rng.normal()
    for t in range(1, T):
        C[t] = 0.9 * C[t-1] - 0.03 + rng.normal(0, 0.3)     # channel quality, drifting down
    opp = rng.poisson(30, T)
    eff = 1 / (1 + np.exp(-(0.5 + 1.0 * C))) + rng.normal(0, 0.03, T)       # remedy efficacy
    rate = np.exp(-1.5 + 0.4 * C)                                            # recording/routing channel
    D = rng.poisson(opp * rate)                                              # dissent: no dependence on past efficacy
    for t in range(1, T - 1):
        X_all.append([eff[t], np.log(opp[t+1])]); Y_all.append(D[t+1])
        Xp.append([eff[t+1], np.log(opp[t])]); Yp.append(D[t])               # lead placebo: future efficacy -> past dissent
X_all, Y_all, Xp, Yp = map(np.asarray, (X_all, Y_all, Xp, Yp))
fit = sm.GLM(Y_all, sm.add_constant(X_all), family=sm.families.Poisson()).fit()
fitp = sm.GLM(Yp, sm.add_constant(Xp), family=sm.families.Poisson()).fit()
print(f"  efficacy_t -> dissent_t+1 (opportunity-adjusted): b={fit.params[1]:+.2f}, z={fit.tvalues[1]:.1f}")
print(f"  lead placebo efficacy_t+1 -> dissent_t:           b={fitp.params[1]:+.2f}, z={fitp.tvalues[1]:.1f}")
print("  -> P3 is 'supported' with zero true feedback. The lead placebo is equally strong and exposes the")
print("     confounding; P3 should preregister lead placebos and unit/period fixed effects or exogenous remedy shocks.")

print("\n== C4d: P1 verdict depends on the measurement scale ==")
P0, P1 = 0.97, 0.95; J0, J1 = 0.50, 0.47
raw = (J0 - J1) > (P0 - P1)
rel = (J0 - J1) / J0 > (P0 - P1) / P0
lg = (logit(J0) - logit(J1)) > (logit(P0) - logit(P1))
print(f"  raw points: J falls {J0-J1:.2f} vs P {P0-P1:.2f} -> P1 {'supported' if raw else 'rejected'}")
print(f"  relative:   J {100*(J0-J1)/J0:.1f}% vs P {100*(P0-P1)/P0:.1f}% -> P1 {'supported' if rel else 'rejected'}")
print(f"  logit:      J {logit(J0)-logit(J1):.3f} vs P {logit(P0)-logit(P1):.3f} -> P1 {'supported' if lg else 'rejected'}")
print("  -> 'larger decline in J than in P' compares quantities with no common unit. Fix: state P1 as a")
print("     difference in standardized effects on a preregistered scale, or as a sign prediction on each.")

print("\n== C4e: P4 'coupled-trace discrimination' passes without any coupling ==")
n = 6000
imp = rng.binomial(1, 0.2, n)
X = np.column_stack([imp * 0.8 + rng.normal(0, 1, n) for _ in range(3)])   # three independent noisy traces
Xtr, Xte, ytr, yte = train_test_split(X, imp, test_size=0.5, random_state=1)
singles = [roc_auc_score(yte, Xte[:, k]) for k in range(3)]
add = LogisticRegression().fit(Xtr, ytr)
Xi = lambda Z: np.column_stack([Z, Z[:, 0]*Z[:, 1], Z[:, 0]*Z[:, 2], Z[:, 1]*Z[:, 2], Z.prod(1)])
inter = LogisticRegression(max_iter=1000).fit(Xi(Xtr), ytr)
print(f"  held-out AUC single traces: {', '.join(f'{s:.3f}' for s in singles)}")
print(f"  additive combination: {roc_auc_score(yte, add.predict_proba(Xte)[:,1]):.3f} | with interactions: {roc_auc_score(yte, inter.predict_proba(Xi(Xte))[:,1]):.3f}")
print("  -> beating 'any raw indicator alone' is near-automatic for independent informative traces. The test of a")
print("     coupled (conjunctive) signal must be against the additive combination, not single indicators.")
