"""C6: follow-up checks on two caveats raised in an external review.
(a) P2: does the ceiling effect also attenuate the CONDITIONAL relation (N on P given case evidence)?
(b) P3: does the spurious feedback survive cluster-robust SEs and unit fixed effects?"""
import numpy as np, statsmodels.api as sm
rng = np.random.default_rng(11)
n = 20_000
quality = rng.normal(0, 1, n)
evidence = quality + rng.normal(0, 1, n)                     # observed case-evidence covariate
N_out = 0.5 * quality + rng.normal(0, 1, n)
P_pre = rng.binomial(1, 1/(1+np.exp(-(1.0+1.2*quality))))
P_post = rng.binomial(1, 1/(1+np.exp(-(4.0+1.2*quality))))
for lab, P in (("pre", P_pre), ("post", P_post)):
    f = sm.OLS(N_out, sm.add_constant(np.column_stack([P, evidence]))).fit()
    print(f"(a) {lab}: completion={P.mean():.2f}  coef(P | evidence)={f.params[1]:+.3f} (SE {f.bse[1]:.3f})")
units, T = 60, 40
rows = []
for u in range(units):
    C = np.zeros(T); C[0] = rng.normal()
    for t in range(1, T): C[t] = 0.9*C[t-1] - 0.03 + rng.normal(0, 0.3)
    opp = rng.poisson(30, T); eff = 1/(1+np.exp(-(0.5+C))) + rng.normal(0, .03, T)
    D = rng.poisson(opp*np.exp(-1.5+0.4*C))
    for t in range(1, T-1): rows.append((u, eff[t], np.log(opp[t+1]), D[t+1], eff[t+1], np.log(opp[t]), D[t]))
r = np.array(rows); g = r[:, 0].astype(int)
fe = np.eye(units)[g][:, 1:]
for lab, X, y in (("efficacy_t -> dissent_t+1", r[:, [1, 2]], r[:, 3]), ("lead placebo", r[:, [4, 5]], r[:, 6])):
    m1 = sm.GLM(y, sm.add_constant(X), family=sm.families.Poisson()).fit(cov_type="cluster", cov_kwds={"groups": g})
    m2 = sm.GLM(y, sm.add_constant(np.column_stack([X, fe])), family=sm.families.Poisson()).fit(cov_type="cluster", cov_kwds={"groups": g})
    print(f"(b) {lab}: pooled+cluster b={m1.params[1]:+.2f} z={m1.tvalues[1]:.1f} | unit FE+cluster b={m2.params[1]:+.2f} z={m2.tvalues[1]:.1f}")
