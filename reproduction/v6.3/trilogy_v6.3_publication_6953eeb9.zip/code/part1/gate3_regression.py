"""Compare guard semantics against Candidate 0.3; no field-data inference."""
from pathlib import Path
from itertools import product
import sys, types, json

def load(path,name):
    m=types.ModuleType(name);sys.modules[name]=m
    exec(compile(path.read_text(),str(path),'exec'),m.__dict__)
    return m
root=Path(__file__).resolve().parents[1]  # release/code
old=load(root/'historical_inputs/review_candidate_03/part1_v63_candidate_original.py','old03')
new=load(Path(__file__).with_name('part1_v63_candidate.py'),'new04')
counts={k:{'old_nonpass_g3_permitted':0,'new_nonpass_g3_permitted':0,'removed':0,'added':0,'old_permitted':0,'new_permitted':0} for k in [m.name for m in old.Mode]}
for m,g,h,bits in product(old.Mode,product(old.Gate,repeat=3),old.HardStatus,product(old.BITS,repeat=9)):
    before=old.can_execute(m,old.Facts(g,h,*bits))
    after=new.can_execute(new.Mode[m.name],new.Facts(tuple(new.Gate[x.name] for x in g),new.HardStatus[h.name],*bits))
    c=counts[m.name]; c['old_permitted']+=before;c['new_permitted']+=after
    if g[2] is not old.Gate.PASS:
        c['old_nonpass_g3_permitted']+=before;c['new_nonpass_g3_permitted']+=after
        assert not after
    else: assert before==after, 'unintended change at G3 PASS'
    c['removed']+=before and not after;c['added']+=after and not before
assert sum(c['removed'] for c in counts.values())==48
assert all(c['added']==0 for c in counts.values())
assert counts['RELEASE']['removed']==48
for g2 in (new.Gate.REVIEW,new.Gate.BLOCK):
    assert new.can_execute(new.Mode.RELEASE,new.Facts((new.Gate.PASS,g2,new.Gate.PASS),new.HardStatus.CLEAR,*([True]*9)))
print(json.dumps({'comparison':counts,'g2_review_and_block_positive_witnesses':True,'scope':'finite static guard only; no temporal integration'},indent=2))
