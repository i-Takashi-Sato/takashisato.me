"""Requirement probes and actual source mutants for candidate 0.4.
Not an independent author or full domain safety proof. Each mutant changes source
and is run against the same separately stated requirement probes. No arbitrary
output substitution counts are reported as mutation coverage.
"""
from collections import deque
from dataclasses import replace
from itertools import product
from pathlib import Path
import importlib.util, types, sys, json
SOURCE=Path(__file__).with_name('part1_v63_candidate.py').read_text()

def load(source,name):
    m=types.ModuleType(name);sys.modules[name]=m
    exec(compile(source,name,'exec'),m.__dict__)
    return m

def route_checks(P):
    G=P.Gate;R=P.Route;D=P.Disposition;C=P.Command
    for g,r,c,b,f in product(product(G,repeat=3),*[P.BITS]*4):
        actual=P.triage(g,r,c,b,f)
        assert P.route_partition(g,r,c,b,f)[actual], 'route encoding disagreement'
        if actual is R.FALLBACK: assert b and f, 'fallback requires readiness and authorization'
        if g==P.ALLPASS: assert actual is R.ELIGIBLE, 'all pass priority'
        if g!=P.ALLPASS and r and c: assert actual is (R.HOLD if G.UNKNOWN in g else R.REVIEW), 'review and unknown priority'
        if g!=P.ALLPASS and not(r and c) and b and f: assert actual is R.FALLBACK, 'ready fallback selected'
    expected={C.RELEASE:D.RELEASE,C.MODIFY:D.MODIFY,C.REJECT:D.REJECT,C.DEFER:D.DEFER}
    for q,b,f in product(C,P.BITS,P.BITS):
        assert P.disposition(R.REVIEW,None,b,f) is D.PENDING,'absent instruction'
        assert P.disposition(R.REVIEW,P.Instruction(q,False),b,f) is D.PENDING,'invalid instruction'
        result=P.disposition(R.REVIEW,P.Instruction(q,True),b,f)
        assert result is (expected[q] if q in expected else D.FALLBACK if b and f else D.UNRESOLVED),'command fidelity'

def guard_checks(P,exhaustive=False):
    # All external predicates favorable; change only the tested dimension.
    # Include inconsistent combinations to test fail-closed behavior.
    G=P.Gate; H=P.HardStatus; M=P.Mode
    valid=P.Facts(P.ALLPASS,H.CLEAR,*([True]*9)); hard_count=0; temporal_count=0; union_count=0
    for mode in M:
        assert P.can_execute(mode,valid),'positive execution witness'
        for h in (H.PROHIBITED,H.UNVERIFIED,H.CORRECTABLE):
            assert not P.can_execute(mode,replace(valid,hard_status=h)),'nonclear hard assessment'
        for g1 in (G.BLOCK,G.UNKNOWN,G.REVIEW):
            assert not P.can_execute(mode,replace(valid,gates=(g1,G.PASS,G.PASS))),'G1 not PASS'
        for g3 in (G.BLOCK,G.UNKNOWN,G.REVIEW):
            assert not P.can_execute(mode,replace(valid,gates=(G.PASS,G.PASS,g3))), 'G3 not PASS'
        for g2 in (G.BLOCK,G.REVIEW):
            x=replace(valid,gates=(G.PASS,g2,G.PASS))
            assert P.can_execute(mode,x)==(mode is M.RELEASE), 'G2 reviewable objection semantics'
        for field in ('fresh','domain_authorized','record_ready'):
            assert not P.can_execute(mode,replace(valid,**{field:False})),field
        if mode in (M.RELEASE,M.MODIFIED,M.FALLBACK_2):
            for field in ('instruction_current','instruction_matches'):
                assert not P.can_execute(mode,replace(valid,**{field:False})),field
        if mode in (M.FALLBACK_1,M.FALLBACK_2):
            for field in ('fallback_authorized','fallback_ready','alternative_adequate'):
                assert not P.can_execute(mode,replace(valid,**{field:False})),field
    if exhaustive:
        for mode,g,h,bits in product(M,product(G,repeat=3),H,product(P.BITS,repeat=9)):
            hard_bad=h is not H.CLEAR or g[0] is not G.PASS
            time_bad=g[2] is not G.PASS
            hard_count+=hard_bad; temporal_count+=time_bad; union_count+=hard_bad or time_bad
            if hard_bad or time_bad:
                assert not P.can_execute(mode,P.Facts(g,h,*bits)), 'hard/temporal constraint counterexample'
    return {'hard_denial':hard_count,'g3_denial':temporal_count,'union_denial':union_count}

def temporal_checks(P):
    # History monitor: DEFER remains pending until explicit authorized resume
    # or authorized reassignment after escalation. Escalation alone is not release.
    initial=P.State(); start=(initial,False); seen={start}; queue=deque([(start,())]); edges=0
    witnesses={}; commits={'execute','start_fallback'}
    while queue:
        (s,pending),path=queue.popleft()
        for e,t in P.transitions(s):
            edges+=1; trace=path+(e,)
            if s.phase is P.Phase.DEFER and t.phase is not P.Phase.DEFER:
                assert e in ('authorized_resume','escalate'), 'unauthorized DEFER exit: '+' -> '.join(trace)
            if e=='authorized_resume':
                assert s.phase is P.Phase.DEFER and s.resume_ready and s.authority and s.record and not s.due, 'invalid resume'
            if e=='authorized_reassignment':
                assert s.phase is P.Phase.ESCALATED and s.authority and s.record, 'invalid reassignment'
            if e in commits:
                assert not pending,'DEFER bypass: '+' -> '.join(trace)
                assert s.hard is P.HardStatus.CLEAR and s.fresh and s.authority and s.record and s.bound and not s.due,'stale/unauthorized commit'
            nd=True if e=='signed_defer' else False if e in ('authorized_resume','authorized_reassignment') else pending
            if e in ('authorized_resume','authorized_reassignment','signed_defer','record_fallback_completion','record_failed_fallback_and_escalate'):witnesses.setdefault(e,list(trace))
            item=(t,nd)
            if item not in seen:seen.add(item);queue.append((item,trace))
    assert all(x in witnesses for x in ('signed_defer','authorized_resume','authorized_reassignment','record_fallback_completion','record_failed_fallback_and_escalate')), 'missing positive transition witness'
    return {'product_states':len(seen),'labeled_edges_including_self_loops':edges,'witnesses':witnesses}

def check(P,full=False):
    route_checks(P); hard=guard_checks(P,full); temporal=temporal_checks(P)
    return {'explicit_denial_configurations':hard,'temporal_history_monitor':temporal}

# Each is an executable alteration of the candidate source, not an arithmetic
# count of possible output values. Shared-spec mutant changes both encodings.
mutants={
 'hold_review_swap': [('return Route.HOLD if Gate.UNKNOWN in g else Route.REVIEW','return Route.REVIEW if Gate.UNKNOWN in g else Route.HOLD')],
 'shared_fallback_readiness_omitted': [('if b and f: return Route.FALLBACK','if b: return Route.FALLBACK'),('bf=b and f','bf=b')],
 'release_modify_swap': [('Command.RELEASE:Disposition.RELEASE,Command.MODIFY:Disposition.MODIFY','Command.RELEASE:Disposition.MODIFY,Command.MODIFY:Disposition.RELEASE')],
 'hard_type_omitted': [('x.hard_status is not HardStatus.CLEAR or x.gates[0] is not Gate.PASS','x.gates[0] is not Gate.PASS')],
 'g1_pass_omitted': [('x.hard_status is not HardStatus.CLEAR or x.gates[0] is not Gate.PASS','x.hard_status is not HardStatus.CLEAR')],
 'g3_pass_omitted': [('    if x.gates[2] is not Gate.PASS: return False\n','')],
 'shared_g3_pass_omitted': [('    if x.gates[2] is not Gate.PASS: return False\n',''),("    if x.gates[2] is not Gate.PASS: violations.append('temporal_diagnostic_not_pass')\n",'')],
 'freshness_omitted': [('if not (x.fresh and x.domain_authorized and x.record_ready)','if not (x.domain_authorized and x.record_ready)')],
 'defer_reroute_bypass': [('Phase.FALLBACK_ACTIVE,Phase.DEFER,Phase.ESCALATED','Phase.FALLBACK_ACTIVE,Phase.ESCALATED')],
 'resume_condition_omitted': [('if s.resume_ready and s.authority and s.record and not s.due:','if s.authority and s.record and not s.due:')],
 'temporal_hard_guard_omitted': [('and s.hard is HardStatus.CLEAR and s.authority','and s.authority')],
 'fallback_readiness_omitted_at_commit': [('and x.fallback_ready and x.alternative_adequate','and x.alternative_adequate')],
}
if __name__=='__main__':
    baseline=check(load(SOURCE,'baseline'),True); results={}
    for i,(name,changes) in enumerate(mutants.items()):
        src=SOURCE
        for old,new in changes:
            assert old in src,name
            src=src.replace(old,new)
        try:check(load(src,f'mutant_{i}'))
        except AssertionError as e:results[name]={'detected':True,'witness':str(e)}
        else:results[name]={'detected':False}
    print(json.dumps({'baseline':baseline,'targeted_mutants':results,'detected':sum(x['detected'] for x in results.values()),'tested':len(results),'scope':'selected requirement probes and finite history monitor; common specification errors can remain'},indent=2))
    assert all(x['detected'] for x in results.values())
