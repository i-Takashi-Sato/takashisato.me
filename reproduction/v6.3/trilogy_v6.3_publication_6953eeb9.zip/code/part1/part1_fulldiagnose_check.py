"""Evidence for DECISIONS D4: the default single-component diagnosis step of the integrated
model reaches the same abstract state set, the same commit set and the same safety/progress
verdicts as full (all-component) re-diagnosis.

Usage: python3 -I part1_fulldiagnose_check.py > part1_fulldiagnose_check.json
Runtime: several minutes (two explorations, the second with the larger branching factor)."""
import importlib.util, json, sys
from pathlib import Path

spec = importlib.util.spec_from_file_location('IM', Path(__file__).with_name('part1_integrated_model.py'))
IM = importlib.util.module_from_spec(spec); sys.modules['IM'] = IM; spec.loader.exec_module(IM)

def run(full):
    IM.FULL_DIAGNOSE = full
    seen, edges, ev, viol, preds = IM.explore()
    commits = set(IM.explore.commits)
    term = [s for s in seen if s.phase in IM.TERMINAL]
    # backward reachability to terminal states (EF progress) and deadlocks
    reach = set(term); stack = list(term)
    while stack:
        t = stack.pop()
        for p in preds.get(t, ()):
            if p not in reach:
                reach.add(p); stack.append(p)
    stuck = sum(1 for s in seen if s not in reach)
    nonterm_no_succ = sum(1 for s in seen if s.phase not in IM.TERMINAL and not any(True for _ in IM.transitions(s, IM.C, frozenset())))
    return {'states': len(seen), 'transitions': edges, 'violations': len(viol), 'states_without_path_to_terminal': stuck,
            'deadlocked_nonterminal_states': nonterm_no_succ, 'commit_edges': len(commits)}, set(seen), commits

single, s1, c1 = run(False)
full, s2, c2 = run(True)
out = {'single_component_diagnosis': single, 'full_rediagnosis': full,
       'same_state_set': s1 == s2, 'same_commit_set': c1 == c2,
       'note': 'transition counts differ by construction (full re-diagnosis adds edges between the same states); '
               'D4 relies on identical state sets, commit sets and verdicts, not on identical transition relations'}
print(json.dumps(out, indent=2))
assert out['same_state_set'] and out['same_commit_set'] and full['violations'] == 0 and full['states_without_path_to_terminal'] == 0
