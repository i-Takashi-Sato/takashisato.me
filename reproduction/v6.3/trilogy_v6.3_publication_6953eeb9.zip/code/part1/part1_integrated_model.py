"""Part I v6.3 — integrated static/temporal protocol model.

The commit transitions of the temporal model are guarded by the *same* static
functions used in the finite contract (`triage`, `disposition`, `can_execute`
from part1_v63_candidate.py). Safety properties are then checked by separately
written requirement predicates that do not call `can_execute`.

Sound finite abstraction (checked by lemmas L1-L3 before exploration):
  L1  REVIEW and BLOCK are interchangeable for triage and can_execute
      -> each gate is abstracted to {PASS, NONPASS(=BLOCK), UNKNOWN}.
  L2  PROHIBITED, UNVERIFIED and CORRECTABLE are interchangeable for can_execute
      -> hard assessment is abstracted to {CLEAR, NOT_CLEAR(=PROHIBITED)}.
  L3  triage depends on r,c only through r AND c, and on b,f only through b AND f
      -> availability is abstracted to R=r&c and B=b&f.
Modelling decisions (documented in docs/DECISIONS.md):
  * A changed candidate (MODIFY, fallback alternative) is unassessed until a new
    diagnosis: its gates are reset to UNKNOWN and its snapshot to stale.
  * A RELEASE instruction is bound to the snapshot it was signed against; any
    later snapshot change requires a new review signature. MODIFY / fallback
    instructions are bound to the changed candidate and the issuing authority.
  * alternative_adequate is represented by the alternative's own diagnosis
    (all-PASS, CLEAR); `resolved` by a current, bound RELEASE signature.
Standard library only. Usage:  python -I code/part1_integrated_model.py [--mutant NAME]
"""
from collections import deque, Counter
from dataclasses import dataclass, replace
from itertools import product
from pathlib import Path
import json, sys, types

def load_candidate(src=None, base=None):
    src = src or Path(__file__).with_name('part1_v63_candidate.py').read_text()
    m = types.ModuleType('cand'); exec(compile(src, 'part1_v63_candidate.py', 'exec'), m.__dict__)
    if base is not None:   # mutant: reuse the baseline types so states are comparable
        for k in ('Gate', 'Route', 'Command', 'Disposition', 'HardStatus', 'Mode', 'Facts', 'Instruction', 'ALLPASS'):
            setattr(m, k, getattr(base, k))
    return m

C = load_candidate()
G, H, M, R_ = C.Gate, C.HardStatus, C.Mode, C.Route
BITS = (False, True)

# ---------------------------------------------------------------- lemmas
def lemmas(c=C):
    swap = {c.Gate.REVIEW: c.Gate.BLOCK}
    canon = lambda g: tuple(swap.get(x, x) for x in g)
    n = 0
    for g, (r, cc, b, f) in product(product(c.Gate, repeat=3), product(BITS, repeat=4)):
        assert c.triage(g, r, cc, b, f) is c.triage(canon(g), r, cc, b, f), 'L1 triage'
        assert c.triage(g, r, cc, b, f) is c.triage(g, r and cc, r and cc, b and f, b and f), 'L3'
        n += 1
    for mode, g, h, bits in product(c.Mode, product(c.Gate, repeat=3), c.HardStatus, product(BITS, repeat=9)):
        x = c.can_execute(mode, c.Facts(g, h, *bits))
        assert x == c.can_execute(mode, c.Facts(canon(g), h, *bits)), 'L1 guard'
        if h is not c.HardStatus.CLEAR:
            assert x == c.can_execute(mode, c.Facts(g, c.HardStatus.PROHIBITED, *bits)), 'L2'
        n += 1
    return n

GATE_CLASSES = (G.PASS, G.BLOCK, G.UNKNOWN)
HARD_CLASSES = (H.CLEAR, H.PROHIBITED)
ALLPASS = C.ALLPASS
UNASSESSED = (G.UNKNOWN,) * 3

PH = ('ASSESS', 'HOLD', 'REVIEW', 'ELIGIBLE', 'RECHECK', 'FALLBACK', 'FALLBACK_ACTIVE',
      'DEFER', 'ESCALATED', 'UNRESOLVED', 'EXECUTED', 'REJECTED', 'FALLBACK_DONE')
TERMINAL = {'EXECUTED', 'REJECTED', 'FALLBACK_DONE'}
FULL_DIAGNOSE = '--full-diagnose' in sys.argv

@dataclass(frozen=True)
class S:
    phase: str = 'ASSESS'
    gates: tuple = UNASSESSED
    hard: object = H.PROHIBITED       # not yet established as CLEAR
    fresh: bool = False
    R: bool = True                    # review authority and capacity
    B: bool = False                   # fallback authorization and readiness
    auth: bool = True                 # executor authority / standing readiness
    record: bool = True               # durable record service ready
    due: bool = False
    bound: bool = False               # unused execution binding to current snapshot
    mode: object = M.DIRECT           # provenance of the candidate for commitment
    instr: str = 'NONE'               # NONE RELEASE MODIFY REJECT DEFER FALLBACK
    instr_ok: bool = False            # instruction current, in scope, bound to candidate
    defer_pending: bool = False
    resume_ready: bool = False

def facts(s, c=C):
    match = {M.RELEASE: 'RELEASE', M.MODIFIED: 'MODIFY', M.FALLBACK_2: 'FALLBACK'}.get(s.mode)
    instr_ok = s.instr_ok and (match is None or s.instr == match)
    return c.Facts(s.gates, s.hard, s.fresh, s.auth, s.record,
                   s.mode is M.RELEASE and instr_ok,      # resolved by a current signed RELEASE
                   instr_ok, instr_ok, s.B, s.B, True)

def transitions(s, c=C, mut=frozenset()):
    if s.phase in TERMINAL:
        return
    snap = dict(bound=False)
    # ---------------- environment
    rel = {} if (s.instr != 'RELEASE' or 'release_survives_rediagnosis' in mut) else {'instr_ok': False}
    if FULL_DIAGNOSE:
        for g in product(GATE_CLASSES, repeat=3):
            for h in HARD_CLASSES:
                yield 'diagnose', replace(s, gates=g, hard=h, fresh=True, **snap, **rel)
    else:
        yield 'diagnose', replace(s, fresh=True, **snap, **rel)                 # re-assessment, unchanged result
        for i in range(3):
            for v in GATE_CLASSES:
                if v is not s.gates[i]:
                    g = s.gates[:i] + (v,) + s.gates[i + 1:]
                    yield 'diagnose', replace(s, gates=g, fresh=True, **snap, **rel)
        yield 'diagnose', replace(s, hard=HARD_CLASSES[1] if s.hard is H.CLEAR else H.CLEAR, fresh=True, **snap, **rel)
    if s.fresh:
        yield 'snapshot_stale', replace(s, fresh=False, **snap,
                                        **({} if s.instr != 'RELEASE' else {'instr_ok': False}))
    yield 'toggle_auth', replace(s, auth=not s.auth, instr_ok=False, **snap)
    yield 'toggle_record', replace(s, record=not s.record, **snap)
    yield 'toggle_R', replace(s, R=not s.R)
    yield 'toggle_B', replace(s, B=not s.B, **snap)
    if not s.due:
        yield 'deadline', replace(s, due=True)
    if s.phase == 'DEFER':
        yield 'toggle_resume_condition', replace(s, resume_ready=not s.resume_ready)
    # ---------------- Stage 1 routing (institutional)
    reroutable = {'ASSESS', 'HOLD', 'UNRESOLVED'} | ({'ELIGIBLE'} if not s.bound else set())
    if 'reroute_from_defer' in mut:
        reroutable |= {'DEFER'}
    if s.phase in reroutable and s.fresh and not s.due and (not s.defer_pending or 'reroute_from_defer' in mut):
        route = c.triage(s.gates, s.R, s.R, s.B, s.B)
        base = dict(instr='NONE', instr_ok=False)
        if route is R_.ELIGIBLE:
            yield 'route_eligible', replace(s, phase='ELIGIBLE', mode=M.DIRECT, bound=True, **base)
        elif route is R_.HOLD:
            yield 'route_hold', replace(s, phase='HOLD', bound=False, **base)
        elif route is R_.REVIEW:
            yield 'route_review', replace(s, phase='REVIEW', bound=False, **base)
        elif route is R_.FALLBACK:
            yield 'route_fallback', replace(s, phase='FALLBACK', mode=M.FALLBACK_1, gates=UNASSESSED,
                                            hard=H.PROHIBITED, fresh=False, bound=False, **base)
        else:
            yield 'route_unresolved', replace(s, phase='UNRESOLVED', bound=False, **base)
    # ---------------- Stage 2 signed dispositions (only inside a currently valid review route)
    review_valid = s.fresh and c.triage(s.gates, s.R, s.R, s.B, s.B) is R_.REVIEW
    if 'sign_without_valid_review' in mut:
        review_valid = s.fresh
    if s.phase == 'REVIEW' and s.auth and s.record and not s.due and review_valid:
        d = lambda q: c.disposition(R_.REVIEW, c.Instruction(q, True), s.B, s.B)
        D = c.Disposition
        assert d(c.Command.RELEASE) is D.RELEASE
        yield 'sign_release', replace(s, phase='ELIGIBLE', mode=M.RELEASE, instr='RELEASE', instr_ok=True, bound=True)
        yield 'sign_modify', replace(s, phase='RECHECK', mode=M.MODIFIED, instr='MODIFY', instr_ok=True,
                                     gates=UNASSESSED, hard=H.PROHIBITED, fresh=False, bound=False)
        yield 'sign_reject', replace(s, phase='REJECTED', instr='REJECT', instr_ok=True)
        yield 'sign_defer', replace(s, phase='DEFER', instr='DEFER', instr_ok=True, defer_pending=True,
                                    resume_ready=False, bound=False)
        if d(c.Command.FALLBACK) is D.FALLBACK:
            yield 'sign_fallback', replace(s, phase='FALLBACK', mode=M.FALLBACK_2, instr='FALLBACK', instr_ok=True,
                                           gates=UNASSESSED, hard=H.PROHIBITED, fresh=False, bound=False)
        else:
            yield 'sign_fallback_unavailable', replace(s, phase='UNRESOLVED', instr='NONE', instr_ok=False)
    # ---------------- binding of a changed candidate after its own diagnosis
    if s.phase in ('RECHECK', 'FALLBACK') and s.fresh and not s.bound and not s.due:
        if s.gates == ALLPASS and s.hard is H.CLEAR:
            yield 'bind_changed_candidate', replace(s, phase='ELIGIBLE' if s.phase == 'RECHECK' else 'FALLBACK', bound=True)
        elif s.phase == 'RECHECK':
            yield 'return_for_new_adjudication', replace(s, phase='ASSESS', instr='NONE', instr_ok=False, mode=M.DIRECT)
    # ---------------- commitment (guarded by the static guard)
    commit_ok = s.bound and not s.due and not s.defer_pending
    if 'commit_ignores_defer' in mut:
        commit_ok = s.bound and not s.due
    if 'commit_ignores_binding' in mut:
        commit_ok = not s.due and not s.defer_pending
    guard = c.can_execute(s.mode, facts(s, c))
    if s.phase == 'ELIGIBLE' and commit_ok and guard:
        yield 'execute', replace(s, phase='EXECUTED')
    if s.phase == 'FALLBACK' and commit_ok and guard and s.mode in (M.FALLBACK_1, M.FALLBACK_2):
        yield 'start_fallback', replace(s, phase='FALLBACK_ACTIVE')
    if s.phase == 'FALLBACK_ACTIVE':
        if s.record:
            yield 'record_fallback_completion', replace(s, phase='FALLBACK_DONE')
        if s.due:
            yield 'record_failed_fallback_and_escalate', replace(s, phase='ESCALATED', bound=False)
    # ---------------- waiting, escalation, re-entry
    if s.due and s.phase not in ('ESCALATED', 'FALLBACK_ACTIVE'):
        yield 'escalate', replace(s, phase='ESCALATED', bound=False)
    if s.phase == 'ESCALATED' and s.auth and s.record:
        yield 'authorized_reassignment', replace(s, phase='ASSESS', due=False, defer_pending=False,
                                                 resume_ready=False, instr='NONE', instr_ok=False,
                                                 mode=M.DIRECT, bound=False)
    if s.phase == 'DEFER' and s.auth and s.record and not s.due and (s.resume_ready or 'resume_without_condition' in mut):
        yield 'authorized_resume', replace(s, phase='ASSESS', defer_pending=False, resume_ready=False,
                                           instr='NONE', instr_ok=False, mode=M.DIRECT, bound=False)

# ---------------------------------------------------------------- independent requirement predicates
def commit_requirements(s):
    """Written from the specification text; does not call can_execute."""
    errs = []
    if s.hard is not H.CLEAR: errs.append('hard admissibility not CLEAR')
    if s.gates[0] is not G.PASS: errs.append('Gate 1 not PASS')
    if s.gates[2] is not G.PASS: errs.append('Gate 3 not PASS')
    if G.UNKNOWN in s.gates: errs.append('UNKNOWN evidence')
    if not (s.fresh and s.bound): errs.append('no current bound snapshot')
    if not (s.auth and s.record): errs.append('executor authority or record missing')
    if s.due: errs.append('deadline elapsed')
    if s.defer_pending: errs.append('outstanding DEFER')
    need_allpass = s.mode in (M.DIRECT, M.MODIFIED, M.FALLBACK_1, M.FALLBACK_2)
    if need_allpass and s.gates != ALLPASS: errs.append('changed/direct candidate not all-PASS')
    need = {M.RELEASE: 'RELEASE', M.MODIFIED: 'MODIFY', M.FALLBACK_2: 'FALLBACK'}.get(s.mode)
    if need and not (s.instr == need and s.instr_ok): errs.append('missing current matching signed instruction')
    if s.mode in (M.FALLBACK_1, M.FALLBACK_2) and not s.B: errs.append('fallback not authorized/ready')
    return errs

def explore(c=C, mut=frozenset(), limit=None):
    init = S()
    seen = {init: None}; q = deque([init]); edges = 0; ev = Counter(); violations = []; commits = set()
    preds = {}
    while q:
        s = q.popleft()
        for e, t in transitions(s, c, mut):
            edges += 1; ev[e] += 1
            preds.setdefault(t, set()).add(s)
            # ---- safety checks (independent of the guard implementation)
            if e in ('execute', 'start_fallback'):
                commits.add((e, s))
                err = commit_requirements(s)
                if err: violations.append((e, err, s))
            if t.phase == 'REJECTED' and e != 'sign_reject': violations.append((e, ['REJECTED without signature'], s))
            if e.startswith('sign_') and not (s.phase == 'REVIEW' and s.fresh and
                                              c.triage(s.gates, s.R, s.R, s.B, s.B) is R_.REVIEW):
                violations.append((e, ['signature outside a valid review route'], s))
            if s.phase == 'DEFER' and t.phase not in ('DEFER',) and e not in ('authorized_resume', 'escalate'):
                violations.append((e, ['unauthorized DEFER exit'], s))
            if e == 'authorized_resume' and not s.resume_ready:
                violations.append((e, ['resume without re-entry condition'], s))
            if e == 'deadline' and t.phase in TERMINAL:
                violations.append((e, ['expiry produced a terminal act'], s))
            if t not in seen:
                seen[t] = None; q.append(t)
        if limit and len(seen) > limit:
            raise RuntimeError('state limit')
    explore.commits = commits
    return seen, edges, ev, violations, preds

def liveness(seen, preds):
    """Conditional progress: from every reachable state some terminal state is reachable (EF terminal),
    given cooperative environment moves. Not AF: an adversarial environment can block forever."""
    target = [s for s in seen if s.phase in TERMINAL]
    can = set(target); q = deque(target)
    while q:
        t = q.popleft()
        for p in preds.get(t, ()):
            if p not in can:
                can.add(p); q.append(p)
    stuck = [s for s in seen if s not in can]
    deadlocks = [s for s in seen if s.phase not in TERMINAL and not any(True for _ in transitions(s))]
    return len(stuck), len(deadlocks)

MUTANTS = {
    'release_survives_rediagnosis': 'RELEASE signature stays valid after the snapshot changes',
    'reroute_from_defer': 'ordinary re-routing allowed out of DEFER',
    'sign_without_valid_review': 'signature accepted when the case is no longer a valid review route',
    'commit_ignores_defer': 'commit guard ignores an outstanding DEFER',
    'commit_ignores_binding': 'commit without a current execution binding',
    'resume_without_condition': 'resume without re-entry condition',
}
SOURCE_MUTANTS = {  # applied to the static guard source, then integrated
    'guard_drops_gate3': ('    if x.gates[2] is not Gate.PASS: return False\n', ''),
    'guard_drops_hard_type': ('x.hard_status is not HardStatus.CLEAR or ', ''),
    'guard_drops_fallback_ready': ('and x.fallback_ready and x.alternative_adequate', 'and x.alternative_adequate'),
}

def main():
    out = {'lemma_cases_checked': lemmas()}
    seen, edges, ev, viol, preds = explore()
    stuck, dead = liveness(seen, preds)
    out['baseline'] = {'reachable_states': len(seen), 'transitions': edges,
                       'commit_edges': ev['execute'] + ev['start_fallback'],
                       'terminal_states': Counter(s.phase for s in seen if s.phase in TERMINAL),
                       'safety_violations': len(viol),
                       'states_without_path_to_terminal': stuck, 'deadlocked_nonterminal_states': dead,
                       'events': dict(sorted(ev.items()))}
    assert not viol and stuck == 0 and dead == 0
    base_commits = set(explore.commits); base_n = len(seen)
    src = Path(__file__).with_name('part1_v63_candidate.py').read_text()
    res = {}
    def classify(v, n):
        if v: return {'result': 'detected', 'witness': v[0][1]}
        same = explore.commits == base_commits
        return {'result': 'equivalent (identical reachable commit set)' if same else 'SURVIVED',
                'reachable_states': n}
    for name in MUTANTS:
        sn, _, _, v, _ = explore(mut=frozenset({name}))
        res[name] = classify(v, len(sn))
    for name, (old, new) in SOURCE_MUTANTS.items():
        assert old in src, name
        cm = load_candidate(src.replace(old, new), base=C)
        sn, _, _, v, _ = explore(c=cm)
        res[name] = classify(v, len(sn))
    out['mutants'] = res
    out['mutant_summary'] = dict(Counter(r['result'].split(' ')[0] for r in res.values()))
    out['scope'] = ('integrated finite abstraction under lemmas L1-L3; truthful external predicates; '
                    'EF-progress only; no real clocks, identities, payloads or records infrastructure')
    print(json.dumps(out, indent=2, default=str))
    assert all(r['result'] != 'SURVIVED' for r in res.values())

if __name__ == '__main__':
    main()
