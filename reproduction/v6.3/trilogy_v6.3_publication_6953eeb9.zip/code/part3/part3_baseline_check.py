"""Re-explore the supplied Claude models, not an independent reimplementation.
Usage: python -I part3_baseline_check.py PATH_TO_EXTRACTED_pkg_v3
"""
import json, sys, hashlib
from pathlib import Path
p=Path(sys.argv[1]); sys.path.insert(0,str(p/'audit'))
import audit_core as C
import exp_models as E
src=(p/'historical/formal_protocol_checks.py').read_text()
assert hashlib.sha256((p/'historical/formal_protocol_checks.py').read_bytes()).hexdigest()=='ca82fc325fce1ddac2dcbcc407fe3eaa96892914855decc961ab220caebc0c7d'
expected=json.loads((p/'results/core.json').read_text())['models']
result={}
for kind in ('M0','B3_S1'):
    m=E.build(kind,src,'v63'); r=C.explore(m); assert not r.truncated
    succ,pred=C.build_adj(r); d=[s.__dict__ for s in r.states]
    closed=[i for i,s in enumerate(d) if s['closed']]; can=C.back_reach(pred,closed)
    fair,stats=C.strong_fair_subgraphs(r,succ,d)
    x=dict(states=len(d),transitions=r.n_transitions,violating_states=r.violating_states,violating_edges=r.violating_edges,closed_states=len(closed),closure_unreachable_states=len(d)-sum(can),P1_authorized_unclosed_but_closure_unreachable=sum(not can[i] and s['retirement_decision_authorized'] and not s['closed'] for i,s in enumerate(d)),defect_terminal_states=sum(not succ[i] and m.meta['classify_terminal'](s)=='DEFECT_terminal' for i,s in enumerate(d)),fair_closure_avoiding_subgraphs=len(fair))
    assert all(x[k]==expected[kind][k] for k in x if k!='fair_closure_avoiding_subgraphs')
    assert len(fair)==expected[kind]['fairness']['exact_strong_fairness_subgraph_search']['fair_closure_avoiding_subgraphs']
    result[kind]=x
print(json.dumps(result,indent=2))
