"""Resumable re-execution of the PE-R1 (audit key B3_S1) mutation suite.

Reuses the audit implementation (audit_part3_checker_v2.mutate) job by job, writing each
result to a JSON-lines checkpoint so the 134-variant suite can be run in time-bounded
slices. When all jobs are present it writes a summary identical in structure to
`mutate` and compares it with the recorded audit output.

Usage:
  python3 -I part3_mutation_rerun.py PKG_DIR OUT_DIR [--budget SECONDS]
"""
import sys, os, json, time, importlib.util, multiprocessing as mp
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

pkg, outdir = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
budget = float(sys.argv[sys.argv.index('--budget') + 1]) if '--budget' in sys.argv else 500.0
sys.path.insert(0, str(pkg / 'audit'))
spec = importlib.util.spec_from_file_location('A', pkg / 'audit' / 'audit_part3_checker_v2.py')
A = importlib.util.module_from_spec(spec); sys.modules['A'] = A; spec.loader.exec_module(A)
C, E = A.C, A.E
KIND, CAP = 'B3_S1', 250000
src = (pkg / 'historical' / 'formal_protocol_checks.py').read_text(encoding='utf-8')
outdir.mkdir(parents=True, exist_ok=True)
ckpt = outdir / 'mutation_B3_S1_checkpoint.jsonl'

t0 = time.time()
H = C.load_module(src, 'hist_for_mut')
funcs = {tr.__name__ for _, tr in H.EXIT_TRANSITIONS}
M = E.build(KIND, src, 'base')
R0 = C.explore(M, None, cap=CAP)
assert not R0.truncated
D0 = [s.__dict__ for s in R0.states]
succ, pred = C.build_adj(R0)
can0 = C.back_reach(pred, [i for i in range(len(D0)) if D0[i]['closed']])
base_p1 = sum(1 for i in range(len(D0)) if D0[i]['retirement_decision_authorized'] and not D0[i]['closed'] and not can0[i])
A._G.update(kind=KIND, cap=CAP, base_edges=C.labeled_edge_set(R0), base_keys=set(R0.keys))
jobs = [(f'hist:{m}', 'hist_named', src, m) for m in H.CRITICAL_GUARD_MUTATIONS]
jobs += [(f'model:{m}', 'model_named', src, m) for m in E.named_mutants_for(KIND)]
am = C.ast_mutants(src, funcs)
jobs += [(lab, 'ast', s, None) for lab, s in am]
done = {}
if ckpt.exists():
    for line in ckpt.read_text().splitlines():
        r = json.loads(line); done[r['label']] = r
todo = [j for j in jobs if j[0] not in done]
print(f'base states {len(D0)}; jobs {len(jobs)}; done {len(done)}; todo {len(todo)}', flush=True)

ctx = mp.get_context('fork')
with ProcessPoolExecutor(max_workers=os.cpu_count() or 2, mp_context=ctx) as ex:
    futs = {}
    it = iter(todo)
    for _ in range(os.cpu_count() or 2):
        j = next(it, None)
        if j: futs[ex.submit(A._job, j)] = j
    while futs:
        from concurrent.futures import wait, FIRST_COMPLETED
        fin, _ = wait(futs, return_when=FIRST_COMPLETED)
        for f in fin:
            j = futs.pop(f); r = f.result()
            with ckpt.open('a') as fh:
                fh.write(json.dumps(r, default=str) + '\n')
            done[r['label']] = r
            print('done', r['label'], flush=True)
            if time.time() - t0 < budget:
                nj = next(it, None)
                if nj: futs[ex.submit(A._job, nj)] = nj

if len(done) < len(jobs):
    print(f'PARTIAL {len(done)}/{len(jobs)}'); sys.exit(3)

results = [done[j[0]] for j in jobs]
for r in results:
    r['classification'] = A.classify(r, base_p1)
summ = {}
for g in ('hist_named', 'model_named', 'ast'):
    rs = [r for r in results if r['group'] == g]
    summ[g] = {'total': len(rs), **dict(Counter(r['classification'] for r in rs))}
total = {'total': len(results), **dict(Counter(r['classification'] for r in results))}
survivors = sorted(r['label'] for r in results if r['classification'].startswith('SURVIVOR'))
recorded = json.loads((pkg / 'results' / 'mut_B3_S1.json').read_text())
rec_surv = sorted(r['label'] for r in recorded['results'] if r['classification'].startswith('SURVIVOR'))
rec_cls = {r['label']: r['classification'] for r in recorded['results']}
mismatch = [r['label'] for r in results if rec_cls.get(r['label']) != r['classification']]
summary = {'kind': KIND, 'cap': CAP, 'base_states': len(D0), 'base_P1_violations': base_p1,
           'summary_by_group': summ, 'summary_total': total, 'survivors': survivors,
           'recorded_summary_total': recorded['summary_total'], 'recorded_survivors': rec_surv,
           'classification_mismatches_vs_recorded': mismatch,
           'truncated_runs': sorted(r['label'] for r in results if r.get('truncated'))}
(outdir / 'mutation_B3_S1_rerun_summary.json').write_text(json.dumps(summary, indent=1))
print(json.dumps({k: summary[k] for k in ('summary_total', 'recorded_summary_total', 'classification_mismatches_vs_recorded', 'survivors')}, indent=1))
