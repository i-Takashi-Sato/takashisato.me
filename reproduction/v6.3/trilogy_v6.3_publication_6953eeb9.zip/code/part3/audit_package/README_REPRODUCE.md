# Verification package v3 (independent audit of the Part III exit-protocol checker)

Status: independent audit material. It does not modify, and must not be used to replace, the
historical checker, the published v6.2 paper or the official site. Every result below describes a
finite-state ABSTRACTION; it shows internal consistency of that abstraction, not real-world validity.

## Contents

| path | what it is |
|---|---|
| historical/formal_protocol_checks.py | historical v5.9 checker, byte-identical to the published file (README.txt and LICENSE alongside) |
| historical/CHECKER.sha256 | SHA-256 of the three historical files (checked by run_all.sh before anything runs) |
| audit/audit_core.py | generic engine: BFS exploration, labeled transition sets, AST guard mutation, SCC, exact strong-fairness search |
| audit/exp_models.py | experimental models layered on the unmodified checker: M0, A, B, B2, M0_S1, B2_S1, B3_S1 |
| audit/audit_part3_checker_v2.py | fixed audit script: fidelity, closure reachability, deadlocks, fairness, mutation suites, assemble |
| audit/audit_followup.py | compatibility (B2_S1 vs B2, B3_S1 vs B2_S1), survivor assessment, closure traces after re-containment |
| audit/scenario_traces.py | witness path of the historical stranded-after-release defect and walkthroughs |
| audit/check_expected.py | compares a fresh run with results/expected_summary.json and the published numbers |
| audit/run_all.sh | one command that reproduces everything |
| results/ | outputs of the run reported in the audit message (results_v3.json is the merged file) |
| diffs/ | audit_v1_to_v2.diff (script fixes), exp_models_B2S1_to_B3S1.diff (what B3_S1 adds) |

## Requirements

Python 3.10 or newer, standard library only, Linux or macOS shell. No network access is needed
(the historical files are included). Memory: baseline exploration of every model is small; the mutation suite of B3_S1 uses a 250,000-state cap per mutant because a few mutants (e.g. no epoch bump) grow without bound and exhaust 8 GB at the default 1,000,000 cap. A mutant run that hits the cap after a violation witness counts as killed; without a witness it is INVALID_TRUNCATED.

## Reproduce

    cd <this directory>
    ./audit/run_all.sh                 # all models, about 1.5-2 h on 2 cores (B3_S1 mutation suite is ~35 min)
    ./audit/run_all.sh M0 B2_S1        # only some mutation suites (core analysis always runs for every model)
    OUT=/some/other/dir ./audit/run_all.sh   # keep the shipped results untouched

Individual steps (all take --checker historical/formal_protocol_checks.py --outdir DIR):

    python3 -I audit/audit_part3_checker_v2.py core ...
    python3 -I audit/audit_part3_checker_v2.py mutate --kind B3_S1 ...
    python3 -I audit/audit_followup.py all ...
    python3 -I audit/audit_part3_checker_v2.py assemble --outdir DIR

Stand-alone integrity check: `cd historical && sha256sum -c CHECKER.sha256`.
Note: use `python3 -I` (isolated mode) so that no stray module in the working directory is imported.

## What the key outputs mean

- core.json / results_v3.json["core"]: per model states, labeled transitions, violations (distinct violating
  states and violation instances reported separately), closure reachability (P0, P1), doomed states,
  deadlock classes, weak/strong fairness (whole-SCC test plus exact sub-SCC search), planned-retirement paths.
- mut_<kind>.json: mutation suite; classification is KILLED (baseline invariant / added invariant / P1 liveness),
  EQUIVALENT (labeled transition set identical to the unmutated model) or SURVIVOR (behaviour changed, nothing detected).
  A run that hit the state cap before a witness is INVALID_TRUNCATED; a witness before the cap still counts as a kill.
- followup_compat.json: exact difference sets between model layers (projection onto shared fields, edges compared
  from states that exist in both).
- followup_survivors.json: per-survivor effect (extra/missing states and edges, new closed/released/redeployed states,
  candidate invariants C1-C6 and their violations).
- followup_traces.json: concrete closure traces that contain a re-containment, each replayed through the model's own
  transition functions with all invariants evaluated along the path.

## Scope statement (explicit, deliberately bounded)

1. The abstraction ends at closure. B3_S1 adds exactly one bounded extension beyond it: two one-shot
   environment flags (post_boundary_case, post_boundary_harm) that may occur once the service is decommissioned
   (before or after closure). They never reopen or alter any other field; the checked statement is that
   a responsible party, a resolved responsibility and a secured remedy path exist whenever such a finding occurs,
   and that closure before the owner/remedy start is impossible while a pre-closure finding is open.
2. Not modeled: per-case ownership, the number of cases, quality of assessments, time, capacity or legitimacy of the
   residual custodian or successor, evidence of what happened during the in-service period.
3. Fairness: all actions (including environment events) are treated alike; liveness under a more specific
   environment assumption is not claimed.
