#!/usr/bin/env python3
"""Independent audit harness v2 for the historical v5.9 Part III checker and for
two experimental repair models (A, B) plus a planned-retirement refinement (S1).

Sub-commands
  core      fidelity check, baseline audit (fixed), exploration + analysis of every model
  mutate    mutation suite for one model kind  (--kind M0|A|B|B2|M0_S1|B2_S1)
  assemble  merge partial JSON files and print the comparison

The historical checker is read-only input: its source is hashed, exec'd into
private namespaces, and never written to.  Truncated explorations are flagged
(`truncated`) and the cap is reported; no conclusion may be drawn from them.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import sys
import time
from collections import Counter, deque
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import audit_core as C  # noqa: E402
import exp_models as E  # noqa: E402

EXPECTED_SHA = "ca82fc325fce1ddac2dcbcc407fe3eaa96892914855decc961ab220caebc0c7d"
KINDS = E.KINDS_ALL

# Closure prerequisites.  DIRECT = conjuncts of the closing action (`close_exit`
# _set_once requirements + invariant closure_requires_...).  UPSTREAM = further
# prerequisites of actions that must precede closure (`decommission` guards).
DIRECT = ["decommissioned", "independently_assured", "affected_people_notified",
          "remedy_opened", "post_exit_responsibility_resolved"]
UPSTREAM = ["currently_contained", "retirement_decision_authorized", "evidence_preserved"]


def is_extra(name: str) -> bool:
    return name.startswith("X:") or name.startswith("S1:")


# ------------------------------------------------------------------ fidelity
def fidelity(src: str) -> dict:
    H = C.load_module(src, "hist_fidelity")
    # (1) historical numbers, historical code path
    base = H.explore_exit_protocol()
    # (2) labeled edge set straight from the historical ExitState / EXIT_TRANSITIONS
    init = H.ExitState()
    keys = {C.skey(init): init}
    edges = set()
    q = deque([init])
    seen = {C.skey(init)}
    while q:
        s = q.popleft()
        for name, tr in H.EXIT_TRANSITIONS:
            n = tr(s, None)
            if n is None or n == s:
                continue
            edges.add((C.skey(s), name, C.skey(n)))
            if C.skey(n) not in seen:
                seen.add(C.skey(n))
                q.append(n)
    nb = len(C.skey(init))
    # (3) M0 replica
    M0 = E.build("M0", src, "fid")
    R0 = C.explore(M0)
    proj = {(a[:nb], n, b[:nb]) for a, n, b in C.labeled_edge_set(R0)}
    proj_states = {k[:nb] for k in R0.keys}
    # (4) the 30 published mutants, historical invariants only, against the historical explorer
    M0h = E.build("M0", src, "fid2")
    M0h.inv_state = lambda s, _H=M0h.meta["hist"]: _H.exit_invariant_violations(s)
    M0h.inv_edge = None
    same = 0
    diffs = []
    for m in H.CRITICAL_GUARD_MUTATIONS:
        h = H.explore_exit_protocol(m)["minimal_counterexample"]
        r = C.explore(M0h, m, keep_edges=False)
        mine = r.first_violation
        ok = bool(h and mine and h["trace"] == mine["trace"] and h["violations"] == mine["violations"])
        same += ok
        if not ok:
            diffs.append(m)
    return {
        "historical_reachable_states": base["reachable_state_count"],
        "historical_transitions": base["explored_transition_count"],
        "historical_labeled_edges": len(edges),
        "M0_states": len(R0.states), "M0_transitions": R0.n_transitions,
        "M0_projected_states_equal_historical": proj_states == seen,
        "M0_projected_labeled_edges_equal_historical": proj == edges,
        "M0_truncated": R0.truncated, "state_cap": R0.cap,
        "published_mutants_checked": len(H.CRITICAL_GUARD_MUTATIONS),
        "published_mutants_trace_and_violations_identical": same,
        "published_mutants_not_identical": diffs,
    }


# ------------------------------------------------------------------ analysis
def first_where(R, pred):
    for i, s in enumerate(R.states):
        if pred(s.__dict__):
            return i
    return None


def tr_state(R, i):
    if i is None:
        return None
    return {"trace": C.trace_of(R, i), "state": C.fmt_state(R.states[i]), "trace_length": len(C.trace_of(R, i))}


def analyze(M, R) -> dict:
    D = [s.__dict__ for s in R.states]
    n = len(D)
    succ, pred = C.build_adj(R)
    closed = [i for i in range(n) if D[i]["closed"]]
    can = C.back_reach(pred, closed)
    doomed = [i for i in range(n) if not can[i]]
    authorized_open = [i for i in range(n) if D[i]["retirement_decision_authorized"] and not D[i]["closed"]]
    stranded = [i for i in doomed if D[i]["retirement_decision_authorized"] and not D[i]["closed"]]
    ep_max = M.meta.get("ep_max")
    classes = Counter()
    for i in doomed:
        d = D[i]
        if d["retirement_decision_authorized"]:
            classes["doomed:authorized_but_cannot_close(DEFECT)"] += 1
        elif d["containment_released"] and ep_max is not None and d["epoch"] >= ep_max:
            classes["doomed:released_after_episode_budget(abstraction bound)"] += 1
        elif d["containment_released"]:
            classes["doomed:released_and_unauthorized(service restored, no retirement path)"] += 1
        else:
            classes["doomed:other"] += 1
    # direct vs upstream prerequisites among doomed states
    flags = DIRECT + UPSTREAM
    reach = {f: C.back_reach(pred, [i for i in range(n) if D[i][f]]) for f in flags}
    unatt = Counter()
    held = Counter()
    for i in doomed:
        u = tuple(f for f in flags if not reach[f][i])
        unatt[u] += 1
        for f in flags:
            if D[i][f]:
                held[f] += 1
    only_contain_missing = [i for i in doomed
                            if all(D[i][f] for f in DIRECT if f not in ("decommissioned", "independently_assured"))
                            and all(D[i][f] for f in UPSTREAM if f != "currently_contained")
                            and not D[i]["currently_contained"]]
    # deadlocks
    terminals = [i for i in range(n) if not succ[i]]
    tclass = Counter(M.meta["classify_terminal"](D[i]) for i in terminals)
    defect_terms = [i for i in terminals if M.meta["classify_terminal"](D[i]) == "DEFECT_terminal"]
    # fairness
    comp, nc = C.tarjan(n, succ)
    traps = C.fair_traps(R, succ, comp, nc, D)
    weak_auth = [t for t in traps if t["weak_trap"] and t["authorized_states"] > 0]
    strong_auth = [t for t in traps if t["strong_trap"] and t["authorized_states"] > 0]
    auth_defect_terms = [i for i in defect_terms if D[i]["retirement_decision_authorized"] and not D[i]["closed"]]
    sf, sf_stats = C.strong_fair_subgraphs(R, succ, D)
    out = {
        "states": n, "transitions": R.n_transitions, "truncated": R.truncated, "state_cap": R.cap,
        "violating_states": R.violating_states,
        "state_violation_instances": R.state_violation_instances,
        "violating_edges": R.violating_edges, "edge_violation_instances": R.edge_violation_instances,
        "violation_names": dict(R.state_violation_names + R.edge_violation_names),
        "first_violation": R.first_violation,
        "closed_states": len(closed),
        "states_from_which_closure_reachable": int(sum(can)),
        "closure_unreachable_states": len(doomed),
        "closure_unreachable_share_percent": round(100 * len(doomed) / n, 2),
        "authorized_unclosed_states": len(authorized_open),
        "P1_authorized_unclosed_but_closure_unreachable": len(stranded),
        "doomed_classes": dict(classes),
        "direct_vs_upstream": {
            "DIRECT_closure_prerequisites": DIRECT, "UPSTREAM_prerequisites": UPSTREAM,
            "doomed_states_holding_each_flag": dict(held),
            "doomed_states_by_unattainable_prerequisites": [
                {"unattainable": list(k), "count": v} for k, v in unatt.most_common()],
            "doomed_with_everything_but_current_containment_and_its_dependents": len(only_contain_missing),
        },
        "terminal_states": len(terminals),
        "terminal_classes": dict(tclass),
        "defect_terminal_states": len(defect_terms),
        "fairness": {
            "nontrivial_sccs_without_closure": len(traps),
            "weak_fair_traps": sum(t["weak_trap"] for t in traps),
            "strong_fair_traps": sum(t["strong_trap"] for t in traps),
            "weak_fair_traps_with_authorized_states": len(weak_auth),
            "strong_fair_traps_with_authorized_states": len(strong_auth),
            "authorized_unclosed_defect_terminals": len(auth_defect_terms),
            "exact_strong_fairness_subgraph_search": {
                "method": "Streett emptiness by recursive SCC decomposition (sub-SCC fair runs included)",
                "fair_closure_avoiding_subgraphs": len(sf),
                "of_which_reachable_from_authorized_state": sum(1 for t in sf if t["reachable_from_authorized"]),
                "stats": sf_stats,
                "examples": [{k: t[k] for k in ("size", "depth", "authorized_states", "reachable_from_authorized", "actions")}
                             for t in sf[:3]],
            },
            "scc_examples": [
                {k: t[k] for k in ("size", "weak_trap", "strong_trap", "has_exit",
                                    "authorized_states", "internal_actions", "always_enabled_actions")}
                for t in traps[:3]],
        },
        "paths": {
            "first_closure_unreachable_state": tr_state(R, doomed[0] if doomed else None),
            "first_stranded_authorized_state": tr_state(R, stranded[0] if stranded else None),
            "first_defect_terminal": tr_state(R, defect_terms[0] if defect_terms else None),
        },
    }
    out["propositions"] = {
        "P0_closure_reachable_from_initial_state": bool(closed),
        "P1_AG(authorized & !closed -> EF closed)": len(stranded) == 0,
        "P2_no_strongly_fair_run_avoids_closure_once_authorized":
            len(strong_auth) == 0 and len(auth_defect_terms) == 0
            and not any(t["reachable_from_authorized"] for t in sf),
        "P2w_no_weakly_fair_run_avoids_closure_once_authorized":
            len(weak_auth) == 0 and len(auth_defect_terms) == 0,
        "P3_all_terminal_states_are_intended": len(defect_terms) == 0,
    }
    # planned retirement
    excl_emerg = {"authorize_emergency_safe_stop", "contain_emergency_safe_stop",
                  "recontain_emergency_safe_stop"}
    pr = {}
    base_pred = lambda d: d["closed"]
    pr["shortest_closure"] = tr_state(R, first_where(R, base_pred))
    pr["shortest_closure_basis_OTHER_AUTHORIZED_BASIS"] = tr_state(
        R, first_where(R, lambda d: d["closed"] and d["retirement_basis"] == "OTHER_AUTHORIZED_BASIS"))
    pr["shortest_closure_basis_RESOLUTION_COLLAPSE"] = tr_state(
        R, first_where(R, lambda d: d["closed"] and d["retirement_basis"] == "RESOLUTION_COLLAPSE"))
    t_other, _ = C.bfs_excluding(R, succ, lambda d: d["closed"] and d["retirement_basis"] == "OTHER_AUTHORIZED_BASIS",
                                 exclude={"record_resolution_collapse_basis"})
    pr["other_basis_trace_without_RC_action"] = t_other
    pr["OTHER_basis_trace_uses_record_other_authorized_retirement_basis"] = bool(
        t_other and "record_other_authorized_retirement_basis" in t_other)
    nec = []
    for a in R.names:
        t, _ = C.bfs_excluding(R, succ, base_pred, exclude={a})
        if t is None:
            nec.append(a)
    pr["actions_necessary_for_any_closure"] = nec
    pr["closed_states_by_basis"] = dict(Counter(D[i]["retirement_basis"].value if hasattr(D[i]["retirement_basis"], "value")
                                                  else D[i]["retirement_basis"] for i in closed))
    if M.meta["kind"].endswith("S1"):
        sc = {}
        for harm in ("NONE", "FOUND"):
            for inv in ("NONE", "EXIST"):
                i = first_where(R, lambda d, h=harm, v=inv: d["closed"] and d["harm_assessment"] == h and d["case_inventory"] == v)
                sc[f"harm={harm},cases={inv}"] = tr_state(R, i)
        pr["S1_scenarios_shortest_closure"] = sc
        pr["S1_closed_with_harm_unassessed"] = sum(1 for i in closed if D[i]["harm_assessment"] == "UNASSESSED")
        pr["S1_closed_with_inventory_unverified"] = sum(1 for i in closed if D[i]["case_inventory"] == "UNVERIFIED")
        pr["S1_closed_found_harm_without_remedy_initiation"] = sum(
            1 for i in closed if D[i]["harm_assessment"] == "FOUND" and not D[i]["remedy_initiated"])
        pr["S1_closed_existing_cases_without_owner"] = sum(
            1 for i in closed if D[i]["case_inventory"] == "EXIST" and not D[i]["open_case_owner_assigned"])
        late = None
        for i in closed:
            t = C.trace_of(R, i)
            if "late_case_discovered" in t:
                late = i
                break
        pr["S1_closure_after_late_case_discovery"] = tr_state(R, late)
    out["planned_retirement"] = pr
    out["diagnostic_closed_on_pre_recontainment_evidence"] = sum(
        1 for i in closed if D[i]["recontained"] and D[i]["evidence_preserved"] and D[i]["evid_epoch"] < D[i]["epoch"])
    out["diagnostic_closed_after_recontainment"] = sum(1 for i in closed if D[i]["recontained"])
    return out


# ------------------------------------------------------------------ mutation suite
_G: dict = {}


def _job(job):
    label, group, src, named = job
    M = E.build(_G["kind"], src, tag="mut")
    R = C.explore(M, named, cap=_G["cap"])
    names = dict(R.state_violation_names + R.edge_violation_names)
    base_names = sorted(k for k in names if not is_extra(k))
    extra_names = sorted(k for k in names if is_extra(k))
    D = [s.__dict__ for s in R.states]
    succ, pred = C.build_adj(R)
    closed = [i for i in range(len(D)) if D[i]["closed"]]
    can = C.back_reach(pred, closed)
    p1 = sum(1 for i in range(len(D)) if D[i]["retirement_decision_authorized"] and not D[i]["closed"] and not can[i])
    res = {"label": label, "group": group, "states": len(D), "transitions": R.n_transitions,
           "truncated": R.truncated, "violating_states": R.violating_states,
           "state_violation_instances": R.state_violation_instances,
           "violating_edges": R.violating_edges, "edge_violation_instances": R.edge_violation_instances,
           "violated_baseline_invariants": base_names, "violated_extra_invariants": extra_names,
           "first_violation": R.first_violation, "P1_violations": p1, "closed_states": len(closed)}
    safety = R.violating_states > 0 or R.violating_edges > 0
    if not safety:
        es = C.labeled_edge_set(R)
        be = _G["base_edges"]
        res["equal_state_set"] = set(R.keys) == _G["base_keys"]
        res["labeled_edge_set_identical"] = es == be
        res["extra_labeled_edges"] = len(es - be)
        res["missing_labeled_edges"] = len(be - es)
        w = None
        for s, a, d in R.edges:
            if (R.keys[s], R.names[a], R.keys[d]) not in be:
                w = {"trace_to_source": C.trace_of(R, s), "action": R.names[a],
                     "source_state": C.fmt_state(R.states[s])}
                break
        res["extra_edge_witness"] = w
    return res


def classify(res: dict, base_p1: int) -> str:
    # A violation witness found before the cap is a valid kill even if the run was
    # truncated afterwards (e.g. an unbounded epoch counter).  Only a truncated run
    # WITHOUT a witness is invalid: absence of violations proves nothing there.
    if res["violated_baseline_invariants"]:
        return "KILLED_by_baseline_invariant" + ("(run truncated after witness)" if res.get("truncated") else "")
    if res["violated_extra_invariants"]:
        return "KILLED_by_added_invariant_only" + ("(run truncated after witness)" if res.get("truncated") else "")
    if res.get("truncated"):
        return "INVALID_TRUNCATED_no_witness"
    # A liveness kill is meaningful only when the unmutated model satisfies P1
    # (base_p1 == 0).  For a base that already violates P1 (M0), a changed P1 count
    # merely reflects a changed state space and is NOT counted as detection.
    if base_p1 == 0 and res["P1_violations"] > 0:
        return "KILLED_by_liveness_P1_only"
    if res.get("labeled_edge_set_identical"):
        return "EQUIVALENT(labeled graph identical)"
    return "SURVIVOR(behaviour changed, nothing detected)"


def mutate(kind: str, src: str, out: Path, with_ast: bool, cap: int):
    t0 = time.time()
    H = C.load_module(src, "hist_for_mut")
    funcs = {tr.__name__ for _, tr in H.EXIT_TRANSITIONS}
    M = E.build(kind, src, "base")
    R0 = C.explore(M, None, cap=cap)
    assert not R0.truncated
    D0 = [s.__dict__ for s in R0.states]
    succ, pred = C.build_adj(R0)
    can0 = C.back_reach(pred, [i for i in range(len(D0)) if D0[i]["closed"]])
    base_p1 = sum(1 for i in range(len(D0)) if D0[i]["retirement_decision_authorized"] and not D0[i]["closed"] and not can0[i])
    _G.update(kind=kind, cap=cap, base_edges=C.labeled_edge_set(R0), base_keys=set(R0.keys))
    jobs = [(f"hist:{m}", "hist_named", src, m) for m in H.CRITICAL_GUARD_MUTATIONS]
    jobs += [(f"model:{m}", "model_named", src, m) for m in E.named_mutants_for(kind)]
    n_sites = 0
    if with_ast:
        am = C.ast_mutants(src, funcs)
        n_sites = len(am)
        jobs += [(lab, "ast", s, None) for lab, s in am]
    ctx = mp.get_context("fork")
    with ProcessPoolExecutor(max_workers=os.cpu_count() or 2, mp_context=ctx) as ex:
        results = list(ex.map(_job, jobs, chunksize=1))
    for r in results:
        r["classification"] = classify(r, base_p1)
    summ = {}
    for g in ("hist_named", "model_named", "ast"):
        rs = [r for r in results if r["group"] == g]
        summ[g] = {"total": len(rs), **dict(Counter(r["classification"] for r in rs))}
    allc = Counter(r["classification"] for r in results)
    invkill = Counter()
    for r in results:
        for nme in r["violated_baseline_invariants"] + r["violated_extra_invariants"]:
            invkill[nme] += 1
    data = {
        "kind": kind, "base_states": len(D0), "base_P1_violations": base_p1,
        "ast_sites": n_sites, "ast_run": with_ast, "summary_by_group": summ,
        "summary_total": {"total": len(results), **dict(allc)},
        "invariant_kill_counts": dict(invkill),
        "results": results, "elapsed_seconds": round(time.time() - t0, 1),
    }
    out.write_text(json.dumps(data, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
    print(kind, json.dumps(data["summary_total"]), "elapsed", data["elapsed_seconds"], "s")


# ------------------------------------------------------------------ core
def core(src: str, v1_path: Path | None, outdir: Path, cap: int):
    t0 = time.time()
    out = {"checker_sha256": hashlib.sha256(src.encode("utf-8")).hexdigest(), "state_cap": cap}
    out["checker_sha256_matches_expected"] = out["checker_sha256"] == EXPECTED_SHA
    out["fidelity"] = fidelity(src)
    print("fidelity:", json.dumps({k: v for k, v in out["fidelity"].items() if k != "published_mutants_not_identical"}))
    models = {}
    for kind in KINDS:
        M = E.build(kind, src, "core")
        R = C.explore(M, None, cap=cap)
        a = analyze(M, R)
        a["state_variables_extended_model"] = len(M.fields)
        a["transitions_available"] = M.names
        a["new_actions"] = [x for x in M.names if x not in [n for n, _ in C.load_module(src, "h_names").EXIT_TRANSITIONS]]
        models[kind] = a
        print(kind, "states", a["states"], "trans", a["transitions"], "trunc", a["truncated"],
              "viol", a["violating_states"], a["violating_edges"],
              "closed", a["closed_states"], "doomed", a["closure_unreachable_states"],
              "P1stranded", a["P1_authorized_unclosed_but_closure_unreachable"],
              "defect_terminals", a["defect_terminal_states"], json.dumps(a["propositions"]))
        if kind in ("A", "B"):
            M0R = None
    out["models"] = models
    # layer diff vs M0 (epoch-0 layer projected to historical fields)
    H = C.load_module(src, "h_diff")
    nb = len(C.skey(H.ExitState()))
    M0 = E.build("M0", src, "d0")
    R0 = C.explore(M0)
    e0 = {(a[:nb], n, b[:nb]) for a, n, b in C.labeled_edge_set(R0)}
    s0 = {k[:nb] for k in R0.keys}
    diffs = {}
    for kind in ("A", "B", "B2"):
        M = E.build(kind, src, "dd")
        R = C.explore(M)
        D = [s.__dict__ for s in R.states]
        layer = {i for i in range(len(D)) if D[i]["epoch"] == 0}
        names_h = {n for n, _ in H.EXIT_TRANSITIONS}
        ek = {(R.keys[s][:nb], R.names[a], R.keys[d][:nb]) for s, a, d in R.edges
              if s in layer and d in layer and R.names[a] in names_h}
        sk = {R.keys[i][:nb] for i in layer}
        diffs[kind] = {
            "epoch0_layer_states": len(sk), "M0_states": len(s0),
            "M0_states_absent_from_epoch0_layer": len(s0 - sk),
            "epoch0_layer_states_absent_from_M0": len(sk - s0),
            "M0_labeled_edges_absent_from_epoch0_layer": len(e0 - ek),
            "epoch0_layer_labeled_edges_absent_from_M0": len(ek - e0),
            "states_in_later_epochs": len(D) - len(layer),
            "example_removed_edge": None,
        }
        rem = sorted(e0 - ek, key=lambda t: t[1])[:1]
        if rem:
            diffs[kind]["example_removed_edge"] = {"action": rem[0][1]}
        diffs[kind]["removed_edges_by_action"] = dict(Counter(a for _, a, _ in (e0 - ek)))
    out["layer_diff_vs_M0"] = diffs
    # baseline v1 reclassification (needs M0 AST mutation file produced by `mutate --kind M0`)
    out["v1_path"] = str(v1_path) if v1_path else None
    out["elapsed_seconds"] = round(time.time() - t0, 1)
    (outdir / "core.json").write_text(json.dumps(out, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
    print("core elapsed", out["elapsed_seconds"], "s")


def assemble(outdir: Path, v1_path: Path | None):
    core_ = json.loads((outdir / "core.json").read_text(encoding="utf-8"))
    res = {"core": core_, "mutation": {}}
    for kind in KINDS:
        p = outdir / f"mut_{kind}.json"
        if p.exists():
            m = json.loads(p.read_text(encoding="utf-8"))
            # re-apply the (corrected) classification rule to the stored raw fields
            for r in m["results"]:
                r["classification"] = classify(r, m["base_P1_violations"])
            summ = {}
            for g in ("hist_named", "model_named", "ast"):
                rs = [r for r in m["results"] if r["group"] == g]
                summ[g] = {"total": len(rs), **dict(Counter(r["classification"] for r in rs))}
            m["summary_by_group"] = summ
            m["summary_total"] = {"total": len(m["results"]),
                                  **dict(Counter(r["classification"] for r in m["results"]))}
            res["mutation"][kind] = m
    # v1 vs v2 reclassification on the baseline
    if v1_path and v1_path.exists() and "M0" in res["mutation"] and res["mutation"]["M0"]["ast_run"]:
        v1 = json.loads(v1_path.read_text(encoding="utf-8"))
        ast_ = [r for r in res["mutation"]["M0"]["results"] if r["group"] == "ast"]
        v2 = {"KILLED": set(), "EQUIV": set(), "EDGE_OR_STATE_CHANGE": set()}
        for r in ast_:
            c = r["classification"]
            if c.startswith("KILLED"):
                v2["KILLED"].add(r["label"])
            elif c.startswith("EQUIVALENT"):
                v2["EQUIV"].add(r["label"])
            else:
                v2["EDGE_OR_STATE_CHANGE"].add(r["label"])
        v1k = {x["label"] for x in v1["B_killed"]}
        v1r = set(v1["B_redundant_guards"])
        v1o = {x["label"] for x in v1["B_same_states_different_edges"]} | {x["label"] for x in v1["B_survivors"]}
        res["v1_vs_v2_baseline_AST_reclassification"] = {
            "v1_counts": {"killed": len(v1k), "redundant": len(v1r), "behaviour_changed_undetected": len(v1o)},
            "v2_counts": {"killed": len(v2["KILLED"]), "equivalent": len(v2["EQUIV"]),
                          "behaviour_changed_undetected": len(v2["EDGE_OR_STATE_CHANGE"])},
            "killed_sets_identical": v1k == v2["KILLED"],
            "redundant_vs_equivalent_sets_identical": v1r == v2["EQUIV"],
            "undetected_sets_identical": v1o == v2["EDGE_OR_STATE_CHANGE"],
            "moved_v1_redundant_to_v2_behaviour_changed": sorted(v1r & v2["EDGE_OR_STATE_CHANGE"]),
            "moved_v1_undetected_to_v2_equivalent": sorted(v1o & v2["EQUIV"]),
        }
    res["followup"] = {}
    for name in ("compat", "survivors", "traces"):
        fp = outdir / f"followup_{name}.json"
        if fp.exists():
            res["followup"][name] = json.loads(fp.read_text(encoding="utf-8"))
    (outdir / "results_v3.json").write_text(json.dumps(res, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
    # console comparison
    print("\n=== comparison ===")
    hdr = f"{'model':8} {'states':>7} {'trans':>8} {'viol':>5} {'closed':>6} {'doomed':>6} {'P1':>4} {'defTerm':>7} {'strongTrap(auth)':>16}"
    print(hdr)
    for kind in KINDS:
        a = core_["models"][kind]
        print(f"{kind:8} {a['states']:7} {a['transitions']:8} {a['violating_states']+a['violating_edges']:5} "
              f"{a['closed_states']:6} {a['closure_unreachable_states']:6} {a['P1_authorized_unclosed_but_closure_unreachable']:4} "
              f"{a['defect_terminal_states']:7} {a['fairness']['strong_fair_traps_with_authorized_states']:16}")
    for kind, m in res["mutation"].items():
        print(kind, "mutation total:", json.dumps(m["summary_total"]))
    return res


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("core", "mutate", "assemble"):
        p = sub.add_parser(name)
        p.add_argument("--checker", type=Path)
        p.add_argument("--outdir", type=Path, required=True)
        p.add_argument("--v1-output", type=Path)
        p.add_argument("--kind", choices=KINDS)
        p.add_argument("--no-ast", action="store_true")
        p.add_argument("--cap", type=int, default=C.MAX_STATES)
    a = ap.parse_args()
    a.outdir.mkdir(parents=True, exist_ok=True)
    if a.cmd == "assemble":
        assemble(a.outdir, a.v1_output)
        return
    raw = a.checker.read_bytes()
    if hashlib.sha256(raw).hexdigest() != EXPECTED_SHA:
        print("WARNING: checker hash differs from the published value", file=sys.stderr)
    src = raw.decode("utf-8")
    if a.cmd == "core":
        core(src, a.v1_output, a.outdir, a.cap)
    else:
        mutate(a.kind, src, a.outdir / f"mut_{a.kind}.json", not a.no_ast, a.cap)


if __name__ == "__main__":
    main()
