#!/usr/bin/env python3
"""Compare a fresh results_v3.json with results/expected_summary.json (and with the published numbers).

usage: check_expected.py <results_v3.json> <expected_summary.json>
Exit code 0 = every compared number matches.  Pure comparison, no model code is run.
"""
import json
import sys
from pathlib import Path

res = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
exp = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
bad = 0


def chk(label, got, want):
    global bad
    ok = got == want
    bad += (not ok)
    print(("PASS " if ok else "FAIL ") + label + ("" if ok else f"  got={got!r} want={want!r}"))


core = res["core"]
fid = core["fidelity"]
chk("historical states (published value)", fid["historical_reachable_states"], 8564)
chk("historical transitions (published value)", fid["historical_transitions"], 36096)
chk("published mutants checked", fid["published_mutants_checked"], 30)
chk("published mutants trace+violations identical", fid["published_mutants_trace_and_violations_identical"], 30)
chk("M0 replica projected labeled edges == historical", fid["M0_projected_labeled_edges_equal_historical"], True)
chk("checker sha256", core["checker_sha256"], exp["checker_sha256"])
for kind, want in exp["models"].items():
    got = core["models"].get(kind)
    if got is None:
        chk(f"{kind} present", None, "present"); continue
    for k, v in want.items():
        chk(f"{kind}.{k}", got.get(k) if k in got else got["fairness"]["exact_strong_fairness_subgraph_search"].get("fair_closure_avoiding_subgraphs"), v)
for kind, want in exp["mutation_totals"].items():
    m = res["mutation"].get(kind)
    chk(f"{kind} mutation totals", None if m is None else m["summary_total"], want)
print("RESULT:", "ALL MATCH" if bad == 0 else f"{bad} MISMATCH(ES)")
sys.exit(1 if bad else 0)
