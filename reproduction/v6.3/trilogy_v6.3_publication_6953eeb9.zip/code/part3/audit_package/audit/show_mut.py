import json, sys
sys.path.insert(0,'.')
import audit_part3_checker_v2 as A
kind=sys.argv[1]
m=json.load(open(f"out/mut_{kind}.json"))
for r in m["results"]: r["classification"]=A.classify(r,m["base_P1_violations"])
from collections import Counter
print("=====",kind,"base P1:",m["base_P1_violations"], dict(Counter(r["classification"] for r in m["results"])))
for g in ("hist_named","model_named","ast"):
    rs=[r for r in m["results"] if r["group"]==g]
    print("--",g,dict(Counter(r["classification"] for r in rs)))
    for r in rs:
        c=r["classification"]
        if g=="model_named" or (g!="model_named" and not c.startswith("KILLED_by_baseline") and not c.startswith("EQUIVALENT")) :
            ex=""
            if c.startswith("KILLED"): ex=" by "+",".join((r["violated_baseline_invariants"]+r["violated_extra_invariants"])[:2])+(" trunc" if r["truncated"] else "")
            if c.startswith("SURV") and r.get("extra_edge_witness"): ex=" | +%d/-%d edges; first: %s"%(r["extra_labeled_edges"],r["missing_labeled_edges"], r["extra_edge_witness"]["action"])
            print("   %-32s %s%s"%(c[:32], r["label"][:100], ex))
