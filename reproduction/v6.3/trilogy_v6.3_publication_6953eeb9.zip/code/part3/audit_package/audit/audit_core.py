#!/usr/bin/env python3
"""Generic engine for the independent audit (v2).

Fixes relative to audit v1 (audit_part3_checker.py):
  1. Graph identity is decided on the LABELED transition set (source state,
     action, target state), never on state-set equality plus a transition count.
  2. The number of distinct violating states and the number of violation
     instances (state-invariant names per state, edge-invariant names per edge)
     are reported separately.  (v1 called the instance count "violating_state_count".)
  3. Exploration reports `truncated` and the cap explicitly; every conclusion
     drawn from a truncated run must be treated as invalid.
  4. Closure prerequisites are split into DIRECT (guards of the closing action)
     and UPSTREAM (guards of actions that must precede it); see driver.

No function in this file modifies the historical checker.  The checker source is
only exec'd into private module namespaces.
"""
from __future__ import annotations

import ast
import copy
import sys
import types
from collections import Counter, defaultdict, deque

MAX_STATES = 1_000_000


def load_module(src: str, name: str) -> types.ModuleType:
    mod = types.ModuleType(name)
    mod.__file__ = name
    sys.modules[name] = mod
    exec(compile(src, name, "exec"), mod.__dict__)
    return mod


def skey(state) -> tuple:
    """Class-independent identity of a state (field order is the dataclass order)."""
    return tuple(state.__dict__.values())


class Model:
    def __init__(self, name, init, transitions, inv_state, inv_edge, fields, meta=None):
        self.name = name
        self.init = init
        self.transitions = transitions
        self.names = [n for n, _ in transitions]
        self.inv_state = inv_state
        self.inv_edge = inv_edge
        self.fields = fields
        self.meta = meta or {}


class Result:
    pass


def trace_of(R, i: int) -> list[str]:
    out = []
    while R.parent[i] is not None:
        pi, ai = R.parent[i]
        out.append(R.names[ai])
        i = pi
    return list(reversed(out))


def explore(model: Model, mutant: str | None = None, cap: int = MAX_STATES,
            keep_edges: bool = True) -> Result:
    tr = model.transitions
    inv_state, inv_edge = model.inv_state, model.inv_edge
    init = model.init
    k0 = skey(init)
    R = Result()
    R.names = model.names
    R.states = [init]
    R.keys = [k0]
    R.parent = [None]
    R.edges = []
    R.cap = cap
    R.truncated = False
    R.n_transitions = 0
    R.violating_states = 0
    R.state_violation_instances = 0
    R.violating_edges = 0
    R.edge_violation_instances = 0
    R.state_violation_names = Counter()
    R.edge_violation_names = Counter()
    R.first_state_violation = None
    R.first_edge_violation = None
    idx = {k0: 0}
    v0 = inv_state(init)
    if v0:
        R.violating_states += 1
        R.state_violation_instances += len(v0)
        R.state_violation_names.update(v0)
        R.first_state_violation = {"trace": [], "violations": v0}
    q = deque([0])
    while q:
        si = q.popleft()
        s = R.states[si]
        ks = R.keys[si]
        for ai, (name, fn) in enumerate(tr):
            n = fn(s, mutant)
            if n is None:
                continue
            kn = skey(n)
            if kn == ks:
                continue
            R.n_transitions += 1
            if inv_edge is not None:
                ve = inv_edge(s, name, n)
                if ve:
                    R.violating_edges += 1
                    R.edge_violation_instances += len(ve)
                    R.edge_violation_names.update(ve)
                    if R.first_edge_violation is None:
                        R.first_edge_violation = {"trace": trace_of(R, si) + [name], "violations": ve}
            di = idx.get(kn)
            if di is None:
                di = len(R.states)
                idx[kn] = di
                R.states.append(n)
                R.keys.append(kn)
                R.parent.append((si, ai))
                q.append(di)
                vs = inv_state(n)
                if vs:
                    R.violating_states += 1
                    R.state_violation_instances += len(vs)
                    R.state_violation_names.update(vs)
                    if R.first_state_violation is None:
                        R.first_state_violation = {"trace": trace_of(R, di), "violations": vs}
                if len(R.states) >= cap:
                    R.truncated = True
                    q.clear()
                    break
            if keep_edges:
                R.edges.append((si, ai, di))
        if R.truncated:
            break
    cands = [x for x in (R.first_state_violation, R.first_edge_violation) if x]
    R.first_violation = min(cands, key=lambda x: len(x["trace"])) if cands else None
    return R


def labeled_edge_set(R: Result) -> set:
    names, keys = R.names, R.keys
    return {(keys[s], names[a], keys[d]) for s, a, d in R.edges}


def fmt_state(s) -> str:
    out = []
    for k, v in s.__dict__.items():
        if v is True:
            out.append(k)
        elif hasattr(v, "value"):
            if v.value not in ("UNRECORDED", "UNDECIDED"):
                out.append(f"{k}={v.value}")
        elif isinstance(v, str) and v not in ("UNASSESSED", "UNVERIFIED"):
            out.append(f"{k}={v}")
        elif isinstance(v, int) and not isinstance(v, bool) and v not in (0, -1):
            out.append(f"{k}={v}")
    return ", ".join(out) or "(initial)"


# --------------------------------------------------------------------------- AST
def _is_return_none(node: ast.If) -> bool:
    return (len(node.body) == 1 and isinstance(node.body[0], ast.Return)
            and isinstance(node.body[0].value, ast.Constant)
            and node.body[0].value.value is None and not node.orelse)


def walk_sites(tree: ast.Module, funcs: set[str], apply: int | None = None) -> list[str]:
    sites: list[str] = []
    idx = 0
    for fn in [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in funcs]:
        for node in ast.walk(fn):
            if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "_set_once":
                for kw in node.keywords:
                    sites.append(f"{fn.name}: _set_once requirement '{kw.arg}'")
                    if apply == idx:
                        kw.value = ast.Constant(True)
                    idx += 1
            if isinstance(node, ast.If) and _is_return_none(node):
                t = node.test
                if isinstance(t, ast.UnaryOp) and isinstance(t.op, ast.Not):
                    inner = t.operand
                    sites.append(f"{fn.name}: whole early-return `if not ({ast.unparse(inner)})`")
                    if apply == idx:
                        node.test = ast.Constant(False)
                    idx += 1
                    if isinstance(inner, ast.BoolOp) and isinstance(inner.op, ast.And):
                        for j, op in enumerate(list(inner.values)):
                            sites.append(f"{fn.name}: conjunct '{ast.unparse(op)}'")
                            if apply == idx:
                                inner.values[j] = ast.Constant(True)
                            idx += 1
                elif isinstance(t, ast.BoolOp) and isinstance(t.op, ast.Or):
                    for j, op in enumerate(list(t.values)):
                        if isinstance(op, (ast.UnaryOp, ast.Compare)):
                            sites.append(f"{fn.name}: reject-disjunct '{ast.unparse(op)}'")
                            if apply == idx:
                                t.values[j] = ast.Constant(False)
                            idx += 1
    return sites


def ast_mutants(src: str, funcs: set[str]) -> list[tuple[str, str]]:
    tree0 = ast.parse(src)
    desc = walk_sites(copy.deepcopy(tree0), funcs)
    out = []
    for i, d in enumerate(desc):
        t = copy.deepcopy(tree0)
        walk_sites(t, funcs, apply=i)
        ast.fix_missing_locations(t)
        out.append((f"ast:{i:03d}:{d}", ast.unparse(t)))
    return out


# --------------------------------------------------------------------------- graph
def build_adj(R: Result):
    n = len(R.states)
    succ = [[] for _ in range(n)]
    pred = [[] for _ in range(n)]
    for s, a, d in R.edges:
        succ[s].append((a, d))
        pred[d].append(s)
    return succ, pred


def back_reach(pred, targets) -> bytearray:
    seen = bytearray(len(pred))
    dq = deque()
    for t in targets:
        if not seen[t]:
            seen[t] = 1
            dq.append(t)
    while dq:
        v = dq.popleft()
        for p in pred[v]:
            if not seen[p]:
                seen[p] = 1
                dq.append(p)
    return seen


def tarjan(n: int, succ):
    index = [-1] * n
    low = [0] * n
    onstack = [False] * n
    comp = [-1] * n
    stack = []
    counter = 0
    ncomp = 0
    for root in range(n):
        if index[root] != -1:
            continue
        work = [(root, 0)]
        while work:
            v, i = work.pop()
            if i == 0:
                index[v] = low[v] = counter
                counter += 1
                stack.append(v)
                onstack[v] = True
            sv = succ[v]
            descended = False
            while i < len(sv):
                w = sv[i][1]
                i += 1
                if index[w] == -1:
                    work.append((v, i))
                    work.append((w, 0))
                    descended = True
                    break
                elif onstack[w]:
                    if index[w] < low[v]:
                        low[v] = index[w]
            if descended:
                continue
            if low[v] == index[v]:
                while True:
                    w = stack.pop()
                    onstack[w] = False
                    comp[w] = ncomp
                    if w == v:
                        break
                ncomp += 1
            if work:
                u = work[-1][0]
                if low[v] < low[u]:
                    low[u] = low[v]
    return comp, ncomp


def fair_traps(R: Result, succ, comp, ncomp, D, avoid_key="closed"):
    """Non-trivial SCCs containing no closed state, classified by fairness.

    weak_trap  : every action enabled in ALL states of the SCC also labels an
                 internal edge -> a weakly fair run can stay forever.
    strong_trap: every action enabled in ANY state of the SCC also labels an
                 internal edge -> a strongly fair run can stay forever.
    """
    members = defaultdict(list)
    for v, c in enumerate(comp):
        members[c].append(v)
    out = []
    for c, vs in members.items():
        if len(vs) == 1 and not any(d == vs[0] for _, d in succ[vs[0]]):
            continue
        if any(D[v][avoid_key] for v in vs):
            continue
        vset = set(vs)
        en = [set(a for a, _ in succ[v]) for v in vs]
        all_en = set.intersection(*en)
        any_en = set.union(*en)
        internal = {a for v in vs for a, d in succ[v] if d in vset}
        exits = [(R.names[a], v) for v in vs for a, d in succ[v] if d not in vset]
        out.append({
            "size": len(vs),
            "weak_trap": all_en <= internal,
            "strong_trap": any_en <= internal,
            "has_exit": bool(exits),
            "authorized_states": sum(1 for v in vs if D[v].get("retirement_decision_authorized")),
            "internal_actions": sorted(R.names[a] for a in internal),
            "always_enabled_actions": sorted(R.names[a] for a in all_en),
            "example_state": vs[0],
        })
    return out


def bfs_excluding(R: Result, succ, pred_fn, exclude=frozenset(), start=0):
    """Shortest action trace from `start` to a state satisfying pred_fn using no excluded action."""
    names = R.names
    parent = {start: None}
    q = deque([start])
    while q:
        v = q.popleft()
        if pred_fn(R.states[v].__dict__):
            out = []
            x = v
            while parent[x] is not None:
                px, a = parent[x]
                out.append(names[a])
                x = px
            return list(reversed(out)), v
        for a, d in succ[v]:
            if names[a] in exclude or d in parent:
                continue
            parent[d] = (v, a)
            q.append(d)
    return None, None


# --------------------------------------------------------------------------- exact strong-fairness check
def _induced_tarjan(vertices, succ):
    """SCCs of the subgraph induced by `vertices` (a set); returns list of lists."""
    vs = sorted(vertices)
    loc = {v: i for i, v in enumerate(vs)}
    lsucc = [[(a, loc[d]) for a, d in succ[v] if d in loc] for v in vs]
    comp, nc = tarjan(len(vs), lsucc)
    groups = defaultdict(list)
    for i, c in enumerate(comp):
        groups[c].append(vs[i])
    return list(groups.values())


def strong_fair_subgraphs(R: Result, succ, D, avoid_key="closed", auth_key="retirement_decision_authorized"):
    """Exact search for strongly fair infinite runs that never reach a state with D[.][avoid_key].

    A strongly fair infinite run ends in a strongly connected subgraph T (set of states plus
    the edges it uses infinitely often) such that every action enabled in some state of T
    labels an edge inside T.  T need NOT be a whole maximal SCC.  Algorithm (Streett
    emptiness by recursive decomposition): take each SCC C of the closure-free graph; let
    BAD = actions enabled somewhere in C but labelling no edge inside C.  If BAD is empty
    C itself supports a fair run (report it).  Otherwise no fair T can contain a state that
    enables a BAD action, so delete those states and decompose the rest again.

    Enabledness uses the FULL graph (an edge to a closed state still makes the action enabled).
    Weak fairness is exact on whole SCCs (a sub-subgraph only enlarges the always-enabled set)
    and is reported by fair_traps().
    """
    n = len(D)
    alive = {i for i in range(n) if not D[i][avoid_key]}
    # states reachable from an authorized, unclosed state without passing a closed state
    seeds = [i for i in alive if D[i].get(auth_key)]
    reach = set(seeds)
    dq = deque(seeds)
    while dq:
        v = dq.popleft()
        for _, d in succ[v]:
            if d in alive and d not in reach:
                reach.add(d)
                dq.append(d)
    found, work = [], [alive]
    stats = {"sccs_examined": 0, "sccs_refined": 0, "refinement_rounds": 0, "max_depth": 0}
    depth = {id(alive): 0}
    while work:
        S = work.pop()
        dep = depth.pop(id(S), 0)
        stats["refinement_rounds"] += 1
        stats["max_depth"] = max(stats["max_depth"], dep)
        for comp in _induced_tarjan(S, succ):
            if len(comp) == 1:
                continue                       # no self-loops are stored
            stats["sccs_examined"] += 1
            cs = set(comp)
            internal = {a for v in comp for a, d in succ[v] if d in cs}
            enabled = {a for v in comp for a, _ in succ[v]}
            bad = enabled - internal
            if not bad:
                found.append({
                    "size": len(comp), "depth": dep,
                    "authorized_states": sum(1 for v in comp if D[v].get(auth_key)),
                    "reachable_from_authorized": bool(cs & reach),
                    "actions": sorted(R.names[a] for a in internal),
                    "example_state": comp[0],
                })
                continue
            stats["sccs_refined"] += 1
            keep = {v for v in comp if not any(a in bad for a, _ in succ[v])}
            if keep:
                sub = keep
                depth[id(sub)] = dep + 1
                work.append(sub)
    return found, stats
