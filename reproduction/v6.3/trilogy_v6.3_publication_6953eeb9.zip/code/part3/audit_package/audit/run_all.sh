#!/bin/bash
# Reproduces every result in results/.  Usage:  ./audit/run_all.sh [kinds...]   (default: all kinds)
# Needs only Python >= 3.10 (standard library).  Wall time on 2 cores: roughly 1.5-2 hours for all kinds
# (mutation suites dominate; see README_REPRODUCE.md).  Nothing outside results/ is written.
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
CK="$HERE/historical/formal_protocol_checks.py"
OUT="${OUT:-$HERE/results}"
KINDS=("$@"); [ ${#KINDS[@]} -eq 0 ] && KINDS=(M0 A B B2 M0_S1 B2_S1 B3_S1)
mkdir -p "$OUT"
echo "== 0. hash check"; (cd "$HERE/historical" && sha256sum -c CHECKER.sha256)
echo "== 1. core analysis (fidelity, closure reachability, deadlocks, fairness)"
python3 -I "$HERE/audit/audit_part3_checker_v2.py" core --checker "$CK" --outdir "$OUT" | tee "$OUT/core_log.txt"
for k in "${KINDS[@]}"; do
  echo "== 2. mutation suite: $k"
  CAP=1000000; [ "$k" = "B3_S1" ] && CAP=250000   # mutants with unbounded epoch growth would otherwise exhaust memory (8 GB)
  python3 -I "$HERE/audit/audit_part3_checker_v2.py" mutate --kind "$k" --cap "$CAP" --checker "$CK" --outdir "$OUT" | tee -a "$OUT/mutation_log.txt"
done
echo "== 3. follow-up audit (compatibility, survivors, closure traces)"
python3 -I "$HERE/audit/audit_followup.py" all --checker "$CK" --outdir "$OUT"
python3 -I "$HERE/audit/scenario_traces.py" "$CK" "$OUT/scenario_traces.json" > "$OUT/scenario_log.txt"
echo "== 4. assemble"
python3 -I "$HERE/audit/audit_part3_checker_v2.py" assemble --outdir "$OUT" | tee "$OUT/assemble_log.txt"
echo "== 5. check against expected numbers"
python3 -I "$HERE/audit/check_expected.py" "$OUT/results_v3.json" "$HERE/results/expected_summary.json" || true
echo "== done. hashes of the historical files are in historical/CHECKER.sha256"
