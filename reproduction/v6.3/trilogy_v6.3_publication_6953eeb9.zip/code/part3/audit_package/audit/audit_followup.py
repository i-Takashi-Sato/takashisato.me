#!/usr/bin/env python3
"""Follow-up audit (round 3): compatibility of S1 layers, survivor assessment, closure traces.

usage: audit_followup.py <compat|survivors|traces|all> --checker FILE --outdir DIR

Read-only with respect to the historical checker (its source is exec'd into private
namespaces).  Nothing here changes the published paper or site.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import audit_core as C  # noqa: E402
import exp_models as E  # noqa: E402

S1_FIELDS = ("harm_assessment", "remedy_initiated", "case_inventory")
B3_ONLY = ("led_harm_found", "led_remedy_init", "led_cases_exist", "harm_epoch", "inv_epoch",
           "post_boundary_case", "post_boundary_harm")
HIST_REPLACED_INV = "post_exit_responsibility_requires_branch_specific_owner_capacity_and_case_ownership"


def explore_kind(kind, src, tag="fu", mutant=None):
    M = E.build(kind, src, tag)
    R = C.explore(M, mutant)
    assert not R.truncated
    return M, R


def project(R, drop_idx, state_filter=None):
    """labeled edges and states with the dropped coordinates removed (optionally only over filtered states)."""
    keep = [i for i in range(len(R.keys[0])) if i not in drop_idx]
    pk = lambda k: tuple(k[i] for i in keep)
    ok = [True] * len(R.keys) if state_filter is None else [state_filter(k) for k in R.keys]
    states = {pk(R.keys[i]) for i in range(len(R.keys)) if ok[i]}
    edges = {(pk(R.keys[s]), R.names[a], pk(R.keys[d])) for s, a, d in R.edges if ok[s] and ok[d]}
    return states, edges, pk


# ---------------------------------------------------------------- 3. compatibility
def compat(src):
    out = {}
    fields = None
    # ---- B2 versus historical (restated; the proof object for the strict extension)
    M0, R0 = explore_kind("M0", src, "c0")
    MB2, RB2 = explore_kind("B2", src, "cb2")
    MS, RS = explore_kind("B2_S1", src, "cs1")
    M3, R3 = explore_kind("B3_S1", src, "c3")
    fields = {k: [f for f in M.fields] for k, M in (("B2", MB2), ("B2_S1", MS), ("B3_S1", M3))}
    idx = lambda M, names: {M.fields.index(n) for n in names}
    # ---------------- B2_S1 vs B2
    drop = idx(MS, S1_FIELDS) | idx(MS, B3_ONLY)
    drop2 = idx(MB2, B3_ONLY)         # B2 carries the same (constant) extra columns
    st1, ed1, _ = project(RS, drop)
    st0, ed0, _ = project(RB2, drop | drop2)
    names_b2 = set(RB2.names)
    ed1c = {e for e in ed1 if e[1] in names_b2}
    s1_actions = sorted(set(RS.names) - names_b2)
    common = st0 & st1
    ed1p = {e for e in ed1c if e[0] in common}
    ed0p = {e for e in ed0 if e[0] in common}
    relax = ed1p - ed0p          # from a state present in both models: edge only B2_S1 offers
    restrict = ed0p - ed1p       # from a state present in both models: edge only B2 offers
    def by_action(es):
        return dict(Counter(a for _, a, _ in es))
    # S1-only actions that change a non-S1 field (environment events)
    nonstutter = Counter()
    for s, a, d in RS.edges:
        if RS.names[a] in s1_actions:
            ks, kd = RS.keys[s], RS.keys[d]
            ch = [MS.fields[i] for i in range(len(ks)) if ks[i] != kd[i] and i not in drop]
            if ch:
                nonstutter[(RS.names[a], tuple(ch))] += 1
    out["B2_S1_vs_B2"] = {
        "projection": "forget harm_assessment, remedy_initiated, case_inventory (and constant bookkeeping columns); "
                      "an edge is kept if SOME S1 valuation of the source offers it",
        "B2_states": len(st0), "B2_S1_projected_states": len(st1), "common_projected_states": len(common),
        "states_only_in_B2": len(st0 - st1), "states_only_in_B2_S1": len(st1 - st0),
        "edges_from_common_states": [len(ed0p), len(ed1p)],
        "relaxations_from_common_states_by_action": by_action(relax),
        "restrictions_from_common_states_by_action": by_action(restrict),
        "S1_only_actions": s1_actions,
        "S1_only_actions_that_change_a_non_S1_field": {f"{a}:{'+'.join(c)}": n for (a, c), n in nonstutter.items()},
        "strict_extension_of_B2": (len(relax) == 0 and len(restrict) == 0 and not (st0 - st1)),
    }
    # slice: B2_S1 edges whose SOURCE has case_inventory != NONE (no verified-absence claim made)
    di = MS.fields.index("case_inventory")
    ed1_slice = {(project_key(R_, s, drop), R_.names[a], project_key(R_, d, drop))
                 for R_ in (RS,) for s, a, d in R_.edges
                 if R_.keys[s][di] != "NONE" and R_.names[a] in names_b2}
    out["B2_S1_vs_B2"]["slice_inventory_not_NONE"] = {
        "projected_edges": len(ed1_slice),
        "edges_not_in_B2": len(ed1_slice - ed0),
        "claim": "restricted to sources where no 'no unresolved cases' verification was made, every projected B2_S1 edge is a B2 edge",
    }
    # replaced invariant: where does the historical one fail in B2_S1, and why
    H = M3.meta["hist"]
    fail = Counter()
    for s in RS.states:
        names = H.exit_invariant_violations(s)
        if HIST_REPLACED_INV in names:
            fail[s.case_inventory] += 1
    out["replaced_invariant"] = {
        "name": HIST_REPLACED_INV,
        "B2_S1_states_violating_the_historical_form_by_case_inventory": dict(fail),
        "reading": "the historical form (owner required for every resolution) fails only where case_inventory=NONE; "
                   "S1 keeps it for EXIST and drops it for NONE (intentional specification change), and adds "
                   "'inventory must be verified before resolution'.",
        "historical_form_holds_in_B2": all(HIST_REPLACED_INV not in H.exit_invariant_violations(s) for s in RB2.states),
    }
    # ---------------- B3_S1 vs B2_S1
    drop3 = idx(M3, B3_ONLY)
    dropS = idx(MS, B3_ONLY)
    i_pc, i_ph = M3.fields.index("post_boundary_case"), M3.fields.index("post_boundary_harm")
    nopb = lambda k: not k[i_pc] and not k[i_ph]       # the layer before any post-boundary finding
    st3, ed3, _ = project(R3, drop3, nopb)
    stS, edS, _ = project(RS, dropS)
    names_s = set(RS.names)
    ed3c = {e for e in ed3 if e[1] in names_s}
    new_actions = sorted(set(R3.names) - names_s)
    commonS = st3 & stS
    rel3 = {e for e in ed3c if e[0] in commonS} - {e for e in edS if e[0] in commonS}
    res3 = {e for e in edS if e[0] in commonS} - {e for e in ed3c if e[0] in commonS}
    out["B3_S1_vs_B2_S1"] = {
        "projection": "forget the B3-only ledgers and stamps; keep only states/edges with no post-boundary finding",
        "B2_S1_states": len(stS), "B3_S1_projected_states": len(st3),
        "common_projected_states": len(commonS),
        "states_only_in_B2_S1": len(stS - st3), "states_only_in_B3_S1": len(st3 - stS),
        "edges_B3_has_B2S1_lacks_by_action": by_action(rel3),
        "edges_B2S1_has_B3_lacks_by_action": by_action(res3),
        "new_actions": new_actions,
        "intended_difference": "only recontain_* edges change (current evaluations expire); every other B2_S1 edge is kept",
        "differences_from_common_states_confined_to_recontain": all(a.startswith("recontain") for _, a, _ in rel3 | res3),
    }
    # B3_S1 epoch-0, pre-recontainment layer vs B2_S1 epoch-0 layer
    e3 = MS.fields.index("epoch")
    lay = lambda R, M: {i for i in range(len(R.keys)) if R.keys[i][M.fields.index("epoch")] == 0}
    L3, LS = lay(R3, M3), lay(RS, MS)
    ek3 = {(project_key(R3, s, drop3), R3.names[a], project_key(R3, d, drop3)) for s, a, d in R3.edges
           if s in L3 and d in L3 and R3.names[a] in names_s and nopb(R3.keys[s]) and nopb(R3.keys[d])}
    ekS = {(project_key(RS, s, dropS), RS.names[a], project_key(RS, d, dropS)) for s, a, d in RS.edges
           if s in LS and d in LS}
    out["B3_S1_vs_B2_S1"]["epoch0_layer_identical_on_B2_S1_actions"] = (ek3 == ekS)
    out["B3_S1_vs_B2_S1"]["epoch0_layer_edges"] = [len(ekS), len(ek3)]
    return out


def project_key(R, i, drop):
    k = R.keys[i]
    return tuple(v for j, v in enumerate(k) if j not in drop)


# ---------------------------------------------------------------- 4. survivors
SURV_PATTERNS = [
    ("preserve_evidence: _set_once requirement 'currently_contained'", "evidence may be preserved while not contained"),
    ("notify_affected_people: _set_once requirement 'containment_initiated'", "notice may precede containment"),
    ("record_function_continuation: whole early-return `if not (state.remedy_opened)`", "disposition may precede remedy path"),
    ("record_function_abolition: whole early-return `if not (state.remedy_opened)`", "disposition may precede remedy path"),
    ("establish_restart_basis: _set_once requirement 'containment_initiated'", "restart basis may precede containment"),
    ("approve_containment_release: conjunct 'verification_guard'", "release approval without independent verification"),
    ("approve_containment_release: conjunct 'fallback_guard'", "release approval without fallback"),
    ("approve_redeployment: conjunct 'verification_guard'", "redeployment approval without independent verification"),
    ("approve_redeployment: conjunct 'fallback_guard'", "redeployment approval without fallback"),
]

CANDIDATES = {
    "C1_evidence_requires_containment_initiated": lambda d: d["evidence_preserved"] and not d["containment_initiated"],
    "C2_notice_requires_containment_initiated": lambda d: d["affected_people_notified"] and not d["containment_initiated"],
    "C3_function_disposition_requires_remedy_path": lambda d: str(getattr(d["function_disposition"], "value", d["function_disposition"])) != "UNDECIDED" and not d["remedy_opened"],
    "C4_restart_basis_requires_containment_initiated": lambda d: d["restart_basis_established"] and not d["containment_initiated"],
    "C5_release_approval_requires_verified_basis_and_fallback": lambda d: (d["containment_release_approval_recorded"] or d["containment_release_approval_current"])
        and not (d["restart_basis_independently_verified"] and d["fallback_ready"]),
    "C6_redeployment_approval_requires_verified_basis_and_fallback": lambda d: (d["redeployment_approval_recorded"] or d["redeployment_approval_current"])
        and not (d["restart_basis_independently_verified"] and d["fallback_ready"]),
}


def survivors(src, kinds=("B2_S1", "B3_S1")):
    H = C.load_module(src, "hist_surv")
    funcs = {tr.__name__ for _, tr in H.EXIT_TRANSITIONS}
    am = C.ast_mutants(src, funcs)
    out = {}
    for kind in kinds:
        M, R = explore_kind(kind, src, "sb_" + kind)
        D = [s.__dict__ for s in R.states]
        base_keys = set(R.keys)
        base_edges = C.labeled_edge_set(R)
        base_cand = {c: sum(1 for d in D if f(d)) for c, f in CANDIDATES.items()}
        cats = {"closed": lambda d: d["closed"], "decommissioned": lambda d: d["decommissioned"],
                "released": lambda d: d["containment_released"], "redeployed": lambda d: d["redeployed_after_closure"]}
        base_cat_keys = {c: {R.keys[i] for i in range(len(D)) if f(D[i])} for c, f in cats.items()}
        rows = []
        for pat, meaning in SURV_PATTERNS:
            lab, msrc = next((l, s) for l, s in am if pat in l)
            Mm, Rm = explore_kind(kind, msrc, "sm", None)
            Dm = [s.__dict__ for s in Rm.states]
            es = C.labeled_edge_set(Rm)
            row = {"label": lab, "meaning": meaning,
                   "violations_of_any_checker_or_added_invariant": Rm.violating_states + Rm.violating_edges,
                   "extra_states": len(set(Rm.keys) - base_keys), "missing_states": len(base_keys - set(Rm.keys)),
                   "extra_edges": len(es - base_edges), "missing_edges": len(base_edges - es),
                   "extra_edges_by_action": dict(Counter(a for _, a, _ in (es - base_edges))),
                   "candidate_invariant_violations_in_mutant": {c: sum(1 for d in Dm if f(d)) for c, f in CANDIDATES.items()}}
            row["new_states_in_category"] = {
                c: len({Rm.keys[i] for i in range(len(Dm)) if f(Dm[i])} - base_cat_keys[c]) for c, f in cats.items()}
            # closure still reachable from every authorized state?
            succ, pred = C.build_adj(Rm)
            can = C.back_reach(pred, [i for i in range(len(Dm)) if Dm[i]["closed"]])
            row["P1_violations"] = sum(1 for i in range(len(Dm)) if Dm[i]["retirement_decision_authorized"]
                                       and not Dm[i]["closed"] and not can[i])
            rows.append(row)
        out[kind] = {"baseline_candidate_invariant_violations": base_cand, "mutants": rows}
    return out


# ---------------------------------------------------------------- 6. traces
def replay(M, R, trace):
    """replay an action list from the initial state through the model's own transition functions."""
    names = [n for n, _ in M.transitions]
    fn = dict(M.transitions)
    s = M.init
    states = [s]
    for a in trace:
        n = fn[a](s, None)
        assert n is not None, f"action {a} not enabled"
        s = n
        states.append(s)
    return states


def key_flags(d):
    ks = ("currently_contained", "containment_released", "recontained", "epoch",
          "containment_release_approval_recorded", "restart_basis_established", "evidence_preserved",
          "retirement_decision_authorized", "post_exit_responsibility_resolved", "open_case_owner_assigned",
          "decommissioned", "closed", "harm_assessment", "case_inventory", "remedy_initiated")
    return {k: (getattr(d[k], "value", d[k])) for k in ks}


def traces(src):
    out = {}
    for kind in ("B2", "B2_S1", "B3_S1"):
        M, R = explore_kind(kind, src, "tr_" + kind)
        succ, _ = C.build_adj(R)
        D = [s.__dict__ for s in R.states]
        cases = {}

        def add(label, pred, exclude=frozenset()):
            t, i = C.bfs_excluding(R, succ, pred, exclude=exclude)
            if t is None:
                cases[label] = None
                return
            states = replay(M, R, t)
            first = next((j for j, a in enumerate(t) if a.startswith("recontain")), None)
            entry = {"length": len(t), "trace": t, "final_state": C.fmt_state(R.states[i]),
                     "violations_along_trace": [x for s in states for x in M.inv_state(s)]
                                              + [x for a, b, c in zip(states, t, states[1:]) for x in (M.inv_edge(a, b, c) or [])]}
            if first is not None:
                entry["state_before_recontain"] = key_flags(states[first].__dict__)
                entry["state_after_recontain"] = key_flags(states[first + 1].__dict__)
            cases[label] = entry

        base = lambda d: d["closed"] and d["recontained"]
        add("recontain_service_preserving_RESOLUTION_COLLAPSE", lambda d: base(d) and d["retirement_basis"].value == "RESOLUTION_COLLAPSE",
            exclude={"recontain_emergency_safe_stop"})
        add("recontain_service_preserving_OTHER_AUTHORIZED_BASIS", lambda d: base(d) and d["retirement_basis"].value == "OTHER_AUTHORIZED_BASIS",
            exclude={"recontain_emergency_safe_stop"})
        add("recontain_emergency_safe_stop", lambda d: base(d), exclude={"recontain_service_preserving"})
        if kind != "B2":
            add("harm_NONE_cases_NONE", lambda d: base(d) and d["harm_assessment"] == "NONE" and d["case_inventory"] == "NONE")
            add("harm_FOUND_cases_EXIST", lambda d: base(d) and d["harm_assessment"] == "FOUND" and d["case_inventory"] == "EXIST")
        if kind == "B3_S1":
            add("harm_found_before_recontain_then_NONE_after_(history_kept_in_ledger)",
                lambda d: base(d) and d["led_harm_found"] and d["harm_assessment"] == "NONE" and d["led_remedy_init"])
            add("cases_existed_before_recontain_then_inventory_EXIST_again",
                lambda d: base(d) and d["led_cases_exist"] and d["case_inventory"] == "EXIST" and d["open_case_owner_assigned"])
            add("post_boundary_case_after_closure_then_owner",
                lambda d: d["closed"] and d["post_boundary_case"] and d["open_case_owner_assigned"] and d["recontained"])
            add("post_boundary_harm_after_closure_then_remedy",
                lambda d: d["closed"] and d["post_boundary_harm"] and d["remedy_initiated"] and d["recontained"])
        out[kind] = cases
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["compat", "survivors", "traces", "all"])
    ap.add_argument("--checker", type=Path, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    a = ap.parse_args()
    a.outdir.mkdir(parents=True, exist_ok=True)
    raw = a.checker.read_bytes()
    src = raw.decode("utf-8")
    meta = {"checker_sha256": hashlib.sha256(raw).hexdigest()}
    for name, fn in (("compat", compat), ("survivors", survivors), ("traces", traces)):
        if a.cmd in (name, "all"):
            res = fn(src)
            res["_meta"] = meta
            (a.outdir / f"followup_{name}.json").write_text(json.dumps(res, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
            print(name, "done")


if __name__ == "__main__":
    main()
