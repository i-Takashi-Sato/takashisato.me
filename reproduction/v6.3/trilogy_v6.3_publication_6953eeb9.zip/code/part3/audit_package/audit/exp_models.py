#!/usr/bin/env python3
"""Experimental models built ON TOP of the unmodified historical v5.9 checker.

The historical source text is exec'd into a private namespace; its ExitState and
its 29 transition functions are reused unchanged (wrapped, never edited).  New
behaviour lives only in this file.

Kinds
  M0     replica: historical transitions + bookkeeping fields (ledgers, approval
         stamps).  Must reproduce 8,564 states / 36,096 transitions and the
         historical labeled edge set (checked in the driver).
  A      single-episode boundary made strict.  A temporary release ENDS the
         episode: every historical action is disabled afterwards except
         begin_new_episode.  A later retirement is a NEW episode (bounded by
         EP_MAX new episodes).  Episode-scoped state is reset; environmental
         facts (fallback_ready, emergency authority) and monotone ledgers carry.
  B      explicit re-containment.  After a temporary release, an authorized
         retirement may be followed by recontain_service_preserving /
         recontain_emergency_safe_stop, restoring currently_contained.  Nothing is
         reset except the release approval chain and the restart basis (both
         stale after re-containment); history/obligation flags are monotone.
  *_S1   planned-retirement refinement (layered on M0 or B2), splitting the single
         remedy_opened notion into four concerns:
           remedy_opened              := remedy PATH secured (kept name, new meaning)
           harm_assessment            := UNASSESSED / NONE / FOUND (authorized finding)
           remedy_initiated           := remedy actually begun for FOUND harm
           case_inventory             := UNVERIFIED / NONE / EXIST (verified absence
                                          or presence of unresolved cases)
           open_case_owner_assigned   := responsibility succession for EXIST cases
         Two historical rules are re-implemented for S1 (resolve_post_exit_responsibility
         and the case-owner precondition); one historical invariant is replaced.

A_S1 is NOT built (see report): carrying harm/inventory obligations across an
episode boundary needs design decisions beyond the requested comparison.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

import audit_core as C

EP_MAX = 1  # at most one NEW episode after the first (model A)
KINDS_ALL = ("M0", "A", "B", "B2", "M0_S1", "B2_S1", "B3_S1")

LEDGERS = ("led_remedy", "led_owner", "led_evidence", "led_party", "led_released")
LEDGERS_B3 = ("led_harm_found", "led_remedy_init", "led_cases_exist")
HISTORY_MONO = (
    "evidence_preserved", "affected_people_notified", "remedy_opened",
    "proper_ending_authority_recorded", "retirement_decision_authorized",
    "accepting_successor_recorded", "residual_custodian_recorded",
    "successor_operational_capacity_ready", "open_case_owner_assigned",
    "post_exit_responsibility_resolved", "decommissioned", "independently_assured",
    "closed", "containment_initiated", "emergency_safe_stop_used",
    "emergency_safe_stop_authorized", "fallback_ready",
)
REL_APPROVAL_FLAGS = (
    "containment_release_approval_recorded", "containment_release_approval_current",
    "containment_release_approval_valid_at_execution",
    "containment_release_no_retirement_decision_at_execution",
)
RED_APPROVAL_FLAGS = (
    "redeployment_approval_recorded", "redeployment_approval_current",
    "redeployment_approval_valid_at_execution",
)
RESTART_FLAGS = ("restart_basis_established", "restart_basis_independently_verified")

NEW_ACTIONS = {
    "A": ["begin_new_episode"],
    "B": ["recontain_service_preserving", "recontain_emergency_safe_stop"],
    "S1": ["assess_harm_none", "assess_harm_found", "inventory_cases_none",
           "inventory_cases_exist", "initiate_remedy_for_harm",
           "late_case_discovered", "late_harm_discovered"],
}

NAMED_MUTANTS = {
    "B3": [
        "recontain_keeps_harm_assessment", "recontain_keeps_remedy_initiation",
        "recontain_keeps_case_inventory", "recontain_keeps_owner", "recontain_keeps_resolution",
        "recontain_drops_harm_ledger", "inventory_none_despite_prior_cases",
        "close_without_prior_harm_remedy", "close_with_open_post_boundary_finding",
        "pb_case_before_decommission", "pb_harm_before_decommission",
    ],
    "A": [
        "new_episode_without_release", "episode_gate_removed",
        "new_episode_keeps_release_approval", "new_episode_keeps_redeploy_approval",
        "new_episode_keeps_restart_basis", "new_episode_drops_ledger",
        "new_episode_drops_fallback", "new_episode_carries_evidence_flag",
        "new_episode_carries_remedy_flag",
    ],
    "B": [
        "recontain_without_release", "recontain_without_retirement_decision",
        "recontain_without_fallback", "recontain_emergency_without_authority",
        "recontain_keeps_release_approval", "recontain_keeps_restart_basis",
        "recontain_clears_evidence", "recontain_clears_remedy",
        "recontain_clears_owner_and_resolution", "recontain_after_decommission",
        "recontain_no_epoch_bump",
    ],
    "S1": [
        "assess_without_evidence", "inventory_without_evidence",
        "initiate_remedy_without_harm_found", "initiate_remedy_without_path",
        "assign_owner_without_cases", "resolve_without_inventory",
        "resolve_exist_without_owner", "close_without_harm_assessment",
        "close_without_inventory", "close_harm_found_without_remedy_initiation",
        "close_cases_exist_without_owner", "late_case_keeps_resolved",
        "late_case_after_decommission", "late_harm_after_closure",
    ],
}


def build(kind: str, hist_src: str, tag: str = "x") -> C.Model:
    assert kind in KINDS_ALL, kind
    fam_a = kind == "A"
    fam_b = kind in ("B", "B2", "B2_S1", "B3_S1")
    fresh_evidence = kind in ("A", "B2", "B2_S1", "B3_S1")   # evidence must be re-preserved per episode/containment generation
    b2 = kind in ("B2", "B2_S1", "B3_S1")
    b3 = kind == "B3_S1"     # B2_S1 + current-evaluation expiry at re-containment + bounded post-boundary findings
    s1 = kind.endswith("S1")
    H = C.load_module(hist_src, f"hist_{tag}_{kind}")

    @dataclass(frozen=True)
    class XState(H.ExitState):
        epoch: int = 0
        led_remedy: bool = False
        led_owner: bool = False
        led_evidence: bool = False
        led_party: bool = False
        led_released: bool = False
        rel_appr_epoch: int = -1
        red_appr_epoch: int = -1
        evid_epoch: int = -1
        recontained: bool = False
        led_harm_found: bool = False
        led_remedy_init: bool = False
        led_cases_exist: bool = False
        harm_epoch: int = -1
        inv_epoch: int = -1
        post_boundary_case: bool = False
        post_boundary_harm: bool = False
        harm_assessment: str = "UNASSESSED"
        remedy_initiated: bool = False
        case_inventory: str = "UNVERIFIED"

    FD = H.FunctionDisposition
    RB = H.RetirementBasis

    # ------------------------------------------------------------ bookkeeping
    def post(s, n):
        upd = {}
        if n.remedy_opened and not n.led_remedy:
            upd["led_remedy"] = True
        if n.open_case_owner_assigned and not n.led_owner:
            upd["led_owner"] = True
        if n.evidence_preserved and not n.led_evidence:
            upd["led_evidence"] = True
        if (n.accepting_successor_recorded or n.residual_custodian_recorded) and not n.led_party:
            upd["led_party"] = True
        if n.containment_released and not n.led_released:
            upd["led_released"] = True
        if n.containment_release_approval_recorded and not s.containment_release_approval_recorded:
            upd["rel_appr_epoch"] = n.epoch
        if n.redeployment_approval_recorded and not s.redeployment_approval_recorded:
            upd["red_appr_epoch"] = n.epoch
        if n.evidence_preserved and not s.evidence_preserved:
            upd["evid_epoch"] = n.epoch
        if b3:
            if n.harm_assessment == "FOUND" and not n.led_harm_found:
                upd["led_harm_found"] = True
            if n.remedy_initiated and not n.led_remedy_init:
                upd["led_remedy_init"] = True
            if n.case_inventory == "EXIST" and not n.led_cases_exist:
                upd["led_cases_exist"] = True
            if n.harm_assessment != s.harm_assessment and n.harm_assessment != "UNASSESSED":
                upd["harm_epoch"] = n.epoch
            if n.case_inventory != s.case_inventory and n.case_inventory != "UNVERIFIED":
                upd["inv_epoch"] = n.epoch
        return replace(n, **upd) if upd else n

    def wrap(fn):
        def f(s, m):
            if fam_a and s.containment_released and m != "episode_gate_removed":
                return None
            n = fn(s, m)
            return None if n is None else post(s, n)
        return f

    # ------------------------------------------------------------ S1 overrides
    def s1_assign_owner(fn):
        def f(s, m):
            if (s.case_inventory != "EXIST" and not (b3 and s.post_boundary_case)
                    and m != "assign_owner_without_cases"):
                return None
            return fn(s, m)
        return f

    def s1_resolve(fn):
        def f(s, m):
            if s.post_exit_responsibility_resolved:
                return None
            if not s.remedy_opened or s.function_disposition == FD.UNDECIDED:
                return None
            if s.case_inventory == "UNVERIFIED" and m != "resolve_without_inventory":
                return None
            owner_ok = (s.case_inventory != "EXIST" or s.open_case_owner_assigned
                        or m == "resolve_exist_without_owner")
            if not owner_ok:
                return None
            if s.function_disposition == FD.CONTINUES:
                if not (s.accepting_successor_recorded and s.successor_operational_capacity_ready):
                    return None
            else:
                if not s.residual_custodian_recorded:
                    return None
            return replace(s, post_exit_responsibility_resolved=True)
        return f

    def s1_close(fn):
        def f(s, m):
            if s.harm_assessment == "UNASSESSED" and m != "close_without_harm_assessment":
                return None
            if s.case_inventory == "UNVERIFIED" and m != "close_without_inventory":
                return None
            if (s.harm_assessment == "FOUND" and not s.remedy_initiated
                    and m != "close_harm_found_without_remedy_initiation"):
                return None
            if (s.case_inventory == "EXIST" and not s.open_case_owner_assigned
                    and m != "close_cases_exist_without_owner"):
                return None
            if b3:
                if s.led_harm_found and not s.led_remedy_init and m != "close_without_prior_harm_remedy":
                    return None
                if ((s.post_boundary_case and not s.open_case_owner_assigned)
                        or (s.post_boundary_harm and not s.remedy_initiated)) \
                        and m != "close_with_open_post_boundary_finding":
                    return None
            return fn(s, m)
        return f

    overrides = {}
    if s1:
        overrides = {"assign_open_case_owner": s1_assign_owner,
                     "resolve_post_exit_responsibility": s1_resolve,
                     "close": s1_close}

    trs = []
    for name, fn in H.EXIT_TRANSITIONS:
        g = overrides[name](fn) if name in overrides else fn
        trs.append((name, wrap(g)))

    # ------------------------------------------------------------ model A
    def begin_new_episode(s, m):
        if not s.containment_released and m != "new_episode_without_release":
            return None
        if s.epoch >= EP_MAX:
            return None
        kw = dict(
            epoch=s.epoch + 1,
            fallback_ready=s.fallback_ready and m != "new_episode_drops_fallback",
            emergency_safe_stop_authorized=s.emergency_safe_stop_authorized,
            led_remedy=s.led_remedy, led_owner=s.led_owner, led_evidence=s.led_evidence,
            led_party=s.led_party, led_released=s.led_released,
        )
        if m == "new_episode_drops_ledger":
            kw.update(led_remedy=False, led_owner=False, led_evidence=False,
                      led_party=False, led_released=False)
        if m == "new_episode_keeps_release_approval":
            for f in REL_APPROVAL_FLAGS:
                kw[f] = getattr(s, f)
            kw["rel_appr_epoch"] = s.rel_appr_epoch
        if m == "new_episode_keeps_redeploy_approval":
            for f in RED_APPROVAL_FLAGS:
                kw[f] = getattr(s, f)
            kw["red_appr_epoch"] = s.red_appr_epoch
        if m == "new_episode_keeps_restart_basis":
            for f in RESTART_FLAGS:
                kw[f] = getattr(s, f)
        if m == "new_episode_carries_evidence_flag":
            kw["evidence_preserved"] = s.evidence_preserved
        if m == "new_episode_carries_remedy_flag":
            kw["remedy_opened"] = s.remedy_opened
        return XState(**kw)

    # ------------------------------------------------------------ model B
    def recontain(emergency):
        def f(s, m):
            if not s.containment_released and m != "recontain_without_release":
                return None
            if not s.retirement_decision_authorized and m != "recontain_without_retirement_decision":
                return None
            if s.decommissioned and m != "recontain_after_decommission":
                return None
            if emergency:
                if not (s.emergency_safe_stop_authorized or m == "recontain_emergency_without_authority"):
                    return None
            else:
                if not (s.fallback_ready or m == "recontain_without_fallback"):
                    return None
            kw = dict(
                currently_contained=True, containment_released=False, recontained=True,
                epoch=s.epoch if m == "recontain_no_epoch_bump" else s.epoch + 1,
                emergency_safe_stop_used=s.emergency_safe_stop_used or emergency,
            )
            if m != "recontain_keeps_release_approval":
                for fl in REL_APPROVAL_FLAGS:
                    kw[fl] = False
            if m != "recontain_keeps_restart_basis":
                for fl in RESTART_FLAGS:
                    kw[fl] = False
            if m == "recontain_clears_evidence" or (b2 and m != "recontain_keeps_evidence_flag"):
                kw["evidence_preserved"] = False
            if m == "recontain_clears_remedy":
                kw["remedy_opened"] = False
            if m == "recontain_clears_owner_and_resolution":
                kw["open_case_owner_assigned"] = False
                kw["post_exit_responsibility_resolved"] = False
            if b3:   # current evaluations expire; history is kept in ledgers
                if m != "recontain_keeps_harm_assessment":
                    kw["harm_assessment"] = "UNASSESSED"
                if m != "recontain_keeps_remedy_initiation":
                    kw["remedy_initiated"] = False
                if m != "recontain_keeps_case_inventory":
                    kw["case_inventory"] = "UNVERIFIED"
                if m != "recontain_keeps_owner":
                    kw["open_case_owner_assigned"] = False
                if m != "recontain_keeps_resolution":
                    kw["post_exit_responsibility_resolved"] = False
                if m == "recontain_drops_harm_ledger":
                    kw["led_harm_found"] = False
            n = replace(s, **kw)
            return post(s, n)
        return f

    # ------------------------------------------------------------ S1 actions
    def assess(val):
        def f(s, m):
            if s.harm_assessment != "UNASSESSED":
                return None
            if not s.evidence_preserved and m != "assess_without_evidence":
                return None
            return replace(s, harm_assessment=val)
        return f

    def inventory(val):
        def f(s, m):
            if s.case_inventory != "UNVERIFIED":
                return None
            if not s.evidence_preserved and m != "inventory_without_evidence":
                return None
            if b3 and val == "NONE" and s.led_cases_exist and m != "inventory_none_despite_prior_cases":
                return None
            return replace(s, case_inventory=val)
        return f

    def initiate_remedy(s, m):
        if s.remedy_initiated:
            return None
        if (s.harm_assessment != "FOUND" and not (b3 and s.post_boundary_harm)
                and m != "initiate_remedy_without_harm_found"):
            return None
        if not s.remedy_opened and m != "initiate_remedy_without_path":
            return None
        return replace(s, remedy_initiated=True)

    def late_case(s, m):
        if s.case_inventory != "NONE":
            return None
        if s.decommissioned and m != "late_case_after_decommission":
            return None
        upd = dict(case_inventory="EXIST")
        if m != "late_case_keeps_resolved":
            upd["post_exit_responsibility_resolved"] = False
        return replace(s, **upd)

    def late_harm(s, m):
        if s.harm_assessment != "NONE":
            return None
        if s.closed and m != "late_harm_after_closure":
            return None
        return replace(s, harm_assessment="FOUND")

    def pb_case(s, m):
        if s.post_boundary_case or (not s.decommissioned and m != "pb_case_before_decommission"):
            return None
        return replace(s, post_boundary_case=True)

    def pb_harm(s, m):
        if s.post_boundary_harm or (not s.decommissioned and m != "pb_harm_before_decommission"):
            return None
        return replace(s, post_boundary_harm=True)

    if fam_a:
        trs.append(("begin_new_episode", begin_new_episode))
    if fam_b:
        trs.append(("recontain_service_preserving", recontain(False)))
        trs.append(("recontain_emergency_safe_stop", recontain(True)))
    if s1:
        extra = [("assess_harm_none", assess("NONE")), ("assess_harm_found", assess("FOUND")),
                 ("inventory_cases_none", inventory("NONE")),
                 ("inventory_cases_exist", inventory("EXIST")),
                 ("initiate_remedy_for_harm", initiate_remedy),
                 ("late_case_discovered", late_case), ("late_harm_discovered", late_harm)]
        if b3:
            extra += [("post_boundary_case_discovered", pb_case), ("post_boundary_harm_discovered", pb_harm)]
        for name, fn in extra:
            trs.append((name, wrap(fn)))

    # ------------------------------------------------------------ invariants
    dropped = set()
    if s1:
        dropped.add("post_exit_responsibility_requires_branch_specific_owner_capacity_and_case_ownership")

    def extra_state(s):
        v = []
        if ((s.remedy_opened and not s.led_remedy) or (s.open_case_owner_assigned and not s.led_owner)
                or (s.evidence_preserved and not s.led_evidence)
                or ((s.accepting_successor_recorded or s.residual_custodian_recorded) and not s.led_party)
                or (s.containment_released and not s.led_released)):
            v.append("X:ledger_covers_current_flags")
        if (s.containment_release_approval_current or s.containment_release_approval_valid_at_execution) \
                and s.rel_appr_epoch != s.epoch:
            v.append("X:release_approval_stale_across_epoch")
        if (s.redeployment_approval_current or s.redeployment_approval_valid_at_execution) \
                and s.red_appr_epoch != s.epoch:
            v.append("X:redeployment_approval_stale_across_epoch")
        if fresh_evidence and s.evidence_preserved and s.evid_epoch != s.epoch:
            v.append("X:evidence_stale_across_epoch")
        if s.closed and ((s.led_remedy and not s.remedy_opened) or (s.led_owner and not s.open_case_owner_assigned)):
            v.append("X:closure_must_discharge_carried_obligations")
        if fam_a:
            if s.epoch > 0 and not s.led_released:
                v.append("X:new_episode_only_after_release")
            if s.epoch > EP_MAX:
                v.append("X:episode_bound_exceeded")
        if fam_b:
            if s.recontained and not (s.led_released and s.retirement_decision_authorized
                                      and s.containment_initiated):
                v.append("X:recontainment_requires_release_history_and_retirement_decision")
            if s.recontained and not (s.currently_contained and not s.containment_released):
                v.append("X:recontained_state_must_be_contained_and_unreleased")
            if s.recontained and (s.containment_release_approval_recorded
                                  or s.containment_release_approval_current
                                  or s.containment_release_approval_valid_at_execution):
                v.append("X:recontained_state_carries_release_approval")
            if s.epoch != (1 if s.recontained else 0):
                v.append("X:epoch_must_track_recontainment")
        if s1:
            if s.harm_assessment != "UNASSESSED" and not s.led_evidence:
                v.append("S1:harm_assessment_requires_preserved_evidence_history")
            if s.case_inventory != "UNVERIFIED" and not s.led_evidence:
                v.append("S1:case_inventory_requires_preserved_evidence_history")
            if b3:
                if (s.harm_assessment == "FOUND" and not s.led_harm_found) or (s.remedy_initiated and not s.led_remedy_init) \
                        or (s.case_inventory == "EXIST" and not s.led_cases_exist):
                    v.append("X:s1_ledger_covers_current_evaluation")
                if s.harm_assessment != "UNASSESSED" and s.harm_epoch != s.epoch:
                    v.append("X:harm_assessment_stale_across_epoch")
                if s.case_inventory != "UNVERIFIED" and s.inv_epoch != s.epoch:
                    v.append("X:case_inventory_stale_across_epoch")
                if s.closed and s.led_harm_found and not s.led_remedy_init:
                    v.append("S1:closed_requires_remedy_initiation_history_for_found_harm")
                if s.led_cases_exist and s.case_inventory == "NONE":
                    v.append("S1:prior_cases_cannot_be_declared_absent")
                if s.post_boundary_case or s.post_boundary_harm:
                    party = (s.accepting_successor_recorded and s.successor_operational_capacity_ready
                             if s.function_disposition == FD.CONTINUES
                             else s.residual_custodian_recorded if s.function_disposition == FD.ABOLISHED else False)
                    if not (s.decommissioned and s.post_exit_responsibility_resolved and s.remedy_opened and party):
                        v.append("S1:post_boundary_finding_requires_decommission_resolved_responsibility_and_party")
            if s.closed and s.harm_assessment == "UNASSESSED":
                v.append("S1:closed_requires_harm_assessment")
            if s.closed and s.case_inventory == "UNVERIFIED":
                v.append("S1:closed_requires_case_inventory")
            if s.closed and s.harm_assessment == "FOUND" and not s.remedy_initiated:
                v.append("S1:closed_requires_remedy_initiation_for_found_harm")
            if s.closed and s.case_inventory == "EXIST" and not s.open_case_owner_assigned:
                v.append("S1:closed_requires_owner_for_existing_cases")
            if s.remedy_initiated and not ((s.harm_assessment == "FOUND" or (b3 and s.post_boundary_harm))
                                           and s.remedy_opened):
                v.append("S1:remedy_initiation_requires_found_harm_and_secured_path")
            if s.open_case_owner_assigned and s.case_inventory != "EXIST" and not (b3 and s.post_boundary_case):
                v.append("S1:owner_only_for_existing_cases")
            if s.post_exit_responsibility_resolved:
                branch = (s.accepting_successor_recorded and s.successor_operational_capacity_ready
                          if s.function_disposition == FD.CONTINUES
                          else s.residual_custodian_recorded if s.function_disposition == FD.ABOLISHED
                          else False)
                ok = (s.remedy_opened and branch and s.case_inventory != "UNVERIFIED"
                      and (s.case_inventory != "EXIST" or s.open_case_owner_assigned))
                if not ok:
                    v.append("S1:responsibility_resolution_requires_path_branch_inventory_and_owner_if_cases")
        return v

    def inv_state(s):
        v = [n for n in H.exit_invariant_violations(s) if n not in dropped]
        v.extend(extra_state(s))
        return v

    def inv_edge(s, name, n):
        v = []
        d0, d1 = s.__dict__, n.__dict__
        for f in LEDGERS + (LEDGERS_B3 if b3 else ()):
            if d0[f] and not d1[f]:
                v.append(f"X:ledger_erased:{f}")
        if not fam_a:
            for f in HISTORY_MONO:
                if d0[f] and not d1[f]:
                    if name == "late_case_discovered" and f == "post_exit_responsibility_resolved":
                        continue
                    if b3 and name.startswith("recontain") and f in ("open_case_owner_assigned",
                                                                     "post_exit_responsibility_resolved"):
                        continue   # B3: current owner/resolution expire at re-containment; history in led_owner / re-resolution
                    if b2 and name.startswith("recontain") and f == "evidence_preserved":
                        continue   # B2: evidence flag is per containment generation; history lives in led_evidence
                    v.append(f"X:history_erased:{f}")
            if d0["retirement_basis"] != RB.UNRECORDED and d1["retirement_basis"] == RB.UNRECORDED:
                v.append("X:history_erased:retirement_basis")
            if d0["function_disposition"] != FD.UNDECIDED and d1["function_disposition"] == FD.UNDECIDED:
                v.append("X:history_erased:function_disposition")
        if name.startswith("recontain"):
            if any(d1[f] for f in REL_APPROVAL_FLAGS):
                v.append("X:recontain_leaves_stale_release_approval")
            if any(d1[f] for f in RESTART_FLAGS):
                v.append("X:recontain_leaves_stale_restart_basis")
        if name == "begin_new_episode":
            if any(d1[f] for f in REL_APPROVAL_FLAGS):
                v.append("X:new_episode_carries_release_approval")
            if any(d1[f] for f in RED_APPROVAL_FLAGS):
                v.append("X:new_episode_carries_redeployment_approval")
            if any(d1[f] for f in RESTART_FLAGS):
                v.append("X:new_episode_carries_restart_basis")
            if d1["containment_released"] or d1["closed"] or d1["decommissioned"]:
                v.append("X:new_episode_carries_terminal_status")
        if s1 and not (b3 and name.startswith("recontain")):
            if d0["remedy_initiated"] and not d1["remedy_initiated"]:
                v.append("S1:remedy_initiation_erased")
            if d0["harm_assessment"] != "UNASSESSED" and d1["harm_assessment"] in ("UNASSESSED",):
                v.append("S1:harm_assessment_erased")
            if d0["harm_assessment"] == "FOUND" and d1["harm_assessment"] != "FOUND":
                v.append("S1:found_harm_erased")
            if d0["case_inventory"] == "EXIST" and d1["case_inventory"] != "EXIST":
                v.append("S1:existing_cases_erased")
            if d0["case_inventory"] != "UNVERIFIED" and d1["case_inventory"] == "UNVERIFIED":
                v.append("S1:inventory_erased")
        if b3:
            if name == "close" and ((s.post_boundary_case and not s.open_case_owner_assigned)
                                    or (s.post_boundary_harm and not s.remedy_initiated)):
                v.append("S1:closure_with_open_post_boundary_finding")
            if name.startswith("post_boundary"):
                changed = [f for f in d0 if f not in ("post_boundary_case", "post_boundary_harm") and d0[f] != d1[f]]
                if changed:
                    v.append("S1:post_boundary_event_must_not_reopen_or_alter_state")
            if name.startswith("recontain"):
                if d1["harm_assessment"] != "UNASSESSED" or d1["case_inventory"] != "UNVERIFIED" \
                        or d1["remedy_initiated"] or d1["open_case_owner_assigned"] \
                        or d1["post_exit_responsibility_resolved"]:
                    v.append("S1:recontain_leaves_stale_current_evaluation")
        return v

    # ------------------------------------------------------------ terminal classes
    def classify_terminal(d):
        if d["closed"] and d["redeployed_after_closure"]:
            return "complete(closed+redeployed)"
        if fam_a and d["containment_released"] and d["epoch"] >= EP_MAX:
            return "episode_budget_exhausted_after_release(abstraction bound)"
        return "DEFECT_terminal"

    import dataclasses
    fields = [f.name for f in dataclasses.fields(XState)]
    meta = {"kind": kind, "classify_terminal": classify_terminal, "XState": XState,
            "ep_max": EP_MAX if fam_a else None, "hist": H}
    return C.Model(kind, XState(), trs, inv_state, inv_edge, fields, meta)


def named_mutants_for(kind: str) -> list[str]:
    out = []
    if kind == "A":
        out += NAMED_MUTANTS["A"]
    if kind in ("B", "B2", "B2_S1", "B3_S1"):
        out += NAMED_MUTANTS["B"]
    if kind in ("B2", "B2_S1", "B3_S1"):
        out += ["recontain_keeps_evidence_flag"]
    if kind.endswith("S1"):
        out += NAMED_MUTANTS["S1"]
    if kind == "B3_S1":
        out += NAMED_MUTANTS["B3"]
    return out
