#!/usr/bin/env python3
"""Counterexample / witness paths for the audit report.  Read-only use of the checker.

usage: scenario_traces.py <formal_protocol_checks.py> <out.json>   (stranded-path witness for the historical model; M0/B/A walkthroughs)
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import audit_core as C  # noqa: E402
import exp_models as E  # noqa: E402

src = Path(sys.argv[1]).read_text(encoding="utf-8")
out = {}

# 1. the stranded path in the historical model (M0)
M0 = E.build("M0", src, "s0")
R0 = C.explore(M0)
D0 = [s.__dict__ for s in R0.states]
stranded = next(i for i, d in enumerate(D0) if d["retirement_decision_authorized"] and d["containment_released"])
stranded_trace = C.trace_of(R0, stranded)
succ0, pred0 = C.build_adj(R0)
out["M0_stranded_trace"] = stranded_trace
out["M0_stranded_state"] = C.fmt_state(R0.states[stranded])
out["M0_enabled_actions_in_stranded_state"] = [R0.names[a] for a, _ in succ0[stranded]]
# the 12 states that satisfy every closure prerequisite except current containment
twelve = [i for i, d in enumerate(D0)
          if d["retirement_decision_authorized"] and d["containment_released"] and d["post_exit_responsibility_resolved"]
          and d["evidence_preserved"] and d["affected_people_notified"] and d["remedy_opened"]]
out["M0_states_with_all_non_containment_prerequisites_met_and_released"] = len(twelve)
if twelve:
    out["M0_example_of_those"] = {"trace": C.trace_of(R0, twelve[0]), "state": C.fmt_state(R0.states[twelve[0]]),
                                  "enabled_actions": [R0.names[a] for a, _ in succ0[twelve[0]]]}

# 2. model B: same prefix, then continue to closure
MB = E.build("B", src, "sB")
RB = C.explore(MB)
succB, _ = C.build_adj(RB)
idx = {k: i for i, k in enumerate(RB.keys)}
cur = 0
for act in stranded_trace:
    ai = RB.names.index(act)
    cur = next(d for a, d in succB[cur] if a == ai)
tail, tail_state = C.bfs_excluding(RB, succB, lambda d: d["closed"], start=cur)
out["B_same_prefix_then_closure"] = {
    "prefix_equals_M0_stranded_trace": True,
    "state_after_prefix": C.fmt_state(RB.states[cur]),
    "continuation": tail,
    "closing_state": C.fmt_state(RB.states[tail_state]),
}
# B: audit the post-closure state for stale approval / erased history
d = RB.states[tail_state].__dict__
out["B_closing_state_checks"] = {
    k: d[k] for k in ("recontained", "epoch", "currently_contained", "containment_released",
                      "containment_release_approval_recorded", "containment_release_approval_valid_at_execution",
                      "restart_basis_established", "evidence_preserved", "remedy_opened",
                      "open_case_owner_assigned", "post_exit_responsibility_resolved", "led_released")}

# 3. model A: release, then a NEW episode, then closure
MA = E.build("A", src, "sA")
RA = C.explore(MA)
succA, _ = C.build_adj(RA)
prefix = [a for a in stranded_trace if a != "authorize_proper_ending"][:]
# prefix up to and including release_containment (authorize is the last action of the stranded trace)
prefix = stranded_trace[:-1]
cur = 0
for act in prefix:
    ai = RA.names.index(act)
    cur = next(d for a, d in succA[cur] if a == ai)
enabled_after_release = [RA.names[a] for a, _ in succA[cur]]
out["A_state_after_release"] = {"state": C.fmt_state(RA.states[cur]), "enabled_actions": enabled_after_release}
bn = RA.names.index("begin_new_episode")
cur2 = next(d for a, d in succA[cur] if a == bn)
tailA, tailA_state = C.bfs_excluding(RA, succA, lambda d: d["closed"], start=cur2)
out["A_new_episode_then_closure"] = {
    "state_after_begin_new_episode": C.fmt_state(RA.states[cur2]),
    "continuation_to_closure": tailA,
    "closing_state": C.fmt_state(RA.states[tailA_state]),
}

# 4. model A: what a retirement attempted directly after release looks like (not allowed in epoch 0)
out["A_authorize_after_release_enabled"] = "authorize_proper_ending" in enabled_after_release

# 5. model A: shortest closure inside the second episode and total path
# 6. S1 late-discovery scenarios (targeted search; BFS-tree traces never contain these events)
for kind in ("M0_S1", "B2_S1"):
    MS = E.build(kind, src, "s_" + kind)
    RS = C.explore(MS)
    succS, _ = C.build_adj(RS)
    DS = [s.__dict__ for s in RS.states]
    lc = RS.names.index("late_case_discovered")
    lh = RS.names.index("late_harm_discovered")
    res = {}
    # late case after responsibility was resolved (verified-NONE becomes stale), before decommission
    start = next((i for i, d in enumerate(DS) if d["case_inventory"] == "NONE"
                  and d["post_exit_responsibility_resolved"] and not d["decommissioned"]
                  and d["retirement_decision_authorized"]), None)
    if start is not None:
        nxt = next((d for a, d in succS[start] if a == lc), None)
        if nxt is not None:
            tail, ts = C.bfs_excluding(RS, succS, lambda d: d["closed"], start=nxt)
            res["late_case_after_resolution"] = {
                "prefix": C.trace_of(RS, start), "event": "late_case_discovered",
                "state_after_event": C.fmt_state(RS.states[nxt]),
                "continuation_to_closure": tail}
    # late harm after decommission, before closure
    start = next((i for i, d in enumerate(DS) if d["harm_assessment"] == "NONE" and d["decommissioned"]
                  and not d["closed"]), None)
    if start is not None:
        nxt = next((d for a, d in succS[start] if a == lh), None)
        if nxt is not None:
            tail, ts = C.bfs_excluding(RS, succS, lambda d: d["closed"], start=nxt)
            res["late_harm_after_decommission"] = {
                "prefix": C.trace_of(RS, start), "event": "late_harm_discovered",
                "continuation_to_closure": tail}
    out["S1_late_discovery_" + kind] = res

Path(sys.argv[2]).write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
print(json.dumps(out, indent=1, ensure_ascii=False)[:6000])
