"""Compare re-executed results with the recorded results of the v6.3 release.

Usage: python3 -I compare_results.py RECORDED_DIR RERUN_DIR --mode quick|full

Every artifact required for the chosen mode must exist in both directories and match;
otherwise the script exits with status 1. JSON files are compared after removing timing
fields only; CSV, Markdown and other files are compared byte for byte. Recorded files that
are not required in the chosen mode are reported as NOT RUN and do not fail the check.
"""
import json, sys
from pathlib import Path

REQUIRED_QUICK = [
    'part1_v63_candidate.json', 'part1_acceptance.json', 'gate3_regression.json',
    'part1_integrated_model.json', 'part2_v63_classification.json', 'part2_profiles.csv',
    'part3_baseline_check.json',
    'part3_historical/formal_protocol_results.json', 'part3_historical/formal_protocol_results.md',
]
REQUIRED_FULL = REQUIRED_QUICK + [
    'part1_fulldiagnose_check.json',
    'part3_mutation/mutation_B3_S1_rerun_summary.json',
]
VOLATILE = {'elapsed', 'elapsed_seconds', 'seconds', 'runtime_seconds', 'time', 'timestamp', 'wall_seconds', 'python'}

def norm(x):
    if isinstance(x, dict):
        return {k: norm(v) for k, v in x.items() if k not in VOLATILE and not k.endswith('_seconds')}
    if isinstance(x, list):
        return [norm(v) for v in x]
    return x

def same(a: Path, b: Path) -> bool:
    if a.suffix == '.json':
        return norm(json.loads(a.read_text())) == norm(json.loads(b.read_text()))
    return a.read_bytes() == b.read_bytes()

def main():
    rec, new = Path(sys.argv[1]), Path(sys.argv[2])
    mode = sys.argv[sys.argv.index('--mode') + 1] if '--mode' in sys.argv else 'quick'
    required = REQUIRED_FULL if mode == 'full' else REQUIRED_QUICK
    failures = 0
    for rel in required:
        a, b = rec / rel, new / rel
        if not a.exists():
            print('FAIL    missing recorded artifact', rel); failures += 1; continue
        if not b.exists():
            print('FAIL    missing re-executed artifact', rel); failures += 1; continue
        if same(a, b):
            print('MATCH  ', rel)
        else:
            print('FAIL    differs', rel); failures += 1
    for a in sorted(p for p in rec.rglob('*') if p.is_file()):
        rel = str(a.relative_to(rec))
        if rel in required or a.suffix == '.jsonl':
            continue
        print('NOT RUN', rel, f'(not required in {mode} mode)')
    print(f'{len(required) - failures}/{len(required)} required artifacts match ({mode} mode)')
    sys.exit(1 if failures else 0)

if __name__ == '__main__':
    main()
