"""GCL-PC descriptive classification candidate. No empirical diagnosis or authority.
Four truth-valued measurements plus explicit indeterminacy; all 81 combinations.
Identification and effect assessment are deliberately independent axes.
"""
from enum import Enum
from itertools import product
from collections import Counter
import json, csv, sys
class T(Enum):
    YES='established'; NO='not_met'; UNKNOWN='insufficient_evidence'
class Result(Enum):
    PRESENT='criteria_met'; ABSENT='criteria_not_met'; INDETERMINATE='indeterminate'
def classify(profile):
    p,j,g,n=profile
    return Result.ABSENT if T.NO in profile else Result.PRESENT if all(v is T.YES for v in profile) else Result.INDETERMINATE

def describe(profile):
    p,j,g,n=profile
    return dict(F_P=p.value,D_J=j.value,D_G=g.value,I_N=n.value,
                gcl_pc=classify(profile).value,
                incipient_capacity_loss_risk=(j is T.YES and g is T.YES and n is not T.YES),
                protected_function_impairment_established=n is T.YES,
                protected_function_status=n.value,
                capacity_loss_established=j is T.YES and g is T.YES,
                evidence_gap=T.UNKNOWN in profile,
                # absence of GCL-PC is not a clearance or a severity ranking
                automatic_incident=False, automatic_action=False)

class ID(Enum):
    POINT='point_identified'; PARTIAL='partially_identified'; NONE='unidentified'
class Effect(Enum):
    ADVERSE='materially_adverse'; NOT_ADVERSE='not_materially_adverse_benefit_not_established'; BENEFICIAL='beneficial'; UNRESOLVED='unresolved'
def assess_effect(id_status, interval, delta):
    """Interval must be a defensible confidence region accounting for sampling and identifying uncertainty, not a plug-in estimate of the population identification set. Report identifying bounds separately. This rule only consumes supplied confidence bounds; coverage is not verified here.
    The function does not validate assumptions, construct intervals, or infer individual causation.
    Boundary effect -delta is materially adverse. No case label is produced.
    """
    if delta<=0: raise ValueError('delta must be positive')
    if id_status is ID.NONE or interval is None: return Effect.UNRESOLVED
    lo,hi=interval
    if not lo<=hi: raise ValueError('invalid interval')
    if hi<=-delta: return Effect.ADVERSE
    if lo>0: return Effect.BENEFICIAL
    if lo>-delta: return Effect.NOT_ADVERSE
    return Effect.UNRESOLVED

def main(path=None):
    rows=[describe(p) for p in product(T,repeat=4)]
    counts=Counter(r['gcl_pc'] for r in rows)
    full=[r for r in rows if not r['evidence_gap']]
    assert len(full)==16 and len(rows)==81
    assert counts=={Result.PRESENT.value:1,Result.ABSENT.value:65,Result.INDETERMINATE.value:15}
    assert sum(r['protected_function_impairment_established'] and r['gcl_pc']!=Result.PRESENT.value for r in full)==7
    assert sum(r['incipient_capacity_loss_risk'] for r in full)==2
    assert all(not r['automatic_incident'] and not r['automatic_action'] for r in rows)
    checks=[(ID.POINT,(-.22,-.18),Effect.ADVERSE),(ID.PARTIAL,(-.224,-.183),Effect.ADVERSE),
            (ID.POINT,(-.01,.01),Effect.NOT_ADVERSE),(ID.POINT,(.1,.2),Effect.BENEFICIAL),(ID.POINT,(0,.2),Effect.NOT_ADVERSE),
            (ID.PARTIAL,(-.1,.02),Effect.UNRESOLVED),(ID.NONE,None,Effect.UNRESOLVED),
            (ID.POINT,(-.05,-.05),Effect.ADVERSE),(ID.POINT,(-.06,-.04),Effect.UNRESOLVED)]
    for id_status,interval,expected in checks: assert assess_effect(id_status,interval,.05) is expected
    if path:
        with open(path,'w',newline='',encoding='utf8') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)
    return {'complete_profiles':len(full),'three_valued_profiles':len(rows),'classification_counts':counts,
            'non_gcl_pc_confirmed_impairment_complete_profiles':7,'incipient_risk_complete_profiles':2,
            'effect_rule_tests':len(checks),'automatic_incidents':0,'automatic_actions':0,
            'scope':'logic only; no measured data, no causal identification, no severity ranking'}
if __name__=='__main__': print(json.dumps(main(sys.argv[1] if len(sys.argv)>1 else None),indent=2))
