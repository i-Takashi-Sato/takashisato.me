# 組版・書体の記録（v6.3 最終）

## 書体
- 本文・見出し・参考文献：STIX Two Text 2.14（Regular/Italic/Bold/BoldItalic、数字はプロポーショナル・ライニング）。
- 数式・論理記号：STIX Two Math 2.14（unicode-math）。本文中の ∧ ∨ ¬ ⇒ ≤ ≥ → ← ↔ ≈ ≠ ∈ δ Δ も数式書体で組む。
- コード・識別子：Source Code Pro（x ハイトを本文に合わせて縮小）。
- 図（Graphviz）：STIX Two Text、論理記号は STIX Two Math。灰色階調。
- 比較：`docs/font_comparison_part2_termes_vs_stix.png`（TeX Gyre Termes＋DejaVu Math では数式記号の字形・太さが本文と揃わない）。
- 取得：配布サイトからの直接取得が遮断されたため github.com/stipub/stixfonts を複製し tools/tirobuild.py で構築。Source Code Pro は adobe-fonts の release ブランチ。いずれも SIL Open Font License 1.1（`fonts/` に同梱、OFL.txt 付き）。

## 版面
- A4、本文 11 pt、版面幅 121 mm × 高さ 216 mm（上余白 36 mm）。1 行平均約 77 字。
- 段落は字下げ、下端は不揃いを許容（\raggedbottom）。孤立行・寡婦行を禁止。
- 見出し：節＝large 太字、項＝太字、目＝斜体。いずれもセリフ体で番号付き。
- 柱：左に論文略題（字間を空けた小型大文字）、右に著者名。ノンブルは下中央。初頁下に DOI。
- 表：booktabs、本文より小さい文字、説明文は表の上。短中の表は浮動体（頁上部優先）、長い表は分割し見出し行を反復。
- 図：説明文は図の下。

## 改ページの規則
- 見出しの直後で改ページしない（節 5 行・項 4 行の確保、直後が小見出しや表なら 12 行）。
- 旧設定の「大見出し前 16 行確保」は大きな空白を生むため廃止（DECISIONS D21）。
- 付録・データ節・参考文献の前で浮動体を出し切る（\FloatBarrier）。付録は残り 18 行以上あれば同じ頁から開始。
- 検査：`build/page_audit.py`（35 mm 超の空白、右余白外の印字、頁末の孤立見出しを検出）と全頁の縮小一覧の目視。最終状態で残る指摘は各編最終頁の余白と、浮動体の直前に生じる 36–41 mm の空白（許容）。

## PDF
- 全フォント埋め込み（サブセット）。テキスト抽出可能（合字は分解）。しおり（節番号付き）、文書言語 en-US、表題・著者・主題・キーワード。
- タグ付き PDF は未対応（LIMITATIONS 参照）。
