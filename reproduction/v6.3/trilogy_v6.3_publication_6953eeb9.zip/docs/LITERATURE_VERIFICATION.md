# 文献照合記録（2026-11-28 時点）

方法：Web 検索・出版社／arXiv／SSRN／公的機関ページで実在と書誌（著者・題・年・媒体・巻号頁・DOI）を照合。「一致」は一次ページで確認、「矛盾なし」は既知の書誌と照合したが DOI 解決まではしていないもの。

## 2025–2026 年の文献・公的資料

| 文献 | 使用編 | 結果 |
|---|---|---|
| Sterz et al. (2024), FAccT '24, 2495–2507, doi:10.1145/3630106.3659051 | II | 一致（頁を含む） |
| Zhu et al. (2026), AI and Ethics, doi:10.1007/s43681-026-01147-7 | I | 一致 |
| Calboreanu (2026), Frontiers in AI, doi:10.3389/frai.2026.1800407 | I | 一致 |
| Mazzocchetti (2026), arXiv:2608.16891 | I | 一致 |
| Azevedo (2026), arXiv:2606.15563 | I | 一致 |
| Langer, Lazar & Baum (2026), LNCS 16220, 160–169 | I, III | 一致（会議年 2025、出版年表記が資料により 2025/2026） |
| Langer, Baum & Schlicker (2025), Minds and Machines 35(1), Article 1, doi:10.1007/s11023-024-09701-0 | I | 一致（2026-11-28 再確認） |
| Manheim & Homewood (2025), arXiv:2507.03525 | I | 一致（2026-11-28 再確認） |
| Lee (2026), CHI EA '26, doi:10.1145/3772363.3798377 | I | 一致 |
| Lin et al. (2026), arXiv:2602.00854 | I, II | 一致 |
| Gaube et al. (2026), arXiv:2605.16278 | I, II | 一致 |
| van de Sande et al. (2026), npj Digital Medicine 9:569 | I, II | 一致 |
| Ferrario & Hatherley (2026), arXiv:2606.00037 | II | 一致 |
| Frimpong (2026) governance inversion, arXiv:2606.26117 | II | 一致（版番号は未確認） |
| Havyarimana (2026), SSRN 7218298 | II | 一致 |
| Niu (2026), arXiv:2602.18474 | II | 一致 |
| Simons & Broniatowski (2026), arXiv:2608.12352 | II | 一致 |
| Tallam (2026), arXiv:2606.12414 | II | 一致 |
| Engin (2026), J. Responsible Technology 26:100167 | II | 一致 |
| Winecoff & Bogen (2025), CHI '25 | I, II | 一致 |
| Popchanovska et al. (2026), arXiv:2603.04259 | III | 一致 |
| Solozobov (2026), arXiv:2604.17836 | III | 一致 |
| Frimpong (2026) AI Debris, arXiv:2606.12432 | III | 一致 |
| Shu & Wei (2026), arXiv:2605.01415 | III | 一致 |
| Han (2026), arXiv:2608.11344 | III | 一致 |
| Ferrario (2026), arXiv:2607.16130 | III | 一致 |
| Wang (2026), arXiv:2607.13040 | III | 一致 |
| OECD (2026), doi:10.1787/41671712-en | III | 一致 |
| Burnat & Davidson (2026) | III | 更新：AIES 2026、doi:10.1609/aies.v9i1.43162 |
| Ditz et al. (2026) | III | 更新：AIES 2026、改題「Secure human oversight of AI: Threat modeling in a socio-technical context」、doi:10.1609/aies.v9i2.43187 |
| Obimakinde (2026), SSRN 6157026 | III | 一致：SSRN 改訂題「The AI Sunset Protocol: Operationalizing Exit, Semantic Portability, and Migration for High-Dependency Systems」（2026-11-28、ChatGPT 監査で SSRN 掲載情報を確認） |
| NCSC Ireland (2026-06-30) | III | 更新：正式題「Securing AI Adoption in the Public Sector: Cyber Security Guidelines for AI Deployments」 |
| ISO/IEC 42105 | I, III | 更新：ISO 公式ページで「Under publication」。in press と表記 |
| Calboreanu (2026)、Mazzocchetti (2026)、Azevedo (2026) の内容 | I | Part I Table 1・§2.3 の比較記述を一次資料の要旨と照合（2026-11-28）：決定的な方針判定（ALLOW/BLOCK/ESCALATE）、ゲート付き実行、人間への escalation、ハッシュ連鎖・署名付き監査（Calboreanu）；提案と実行の分離、信頼できる来歴、fail-closed、非単独の settlement（Mazzocchetti）；不確実性に基づく監督配分（Azevedo） |
| Digital Transformation Agency, Technical standard for government's use of AI | III | 実在確認（2026-11-28） |
| OMB M-25-21 | III | 実在確認（2026-11-28） |

## 古典的文献・公的報告

Meyer & Rowan (1977)、Bovens & Zouridis (2002)、Lipsky (1980)、Power (1997)、Rasmussen (1997)、Vaughan (1996)、Parasuraman & Manzey (2010)、Endsley & Kiris (1995)、Morrison & Milliken (2000)、Bromley & Powell (2012)、Green (2022)、Wagner (2019)、Elish (2019)、Selbst et al. (2019)、Raji et al. (2020)、NIST AI RMF (2023)、EU AI Act (2024)、Robodebt Royal Commission (2023)、オランダ議会調査委員会 (2020)、Michigan OAG (2016) ほか：既知の書誌と照合し矛盾なし。DOI 解決は一部のみ。Michigan OAG 報告書の本文要約は報告書本体と未照合。

## 最終改訂工程で追加した文献（2026-11-28）

| 文献 | 使用編 | 結果 |
|---|---|---|
| Bardach (1976), Policy Sciences 7(2), 123–131 | III | 一致 |
| Biller (1976), Policy Sciences, doi:10.1007/BF00143911 | III | 一致 |
| deLeon (1978), Policy Analysis 4(3), 369–392 | III | 一致（独立した2論文の引用文献リストで巻号頁を確認。DOI は付与されていない） |
| Behn (1978), Policy Analysis 4(3), 393–413 | III | 一致（同上） |
| Brewer (1978), Public Administration Review 38(4), 338–344 | III | 一致（同上。前版の記録の誌名「Policy Analysis」は記録の誤りで、原稿の書誌は当初から正しい） |
| Lewis (2002), Journal of Politics 64(1), 89–107 | III | 一致 |
| Adam, Bauer, Knill & Studinger (2007), Public Organization Review, doi:10.1007/s11115-007-0033-4 | III | 一致 |
| Kuipers et al. (2018), Public Organization Review, doi:10.1007/s11115-017-0376-4 | III | 一致 |
| Daugbjerg & Bazzan (2026), Policy and Society, doi:10.1093/polsoc/puaf050 | III | 一致 |
| Texas Government Code ch. 325（Texas Sunset Act）、§325.017 | III | 州の公式法令ページで条文確認（一年の終了期間、未執行予算の失効、知事による残務担当機関の指定） |
| Sunset Advisory Commission (2025) | III | 公式ページで確認 |
| Bainbridge (1983), Automatica 19(6), 775–779, doi:10.1016/0005-1098(83)90046-8 | I, II | 一致 |
| Hirschman (1970), Exit, Voice, and Loyalty, Harvard University Press | II | 矛盾なし |
| Scott (1998), Seeing Like a State, Yale University Press | II | 矛盾なし |
| Campbell (1979), Evaluation and Program Planning 2(1), 67–90, doi:10.1016/0149-7189(79)90048-X | II | 一致 |
| Goodhart (1975/1984), Monetary Theory and Practice, doi:10.1007/978-1-349-17295-5_4 | II | 一致（再録版） |
| Erpenbach (2026, July 28), Oxford Business Law Blog | II | 掲載日・題名を公式ページで確認。関連プレプリントへのリンクは見当たらず（PYMNTS が 2026-08-25 に転載） |

## 出版慣行の調査（組版判断の根拠、2026-11-28）

- Nature：論文要旨は概ね 200 語台前半を目安とする投稿規定。
- OUP：様式は誌ごとの規定。要旨約 250 語とする誌がある。
- Princeton University Press：Chicago 様式を基本とし、一貫性を重視。
- ACM：acmart テンプレートは Libertine 系書体を指定し、アクセシビリティとメタデータを重視。
- CUP：図表の番号付けと本文での参照、アクセシブルな説明文を求める。
- STIX Two：Tiro Typeworks が STI Pub 加盟出版社の委託で制作した科学出版用書体。
