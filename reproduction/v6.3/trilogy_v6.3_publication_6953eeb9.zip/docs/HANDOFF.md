# 引継書（次セッション・最終監査用）

作成：2026-11-28。作業者：Claude（v6.3 改訂・実装・検証の主担当）。

## 1. 現在の状態

- 最終改訂工程（学術補強・英文編集・組版）を完了。三編の最終候補 PDF、編集可能ソース、テンプレート、書体、検証コード・結果、編集履歴、前後比較、文書一式、SHA-256 一覧、ZIP を作成済み。
- 改訂者は本工程で作業を終了する。以後の修正は独立監査の結果に基づく場合に限るのが望ましい。
- 公開済み v6.2、SSRN、GitHub（i-Takashi-Sato/takashisato.me）、公式サイトには一切変更を加えていない。
- 残る工程は「独立最終監査」と「公開判断」のみ（いずれも著者側）。

## 2. 最終監査の進め方（推奨）

1. 記憶をオフにした新規チャット（またはシークレットモード）で行う。過去の議論・本引継書・対応表は渡さない。
2. 渡すもの：三編の PDF、`code/`・`results/recorded/`、v6.2 原本 PDF（比較用）。
3. 依頼内容の例：「独立した査読者として v6.3 三部作を審査し、論理・反証可能性・因果推論・形式検証の保証範囲・三編間の整合・引用の実在を確認。`bash run_all.sh` と `FULL=1 bash run_all.sh` を実行し、本文の数値と照合」。
4. 監査で修正が出た場合の再生成手順は下記 3。

## 3. 再生成手順

```
# 原稿を編集：manuscripts/partN.md（正本）
python3 build/build.py partN          # build/partN_v6.3.pdf を生成（fonts/ の同梱書体を使用）
python3 build/page_audit.py build/partN_v6.3.pdf   # 空白・はみ出し・孤立見出しの検査
python3 build/editing/meaning_check.py <旧manuscripts> manuscripts out.json   # 前後比較
pdftoppm -r 50 -png build/partN_v6.3.pdf /tmp/pN/p && python3 build/contact.py /tmp/pN /tmp/pN_sheet 4 2   # 目視検査用一覧
bash run_all.sh                        # 数値の再現（FULL=1 で変異検査を含む）
find . -type f ! -name SHA256SUMS ! -path './build/tmp/*' -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
```

図の変更：`manuscripts/figures/*.dot` を編集し `dot -Tpdf` で再生成。共通用語表は三編の付録 A に同一内容で埋め込まれているため、変更時は三編すべてを更新すること（`manuscripts/shared_terminology_map.md` が原本）。

## 4. 著者の判断が必要な事項

LIMITATIONS_AND_OPEN_ISSUES.md の A 節を参照（歴史版資料の同梱可否、生成 AI 開示の確認、公開手順）。

## 5. 注意

- 本パッケージの検証は改訂者自身によるもので、独立査読ではない。
- `build/assemble_part*.py` は v6.2 からの変換の記録であり、作業環境の絶対パスを含む。再生成には使わず、Markdown を直接編集する。
